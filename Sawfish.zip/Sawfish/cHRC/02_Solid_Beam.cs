﻿using System;
using System.Collections.Generic;

using Grasshopper.Kernel;
using Rhino.Geometry;



using Grasshopper.Kernel.Data;






namespace cHRC
{
    public class cc_Component_Solid_Beam : GH_Component
    {
        /// <summary>
        /// Initializes a new instance of the MyComponent1 class.
        /// </summary>
        public cc_Component_Solid_Beam()
          : base("02_Solid Beam", "Solid Beam",
              "Description",
              "cHRC", "02 Offset Geometry")
        {
        }

        /// <summary>
        /// Registers all the input parameters for this component.
        /// </summary>
        protected override void RegisterInputParams(GH_Component.GH_InputParamManager pManager)
        {





            pManager.AddCurveParameter("Polylines", "Pl", "Polyline Input for the offset, as list", GH_ParamAccess.list); //00

           





            pManager.AddNumberParameter("Thickness", "T", "The material thickness, structural height in mm", GH_ParamAccess.item, 50);  //04

            pManager.AddNumberParameter("OffsetBeam", "OB", "Offset the whole beam, for example if there is a plate on top of the beam based on the same input as the beam", GH_ParamAccess.item, 0.0);  //05


            pManager.AddNumberParameter("NodeBack", "NB", "Distance in mm to make the lower node outcut", GH_ParamAccess.item, 60);  //06

        

            pManager.AddIntegerParameter("OpenCloseTop", "OC", "0 for an open node top, 1 for a closed node top", GH_ParamAccess.item, 1);  //07


            pManager.AddBooleanParameter("ForcePlanarity", "FP", "When nodes are open at the top the node adjacant side is not necessarily planar. If True planarity is enforced. Planar Sides can be cut by a circular saw as tool, non planarsides, possibly providing a higher node aesthetic,  have to be milled", GH_ParamAccess.item, true);  //08



            pManager.AddBooleanParameter("CalcLines", "L", "If true, calculates the beams  side  curves, can be  as input for the  ClosedBrep component ", GH_ParamAccess.item, true);  //09


          //  pManager.AddBooleanParameter("CalcSurfaces", "CalcSurface", "In development..: If true, calculates an open Surface  of the beam. if the node top is open you can cap it in grasshopper, use it as it is, for a closed Brep with a closed node so far it was easyier for me to construct it in grasshopper based on the sidlines: partition sidleline list, lenght 7, split away the last line, ruled surface from each line to the next by shift list, join surfaces, cap, see the example file)  ", GH_ParamAccess.item, true);  //10



            pManager.AddBooleanParameter("CalcMesh", "M", "If true, calculates am mesh of each beam)  ", GH_ParamAccess.item, false);  //11




            pManager.AddNumberParameter("CheckDist", "CD", "The Distance from the polygon edges middlepoint to the neighbourpolygon in which the neighbour polygon is considered a neighbour (not a naked edge)", GH_ParamAccess.item, 0.01); //03

            // pManager.AddBooleanParameter("Manual iteration", "Manual iteration", "True to limit the iterations", GH_ParamAccess.item, false);  //01

            pManager.AddIntegerParameter("StartIteration", "Si", "Start Index if larger than -1", GH_ParamAccess.item, -1); //03


            pManager.AddIntegerParameter("MaxIterations", "Mi", "Maximal Iteration count if larger than -1", GH_ParamAccess.item, -1); //02






        }

        /// <summary>
        /// Registers all the output parameters for this component.
        /// </summary>
        protected override void RegisterOutputParams(GH_Component.GH_OutputParamManager pManager)
        {



            pManager.AddCurveParameter("TopPolyline", "TPl", "The top polyline possibly with node outcut", GH_ParamAccess.list);  //00


            pManager.AddCurveParameter("Lowerpolyline", "LPl", "The lower polyline  with node outcut", GH_ParamAccess.list);  //01

            pManager.AddCurveParameter("SideCurves", "SC", "SideCurves as Tree, no double curves", GH_ParamAccess.tree); //05


            //    pManager.AddCurveParameter("SideCurves", "SideCurves", "The curves (line-like) connecting the top and the lower polyline", GH_ParamAccess.list);  //02


            //   pManager.AddSurfaceParameter("Surface", "Surface", "A  List of Surfaces for each beam compoinent if CalcSurface input is true", GH_ParamAccess.list);  //03


            pManager.AddMeshParameter("Meshes", "M", "A  List of meshes for each beam compoinent if ClacMesh input is true", GH_ParamAccess.list);  //04



         


           //pManager.AddCurveParameter("SideCurvesTreeC", "SideCurvesTreeC", "SideCurves as Tree", GH_ParamAccess.tree); //06




        }

        /// <summary>
        /// This is the method that actually does the work.
        /// </summary>
        /// <param name="DA">The DA object is used to retrieve from inputs and store in outputs.</param>
        protected override void SolveInstance(IGH_DataAccess DA)
        {





            List<Curve> iCurves = new List<Curve>();   //00





        //    bool oManItOn = false;  //01


            double oHeight = 27; //04


            double oOffsetBeam = 27; //05

            double oNodeBack = 34; //06



            int OKOpenClosed = 1;  // 07


            bool oForcePlanarity = true; //08



            bool oCalcLines = true; //09

         //   bool oCalcBrep = true; //10


            bool oCalcMesh = true; //11


            double iCheckDist = 0.01;



            int oManStIndex = -1; //03


            int oManIt = -1; //02

       






            //  if (!DA.GetDataTree<GH_Curve>(0, out iCurves0)) return;   //worked in crazy ways tree structure




            if (!DA.GetDataList<Curve>(0, iCurves)) { return; } //  0


                                                

     //       if (!DA.GetData(1, ref oManItOn)) return;  //01



            if (!DA.GetData(1, ref oHeight)) return; //04



            if (!DA.GetData(2, ref oOffsetBeam)) return;   //05

            if (!DA.GetData(3, ref oNodeBack)) return;   //06



            if (!DA.GetData(4, ref OKOpenClosed)) return;  //07



            if (!DA.GetData(5, ref oForcePlanarity)) return;  //08



            if (!DA.GetData(6, ref oCalcLines)) return;  //09

        //    if (!DA.GetData(7, ref oCalcBrep)) return;  //10


            if (!DA.GetData(7, ref oCalcMesh)) return;  //11


            if (!DA.GetData(8, ref iCheckDist)) return;  //11

            if (!DA.GetData(9, ref oManStIndex)) return; //03

            if (!DA.GetData(10, ref oManIt)) return;  //02
















            //Expiring:


            var myDay = System.DateTime.Now.Day;

            var myMonth = System.DateTime.Now.Month;

            var myYear = System.DateTime.Now.Year;

            /*
            A = myDay;

            B = myMonth;

            C = myYear;
            */

            //ExpiringTime

            int check = 1;

            int expYear = 999999999;

            int expMonth = 03;

            int expDay = 27;



            if (myYear > expYear)
            {
                check = 0;
            }

            if (myYear == expYear)
            {
                if (myMonth > expMonth)
                {
                    check = 0;
                }

                if (myMonth == expMonth)
                {

                    if (myDay > expDay)
                    {
                        check = 0;
                    }

                }

            }



            //  E = check;



























            /*



                int iteration;

                int StartIndex;

                //  int oManStIndex = 0;

                if (oManItOn == true)

                {
                  iteration = oManIt;

                  StartIndex = oManStIndex;


                }

                else

                {
                  iteration = iCurves.Count;

                  StartIndex = 0;


                }

                        */







            // Enable to define the iteration start and the iteration count without being out of range all the time



            int myStartIndex = 0;

            int iteration = 0;



            if (oManStIndex == -1 & oManIt == -1)

            {
                myStartIndex = 0;

                iteration = iCurves.Count;

                //  iteration = 2;
            }





            if (oManStIndex > -1 & oManIt == -1)

            {

                if (oManStIndex < iCurves.Count)

                {

                    myStartIndex = oManStIndex;

                    iteration = iCurves.Count - oManStIndex;

                }


                else

                {

                    myStartIndex = iCurves.Count - 1;

                    iteration = 1;


                }



            }





            if (oManStIndex == -1 & oManIt > -1)

            {


                if (oManIt < iCurves.Count)

                {
                    myStartIndex = 0;

                    iteration = oManIt;

                }

                else

                {

                    myStartIndex = 0;

                    iteration = iCurves.Count;
                }


            }





            if (oManStIndex > -1 & oManIt > -1)

            {


                if (oManStIndex < iCurves.Count)

                {
                    myStartIndex = oManStIndex;


                    if (oManIt + oManStIndex < iCurves.Count)

                    {
                        iteration = oManIt;
                    }


                    else

                    {
                        iteration = iCurves.Count - oManStIndex;
                    }



                }



                else

                {
                    myStartIndex = iCurves.Count - 1;

                    iteration = 1;

                }



            }




    






    List<Polyline> AllBeamPolylinesUK = new List<Polyline>();


    List<Polyline> AllBeamPolylinesOK = new List<Polyline>();


    List<Point3d> testPoints = new List<Point3d>();

    List<NurbsCurve> allConnectLines = new List<NurbsCurve>();



    List<Mesh> allMeshes = new List<Mesh>();





    List<Brep> allBreps = new List<Brep>();

    List<Brep> allBreps2 = new List<Brep>();



    List<Vector3d> myNormals = new List<Vector3d>();

    List<Point3d> myPcenters = new List<Point3d>();




            List<Polyline> Icurves22 = new List<Polyline>();




            List<List<NurbsCurve>> myListListCurves = new List<List<NurbsCurve>>();





            //Loop through all input polylines to get all neighbour normal vectors and neighbour polygon centers which are necessary to offset the beam correctly  (Edge offset in the bisecting angle to the neighbour)

            if (check != 0)  //Expiring if

            {



                for (int i = 0; i < iCurves.Count; i++)

                {



                    // Necessary in Visual Studio

                    Polyline iPolyL3;

                    //     iCurves[i + oManStIndex].TryGetPolyline(out iPolyL3);

                    iCurves[i].TryGetPolyline(out iPolyL3);



                    // Polyline iPolyL3 = iCurves[i];


                    Vector3d v4 = iPolyL3[0] - iPolyL3[1];

                    //v4.Unitize();

                    Vector3d v5 = iPolyL3[0] - iPolyL3[2];

                    //v5.Unitize();


                    Vector3d myNormal = Vector3d.CrossProduct(v4, v5);

                    myNormal.Unitize();

                    myNormals.Add(myNormal);


                    Point3d myPcenter7 = PolylineAverage(iPolyL3);



                    myPcenters.Add(myPcenter7);


                    Polyline myPolyL;

                    iCurves[i].TryGetPolyline(out myPolyL);


                    //  iCurves[i + oManStIndex].TryGetPolyline(out myPolyL);


                    Icurves22.Add(myPolyL);

                }

            }//Expiring



    double oHeightSuper = oHeight + oOffsetBeam;


// Main loop, (this is the most horrible node of the plugin)




    for (int i = 0; i < iteration; i++)
    {


     // Polyline iPolyL0 = iCurves[i + StartIndex];







                Polyline iPolyL0;   // The polyline to work with


                //iCurves[i + oManStIndex].TryGetPolyline(out iPolyL0);


                iCurves[i + myStartIndex].TryGetPolyline(out iPolyL0);



                /*


                List<Point3d> myUKpoints = UKpointOffset(iPolyL0, oHeightSuper, myPcenters[i + StartIndex], Icurves22, myPcenters, myNormals, oNodeBack);



      List<Point3d> myOKdownPoints0 = UKpointOffset(iPolyL0, oOffsetBeam, myPcenters[i + StartIndex], Icurves22, myPcenters, myNormals, oNodeBack);



                */



                // Offset function is called twice: so the beam can be constructed between the two offsets(with different offset distance) 
                //this is to move the beam globally down if a plate is on its top



                List<Point3d> myUKpoints = UKpointOffset(iPolyL0, oHeightSuper, myPcenters[i + myStartIndex], Icurves22, myPcenters, myNormals, oNodeBack, iCheckDist); //offset 1 by a functiuon, see functions



                List<Point3d> myOKdownPoints0 = UKpointOffset(iPolyL0, oOffsetBeam, myPcenters[i + myStartIndex], Icurves22, myPcenters, myNormals, oNodeBack, iCheckDist); //offset 2 by a functiuon, see functions





                List<List<Point3d>> myOKdownPointsListList = new List<List<Point3d>>();








      if (oForcePlanarity)

      {

        myOKdownPointsListList.Add(OKPlanarity(myOKdownPoints0, myUKpoints));  //At the node one side is not necessarily planar. With this Function the fourth point which is out of plane is moved back to the plane (in the corret direction)

      }

      else


      {

        myOKdownPointsListList.Add(myOKdownPoints0);

      }


      List<Point3d> myOKdownPoints = myOKdownPointsListList[0];









      myUKpoints.Add(myUKpoints[0]);

      Polyline UKpolyLine1 = new Polyline(myUKpoints);


      AllBeamPolylinesUK.Add(UKpolyLine1);



//Choose between an open and a closed node: open nodes cause  a quad surface at the node which is not automatically planar. for this sitation is the Force Planarity function

      if (OKOpenClosed != 1)

      {

        myOKdownPoints.Add(myOKdownPoints[0]);

        Polyline OKpolyLine1 = new Polyline(myOKdownPoints);

        AllBeamPolylinesOK.Add(OKpolyLine1);



      }

      else

      {

        AllBeamPolylinesOK.Add(iPolyL0);
      }











      if (OKOpenClosed != 1)

      {

        if (oCalcLines)  // create the side lines


        {


          List<NurbsCurve> Connectlines = new List<NurbsCurve>();

          Brep collectBrep = new Brep();


          Line l1 = new Line(myUKpoints[0], myOKdownPoints[0]);

          NurbsCurve myNurb1 = l1.ToNurbsCurve();

          Connectlines.Add(myNurb1);






          Line l2 = new Line(myUKpoints[1], myOKdownPoints[1]);

          NurbsCurve myNurb2 = l2.ToNurbsCurve();

          Connectlines.Add(myNurb2);



          // var myBrep1 = Brep.CreateFromCornerPoints(myUKpoints[0], myUKpoints[1], iPolyL0[0], iPolyL0[1], 0.001);

          // collectBrep.AddSurface(myBrep1.Surfaces[0]);



          Line l3 = new Line(myUKpoints[2], myOKdownPoints[2]);

          NurbsCurve myNurb3 = l3.ToNurbsCurve();

          Connectlines.Add(myNurb3);





          Line l4 = new Line(myUKpoints[3], myOKdownPoints[3]);

          NurbsCurve myNurb4 = l4.ToNurbsCurve();

          Connectlines.Add(myNurb4);



          Line l5 = new Line(myUKpoints[4], myOKdownPoints[4]);

          NurbsCurve myNurb5 = l5.ToNurbsCurve();

          Connectlines.Add(myNurb5);



          Line l6 = new Line(myUKpoints[5], myOKdownPoints[5]);

          NurbsCurve myNurb6 = l6.ToNurbsCurve();

          Connectlines.Add(myNurb6);


          Line l7 = new Line(myUKpoints[0], myOKdownPoints[0]);

          NurbsCurve myNurb7 = l7.ToNurbsCurve();

          Connectlines.Add(myNurb7);


                        myListListCurves.Add(Connectlines);


                        //Brep myBrep = new Brep();



             /*           if (oCalcBrep)

          {

            var myBrep = Brep.CreateFromLoft(Connectlines, Point3d.Unset, Point3d.Unset, LoftType.Straight, false)[0];

            // myBrep.CapPlanarHoles(0.001);

            allBreps.Add(myBrep);


            //allBreps2.Add(collectBrep);

          }


*/

          for (int j = 0; j < Connectlines.Count; j++)
          {
            allConnectLines.Add(Connectlines[j]);
          }




        }




        //mesh.Vertices.Add(Srf.PointAt((double) t1[i][0], t2 * j));



        //Create a mesh representation of the beam



        if (oCalcMesh)

        {

          Mesh myMesh = new Mesh();

          for (int j = 0; j < myUKpoints.Count; j++)
          {
            myMesh.Vertices.Add(myUKpoints[j]);

          }


          for (int j = 0; j < myOKdownPoints.Count; j++)
          {
            myMesh.Vertices.Add(myOKdownPoints[j]);

          }


          // myMesh.Faces.AddFace(3, 2, 1, 0);

          myMesh.Faces.AddFace(3, 0, 1, 2);

          //myMesh.Faces.AddFace(0, 5, 4, 3);

          myMesh.Faces.AddFace(0, 3, 4, 5);




          myMesh.Faces.AddFace(myUKpoints.Count + 1, myUKpoints.Count + 2, myUKpoints.Count + 3, myUKpoints.Count + 4);

          myMesh.Faces.AddFace(myUKpoints.Count + 0, myUKpoints.Count + 1, myUKpoints.Count + 4, myUKpoints.Count + 5);


          myMesh.Faces.AddFace(0, 1, myUKpoints.Count + 1, myUKpoints.Count + 0);

          myMesh.Faces.AddFace(1, 2, myUKpoints.Count + 2, myUKpoints.Count + 1);

          myMesh.Faces.AddFace(2, 3, myUKpoints.Count + 3, myUKpoints.Count + 2);

          myMesh.Faces.AddFace(3, 4, myUKpoints.Count + 4, myUKpoints.Count + 3);

          myMesh.Faces.AddFace(4, 5, myUKpoints.Count + 5, myUKpoints.Count + 4);

          myMesh.Faces.AddFace(5, 0, myUKpoints.Count + 0, myUKpoints.Count + 5);


          //This is important: if the mesh normals are not unified and again computed the mesh looks horrible, all the normals have to point outside 

          myMesh.Normals.ComputeNormals();


          myMesh.UnifyNormals();


          myMesh.Normals.ComputeNormals();




          //  int N;

          // N =  myMesh.UnifyNormals(false);


          //myMesh.FaceNormals.UnitizeFaceNormals();







          allMeshes.Add(myMesh);



        }


      }





      else


      {

        if (oCalcLines)   //Calculate the side lines


        {


          List<NurbsCurve> Connectlines = new List<NurbsCurve>();

          Brep collectBrep = new Brep();


          Line l1 = new Line(myUKpoints[0], iPolyL0[0]);

          NurbsCurve myNurb1 = l1.ToNurbsCurve();

          Connectlines.Add(myNurb1);






          Line l2 = new Line(myUKpoints[1], iPolyL0[1]);

          NurbsCurve myNurb2 = l2.ToNurbsCurve();

          Connectlines.Add(myNurb2);



          // var myBrep1 = Brep.CreateFromCornerPoints(myUKpoints[0], myUKpoints[1], iPolyL0[0], iPolyL0[1], 0.001);

          // collectBrep.AddSurface(myBrep1.Surfaces[0]);



          Line l3 = new Line(myUKpoints[2], iPolyL0[1]);

          NurbsCurve myNurb3 = l3.ToNurbsCurve();

          Connectlines.Add(myNurb3);





          Line l4 = new Line(myUKpoints[3], iPolyL0[2]);

          NurbsCurve myNurb4 = l4.ToNurbsCurve();

          Connectlines.Add(myNurb4);



          Line l5 = new Line(myUKpoints[4], iPolyL0[3]);

          NurbsCurve myNurb5 = l5.ToNurbsCurve();

          Connectlines.Add(myNurb5);



          Line l6 = new Line(myUKpoints[5], iPolyL0[4]);

          NurbsCurve myNurb6 = l6.ToNurbsCurve();

          Connectlines.Add(myNurb6);


          Line l7 = new Line(myUKpoints[0], iPolyL0[0]);

          NurbsCurve myNurb7 = l7.ToNurbsCurve();

          Connectlines.Add(myNurb7);

                      

/*
                        //Brep myBrep = new Brep();

                        if (oCalcBrep)

          {

            var myBrep = Brep.CreateFromLoft(Connectlines, Point3d.Unset, Point3d.Unset, LoftType.Straight, false)[0];

            //myBrep.CapPlanarHoles(0.001);

            allBreps.Add(myBrep);


            //allBreps2.Add(collectBrep);

          }


*/

          myListListCurves.Add(Connectlines);


          for (int j = 0; j < Connectlines.Count; j++)
          {
            allConnectLines.Add(Connectlines[j]);
          }




        }




        //mesh.Vertices.Add(Srf.PointAt((double) t1[i][0], t2 * j));


        // Create a mesh representation of the beam

        if (oCalcMesh)

        {

          Mesh myMesh = new Mesh();

          for (int j = 0; j < myUKpoints.Count; j++)
          {
            myMesh.Vertices.Add(myUKpoints[j]);

          }


          for (int j = 0; j < iPolyL0.Count; j++)
          {
            myMesh.Vertices.Add(iPolyL0[j]);

          }


          myMesh.Faces.AddFace(3, 2, 1, 0);

          myMesh.Faces.AddFace(0, 5, 4, 3);


          myMesh.Faces.AddFace(myUKpoints.Count + 1, myUKpoints.Count + 2, myUKpoints.Count + 3, myUKpoints.Count + 4);


          myMesh.Faces.AddFace(0, 1, myUKpoints.Count + 1, myUKpoints.Count + 0);

          myMesh.Faces.AddFace(1, 2, myUKpoints.Count + 1);

          myMesh.Faces.AddFace(2, 3, myUKpoints.Count + 2, myUKpoints.Count + 1);

          myMesh.Faces.AddFace(3, 4, myUKpoints.Count + 3, myUKpoints.Count + 2);

          myMesh.Faces.AddFace(4, 5, myUKpoints.Count + 4, myUKpoints.Count + 3);

          myMesh.Faces.AddFace(5, 6, myUKpoints.Count + 4);


          //This is important: if the mesh normals are not unified and again computed the mesh looks horrible, all the normals have to point outside 

          myMesh.Normals.ComputeNormals();


          myMesh.UnifyNormals();


          myMesh.Normals.ComputeNormals();







          allMeshes.Add(myMesh);



        }


      }



    }









            //  List<Point3d> myUKpoints222 = UKpointOffset(iCurves[0], oHeightSuper, myPcenters[0 + StartIndex], Icurves22, myPcenters, myNormals, oNodeBack);   //visual studio out

            // List<Point3d> myOKdownPoints222 = UKpointOffset(iCurves[0], oOffsetBeam, myPcenters[0 + StartIndex], Icurves22, myPcenters, myNormals, oNodeBack);    //visual studio out



            // Line TestP22 = OKPlanarity(myOKdownPoints222, myUKpoints222);


            //  List<Point3d> TestP22 = OKPlanarity(myOKdownPoints222, myUKpoints222);  //visual studio out


            // List<Plane> TestP22 = OKPlanarity(myOKdownPoints222, myUKpoints222);

            // Point3d TestP22 = OKPlanarity(myOKdownPoints222, myUKpoints222);




            /*


     oBeamPolylinesUK = AllBeamPolylinesUK;

    //oTestP = testPoints;

    oAllConnectlines = allConnectLines;

    oAllBreps = allBreps;

    oAllBreps2 = allBreps2;


    oAllMeshes = allMeshes;


    oAllBeamPolylinesOK = AllBeamPolylinesOK;



            //oTest = TestP22;



            */











            /*



            Grasshopper.DataTree<Curve> myFinalCurvesTreeC = new Grasshopper.DataTree<Curve>();        //ListofLists to Tree for the Output


            int BranchCount222 = myListListCurves.Count;


            for (int i = 0; i < myListListCurves.Count; i++)

            {

                int ListLenght333 = myListListCurves[i].Count;

                for (int j = 0; j < ListLenght333; j++)

                {

                    myFinalCurvesTreeC.Add(myListListCurves[i][j], new GH_Path(i));

                    //myFinalPointsTree.Add(mySuperPoints[i][j], new GH_Path(i));
                }


            }



            */





            Grasshopper.DataTree<Curve> myFinalCurvesTreeO = new Grasshopper.DataTree<Curve>();        //ListofLists to Tree for the Output


           /// int BranchCount222 = myListListCurves.Count;


            for (int i = 0; i < myListListCurves.Count; i++)

            {

                int ListLenght333 = myListListCurves[i].Count -1;

                for (int j = 0; j < ListLenght333; j++)

                {

                    myFinalCurvesTreeO.Add(myListListCurves[i][j], new GH_Path(i));

                    //myFinalPointsTree.Add(mySuperPoints[i][j], new GH_Path(i));
                }


            }











            DA.SetDataList(0, AllBeamPolylinesOK);

            DA.SetDataList(1, AllBeamPolylinesUK);

            DA.SetDataTree(2, myFinalCurvesTreeO);

            //     DA.SetDataList(2, allConnectLines);

            //     DA.SetDataList(3, allBreps);


            DA.SetDataList(3, allMeshes);

          

          //  DA.SetDataTree(5, myFinalCurvesTreeC);














        }














        //At the node one side is not necessarily planar. With this Function the fourth point which is out of plane is moved back to the plane (in the corret direction) without messing up(making not planar the other sides)


    //The principle to make the nonplanar quad planar  is to project the out of plane point back to a plane defined by the three other points IN THE VECTOR OF THE AFJACANT EDGE to not make the adjacant side non planar

        public static List<Point3d> OKPlanarity(List<Point3d> ListOK, List<Point3d> ListUK)


        {


            /*
            for (int i = 0; i < ListOK.Count ; i++)

            {
              PCenterT2 = PCenterT2 + iPolyL[i];
            }

           */



            Plane myPlane1 = new Plane(ListUK[0], ListUK[0] - ListOK[0], ListUK[0] - ListUK[5]);

            Plane myPlane2 = new Plane(ListUK[1], ListUK[1] - ListOK[1], ListUK[1] - ListUK[2]);




            Vector3d V45 = ListOK[5] - ListOK[4];

            Vector3d V32 = ListOK[2] - ListOK[3];


            Point3d Move45 = ListOK[4] + V45 * 2;

            Point3d Move32 = ListOK[3] + V32 * 2;


            Line L45 = new Line(ListOK[4], Move45);

            Line L32 = new Line(ListOK[3], Move32);




            double t45;

            Rhino.Geometry.Intersect.Intersection.LinePlane(L45, myPlane1, out t45);


            Point3d intPoint45 = L45.PointAt(t45);





            double t32;

            Rhino.Geometry.Intersect.Intersection.LinePlane(L32, myPlane2, out t32);


            Point3d intPoint32 = L32.PointAt(t32);






            List<Point3d> AdjustedOK = new List<Point3d>();





            AdjustedOK.Add(ListOK[0]);


            AdjustedOK.Add(ListOK[1]);

            AdjustedOK.Add(intPoint32);

            AdjustedOK.Add(ListOK[3]);

            AdjustedOK.Add(ListOK[4]);

            AdjustedOK.Add(intPoint45);




            // return myPlane1;

            return AdjustedOK;

        }











        public static Point3d PolylineAverage(Polyline iPolyL)   //A Fubnction to get the center of a closed polyline
        {

            Point3d PCenterT2 = new Point3d(0, 0, 0);


            for (int i = 0; i < iPolyL.Count - 1; i++)

            {
                PCenterT2 = PCenterT2 + iPolyL[i];
            }

            Point3d PCenter3 = PCenterT2 / (iPolyL.Count - 1);


            return PCenter3;
        }





        // A Function to offset the beam  top polyline points

        // The endpoints of the edges are moved in the bisecting vector of the adjacant polyline normal vectors. To get the correct and uniform material Thickness offset Distance is calculated with a math cosinus function 
        //in dependence of the material thickness.
        //If an edge is naked and therte is no neighbour polyline,
        //the edges Endpoints are moved in the polylines normal vector: Distance: Matetrial Thickness


        public static List<Point3d> UKpointOffset(Polyline iPolyL, double height, Point3d myPcenter, List<Polyline> allMyPolylines, List<Point3d> allmyPcenters, List<Vector3d> superNormals, double nodeBack, double myCheckdist)
        {


            List<Point3d> offsetsUK = new List<Point3d>();

            List<Point3d> test2 = new List<Point3d>();

            //iPolyL.Count - 1




            //main Loop through polylines segments (points)

            for (int i = 0; i < iPolyL.Count - 1; i++)

            {


                Vector3d v1 = iPolyL[i] - iPolyL[i + 1];  // Edge vector

                Point3d mp0 = iPolyL[i] + v1 * -0.5;   //Middle point

                //test2.Add(mp0);

                // List<Polyline> myNeighbours = new List<Polyline>();

                List<Point3d> myNeighbourCenterPoints = new List<Point3d>();

                List<Vector3d> myNeighbourVectors = new List<Vector3d>();



                //Find the neighbour polylines of the current polyline edge

                for (int j = 0; j < allMyPolylines.Count; j++)
                {

                    Polyline myPl = allMyPolylines[j];

                    Point3d myCP = myPl.ClosestPoint(mp0);

                    double Distance = mp0.DistanceTo(myCP);


                    if (Distance < myCheckdist)
                    {
                        //myNeighbours.Add(allMyPolylines[j]);

                        myNeighbourCenterPoints.Add(allmyPcenters[j]);

                        myNeighbourVectors.Add(superNormals[j]);
                    }

                }



                //Distinguishing between naked and not naked edges by counting how many neighbours a polyline edge has

               // Moving offseted  edges endpoints back if they are at the node to create the outcut of the complex node part

                if (myNeighbourCenterPoints.Count < 2)  // The curent polyline is considered as a neighbour of itself, therefore every polyline segment has at least one Neighbour(itself) therefore Count < 2

                {

                    Vector3d moveVec = Vector3d.CrossProduct(v1, myNeighbourCenterPoints[0] - iPolyL[i]);  //NO Neighbour exept of itself: move in the polylines normal vector 

                    moveVec.Unitize();


                    Point3d myUKpoint0 = iPolyL[i] + moveVec * height;

                    Point3d myUKpoint1 = iPolyL[i + 1] + moveVec * height;

                    v1.Unitize();


                    // set the node points back for the outcut of the complex node situation if it is the first  (longest) edge (naked but not i==0 means its a edge not at the node(second longes paralell to the longest at the node))


                    if (i == 0)  //first longest edge if at the edge of the over all structure  then its naked 
                    {

                        Point3d NodeBack0 = myUKpoint0 + v1 * -1 * nodeBack;

                        Point3d NodeBack1 = myUKpoint1 + v1 * nodeBack;


                        test2.Add(NodeBack0);

                        test2.Add(NodeBack1);

                    }



                }





                else   //The Polylinesegment  has a neigbour (is not naked) moving in the bisecting direction of the polylines and the polylines neighbour normal vector. Distance: with math cos in dependence of the material thickness


                {


                    Vector3d moveVecSum2 = myNeighbourVectors[0] + myNeighbourVectors[1];

                    moveVecSum2.Unitize();




                    double alpha = Vector3d.VectorAngle(moveVecSum2, myNeighbourVectors[1]);


                    double Hypothenuse = height / System.Math.Cos(alpha);



                    Point3d myUKpoint2 = iPolyL[i] + moveVecSum2 * Hypothenuse * -1;

                    Point3d myUKpoint3 = iPolyL[i + 1] + moveVecSum2 * Hypothenuse * -1;



                    v1.Unitize();



                    // set the node points back for the outcut of the complex node situation


                    if (i == 0) //first longest here never naked

                    {

                        Point3d NodeBack2 = myUKpoint2 + v1 * -1 * nodeBack;

                        Point3d NodeBack3 = myUKpoint3 + v1 * nodeBack;


                        test2.Add(NodeBack2);

                        test2.Add(NodeBack3);

                    }



                    if (i == 1) //never naked

                    {

                        Point3d NodeBack2 = myUKpoint2 + v1 * -1 * nodeBack;

                        Point3d NodeBack3 = myUKpoint3;// +v1 * nodeBack; //i think always naked paralell to longest


                        test2.Add(NodeBack2);

                        test2.Add(NodeBack3);

                    }


                    if (i == 3) // never naked

                    {

                        Point3d NodeBack2 = myUKpoint2;// +v1 * -1 * nodeBack;   //i think always naked paralell to longest

                        Point3d NodeBack3 = myUKpoint3 + v1 * nodeBack;  


                        test2.Add(NodeBack2);

                        test2.Add(NodeBack3);

                    }

                }

            }

            return test2;

        }

































        /// <summary>
        /// Provides an Icon for the component.
        /// </summary>
        protected override System.Drawing.Bitmap Icon
        {
            get
            {
                //You can add image files to your project resources and access them like this:
                // return Resources.IconForThisComponent;
                // return null;

                // return Resource1._1rhino;

                //   return Resource1.beam777;


                //    return Resource1.offset257_black_solid;


                return Resource1.beamLast;


            }
        }

        /// <summary>
        /// Gets the unique ID for this component. Do not change this ID after release.
        /// </summary>
        public override Guid ComponentGuid
        {
            get { return new Guid("7d533e2c-56c5-4029-9c8e-ebe81fbb5fb0"); }
        }
    }
}