﻿using System;
using System.Collections.Generic;

using Grasshopper.Kernel;
using Rhino.Geometry;

namespace cHRC
{
    public class Component_DivideSurface : GH_Component
    {
        /// <summary>
        /// Initializes a new instance of the MyComponent1 class.
        /// </summary>
        public Component_DivideSurface()
          : base("00_Divide Surface Tri", "Divide Surface Tri",
              "Makes triangular polylines on a UV Nurbsurface",
              "cHRC", "00 Triangulation")
        {
        }

        /// <summary>
        /// Registers all the input parameters for this component.
        /// </summary>
        protected override void RegisterInputParams(GH_Component.GH_InputParamManager pManager)
        {

            pManager.AddSurfaceParameter("Surface", "S", "Nurb Surface to divide ", GH_ParamAccess.item);  //00

            pManager.AddIntegerParameter("U", "U", "U division count", GH_ParamAccess.item, 5); //01

            pManager.AddIntegerParameter("V", "V", "V division count", GH_ParamAccess.item, 5); //02

        }


        /// <summary>
        /// Registers all the output parameters for this component.
        /// </summary>
        protected override void RegisterOutputParams(GH_Component.GH_OutputParamManager pManager)
        {
            pManager.AddCurveParameter("TopPolylineCurve", "TPl", "The top polyline of the enforcement beam with a easy 90 degree cut node situation", GH_ParamAccess.list);  //00
        }




        /// <summary>
        /// This is the method that actually does the work.
        /// </summary>
        /// <param name="DA">The DA object is used to retrieve from inputs and store in outputs.</param>
        /// 


        protected override void SolveInstance(IGH_DataAccess DA)
        {

            Surface iSurface = null;  //00

            int U = 1; //01

            int V = 1; //02




            if (!DA.GetData(0, ref iSurface)) return;  // 00

            if (!DA.GetData(1, ref U)) return;  // 01

            if (!DA.GetData(2, ref V)) return;  // 02




            //Set Surface domains from effectiv lengt to 1 (0 -1)

            iSurface.SetDomain(0, new Interval(0.0, 1.0));
            iSurface.SetDomain(1, new Interval(0.0, 1.0));


            // Fraction of one part

            double myU = 1 / ((double)U);

            double myV = 1 / ((double)V);



            List<Polyline> myPolylines = new List<Polyline>();

            List<Polyline> myPolylines2 = new List<Polyline>();  //was necessary for development

            List<Polyline> myPolylines3 = new List<Polyline>();  //was necessary for development



            List<List<Point3d>> myPointsListList = new List<List<Point3d>>();  //List of List, in each list is one Point row





            // Getting all surface division points an ordering to make triangles, many solutions for edge exeptions are necessary...



            for (int i = 0; i < U + 1; i++)       
            {

                List<Point3d> myPoints = new List<Point3d>();


                for (int j = 0; j < V + 1; j++)   // adding Points in a row in one list

                {

                    Point3d myp1 = iSurface.PointAt(i * myU, j * myV);

                    myPoints.Add(myp1);

                }

                myPointsListList.Add(myPoints); // adding Points in a row in one list Addling this List to The ListList
            }




            //accessing the list of list to make subblist with each 4 points for a closed triangle

            for (int i = 0; i < U; i++)

            {

                if (i % 2 == 0)  // for uneven subdivisions anothe edge situation is necessary

                {

                    List<Point3d> myPolyPoints0 = new List<Point3d>();



                    Point3d p01 = myPointsListList[i][0];

                    Point3d p02 = myPointsListList[i + 1][0 + 1];

                    Point3d p03 = myPointsListList[i + 1][0 + 0];

                    Point3d p04 = myPointsListList[i][0];


                    myPolyPoints0.Add(p01);

                    myPolyPoints0.Add(p02);

                    myPolyPoints0.Add(p03);

                    myPolyPoints0.Add(p04);



                    Polyline myPoly0 = new Polyline(myPolyPoints0);


                    myPolylines.Add(myPoly0);



                    for (int j = 0; j < V - 1; j++)

                    {


                        if (j % 2 == 0) // for uneven subdivisions anothe edge situation is necessary

                        {

                            List<Point3d> myPolyPoints = new List<Point3d>();



                            Point3d p1 = myPointsListList[i][j];

                            Point3d p2 = myPointsListList[i][j + 2];

                            Point3d p3 = myPointsListList[i + 1][j + 1];

                            Point3d p4 = myPointsListList[i][j];


                            myPolyPoints.Add(p1);

                            myPolyPoints.Add(p2);

                            myPolyPoints.Add(p3);

                            myPolyPoints.Add(p4);



                            Polyline myPoly = new Polyline(myPolyPoints);


                            myPolylines.Add(myPoly);

                        }

                        else

                        {

                            List<Point3d> myPolyPoints = new List<Point3d>();


                            Point3d p1 = myPointsListList[i + 1][j + 0];

                            Point3d p2 = myPointsListList[i + 0][j + 1];

                            Point3d p3 = myPointsListList[i + 1][j + 2];

                            Point3d p4 = myPointsListList[i + 1][j];


                            myPolyPoints.Add(p1);

                            myPolyPoints.Add(p2);

                            myPolyPoints.Add(p3);

                            myPolyPoints.Add(p4);



                            Polyline myPoly = new Polyline(myPolyPoints);


                            myPolylines.Add(myPoly);

                        }

                    }



                    if (V % 2 != 0)  // for uneven subdivisions anothe edge situation is necessary
                    {

                        List<Point3d> myPolyPointsE = new List<Point3d>();


                        int L1 = myPointsListList.Count;

                        int L2 = myPointsListList[i].Count;


                        Point3d pE1 = myPointsListList[i + 0][L2 - 2];

                        Point3d pE2 = myPointsListList[i][L2 - 1];

                        Point3d pE3 = myPointsListList[i + 1][L2 - 1];

                        Point3d pE4 = myPointsListList[i + 0][L2 - 2];



                        myPolyPointsE.Add(pE1);

                        myPolyPointsE.Add(pE2);

                        myPolyPointsE.Add(pE3);

                        myPolyPointsE.Add(pE4);



                        Polyline myPolyE = new Polyline(myPolyPointsE);


                        myPolylines.Add(myPolyE);

                    }

                    else

                    {


                        List<Point3d> myPolyPointsE = new List<Point3d>();


                        int L1 = myPointsListList.Count;

                        int L2 = myPointsListList[i].Count;


                        Point3d pE1 = myPointsListList[i + 1][L2 - 2];

                        Point3d pE2 = myPointsListList[i][L2 - 1];

                        Point3d pE3 = myPointsListList[i + 1][L2 - 1];

                        Point3d pE4 = myPointsListList[i + 1][L2 - 2];



                        myPolyPointsE.Add(pE1);

                        myPolyPointsE.Add(pE2);

                        myPolyPointsE.Add(pE3);

                        myPolyPointsE.Add(pE4);



                        Polyline myPolyE = new Polyline(myPolyPointsE);


                        myPolylines.Add(myPolyE);

                    }


                }



                else


                {

                    List<Point3d> myPolyPoints0 = new List<Point3d>();


                    Point3d p01 = myPointsListList[i][0];

                    Point3d p02 = myPointsListList[i + 0][0 + 1];

                    Point3d p03 = myPointsListList[i + 1][0 + 0];

                    Point3d p04 = myPointsListList[i][0];


                    myPolyPoints0.Add(p01);

                    myPolyPoints0.Add(p02);

                    myPolyPoints0.Add(p03);

                    myPolyPoints0.Add(p04);



                    Polyline myPoly0 = new Polyline(myPolyPoints0);


                    myPolylines.Add(myPoly0);


                    for (int j = 0; j < V - 1; j++)

                    {


                        if (j % 2 == 0)   // for uneven subdivisions anothe edge situation is necessary

                        {

                            List<Point3d> myPolyPoints2 = new List<Point3d>();



                            Point3d pp1 = myPointsListList[i + 1][j + 0];

                            Point3d pp2 = myPointsListList[i + 0][j + 1];

                            Point3d pp3 = myPointsListList[i + 1][j + 2];

                            Point3d pp4 = myPointsListList[i + 1][j + 0];



                            myPolyPoints2.Add(pp1);

                            myPolyPoints2.Add(pp2);

                            myPolyPoints2.Add(pp3);

                            myPolyPoints2.Add(pp4);



                            Polyline myPoly = new Polyline(myPolyPoints2);


                            myPolylines.Add(myPoly);


                        }

                        else

                        {

                            List<Point3d> myPolyPoints2 = new List<Point3d>();



                            Point3d pp1 = myPointsListList[i + 0][j + 0];

                            Point3d pp2 = myPointsListList[i + 0][j + 2];

                            Point3d pp3 = myPointsListList[i + 1][j + 1];

                            Point3d pp4 = myPointsListList[i + 0][j + 0];



                            myPolyPoints2.Add(pp1);

                            myPolyPoints2.Add(pp2);

                            myPolyPoints2.Add(pp3);

                            myPolyPoints2.Add(pp4);


                            Polyline myPoly = new Polyline(myPolyPoints2);

                            myPolylines.Add(myPoly);


                        }




                    }


                    if (V % 2 != 0)  // for uneven subdivisions anothe edge situation is necessary

                    {

                        List<Point3d> myPolyPointsE = new List<Point3d>();


                        int L1 = myPointsListList.Count;

                        int L2 = myPointsListList[i].Count;


                        Point3d pE1 = myPointsListList[i + 0][L2 - 1];

                        Point3d pE2 = myPointsListList[i + 1][L2 - 1];

                        Point3d pE3 = myPointsListList[i + 1][L2 - 2];

                        Point3d pE4 = myPointsListList[i + 0][L2 - 1];



                        myPolyPointsE.Add(pE1);

                        myPolyPointsE.Add(pE2);

                        myPolyPointsE.Add(pE3);

                        myPolyPointsE.Add(pE4);



                        Polyline myPolyE = new Polyline(myPolyPointsE);


                        myPolylines.Add(myPolyE);


                    }

                    else

                    {


                        List<Point3d> myPolyPointsE = new List<Point3d>();


                        int L1 = myPointsListList.Count;

                        int L2 = myPointsListList[i].Count;


                        Point3d pE1 = myPointsListList[i + 0][L2 - 1];

                        Point3d pE2 = myPointsListList[i + 1][L2 - 1];

                        Point3d pE3 = myPointsListList[i][L2 - 2];

                        Point3d pE4 = myPointsListList[i + 0][L2 - 1];



                        myPolyPointsE.Add(pE1);

                        myPolyPointsE.Add(pE2);

                        myPolyPointsE.Add(pE3);

                        myPolyPointsE.Add(pE4);



                        Polyline myPolyE = new Polyline(myPolyPointsE);


                        myPolylines.Add(myPolyE);




                    }



                }




            }




            //Output Geometry

            DA.SetDataList(0, myPolylines);



        }

        /// <summary>
        /// Provides an Icon for the component.
        /// </summary>
        protected override System.Drawing.Bitmap Icon
        {
            get
            {
                //You can add image files to your project resources and access them like this:
                // return Resources.IconForThisComponent;

                //return null;

                return Resource1.tri;
            }
        }

        /// <summary>
        /// Gets the unique ID for this component. Do not change this ID after release.
        /// </summary>
        public override Guid ComponentGuid
        {
            get { return new Guid("e21e54c6-808f-4e19-864c-349d6787bb61"); }
        }
    }
}