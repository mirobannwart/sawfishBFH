﻿using System;
using System.Collections.Generic;

using Grasshopper.Kernel;
using Rhino.Geometry;

namespace cHRC
{
    public class PolylineCheckpoints : GH_Component
    {
        /// <summary>
        /// Initializes a new instance of the MyComponent3 class.
        /// </summary>
        public PolylineCheckpoints()
          : base("07_PolylineCheckPoints", "PLcheckP",
              "Get the hightest point(.Z), lowest point (.Z) or the center point of a polyline ",
              "cHRC", "01 Adjust")
        {
        }

        /// <summary>
        /// Registers all the input parameters for this component.
        /// </summary>
        protected override void RegisterInputParams(GH_Component.GH_InputParamManager pManager)
        {
            pManager.AddCurveParameter("Polylines", "PL", "Polylines without the removed ones", GH_ParamAccess.list); //00

            pManager.AddBooleanParameter("Highest", "H", "Get the higest point of a polyline", GH_ParamAccess.item, true);  //01

            pManager.AddBooleanParameter("Lowest", "L", "Get the lowest point of a polylinen", GH_ParamAccess.item, false);  //02

            pManager.AddBooleanParameter("Centerpoint", "C", "Get the centerpoint of a polyline", GH_ParamAccess.item, false);  //03
        }

        /// <summary>
        /// Registers all the output parameters for this component.
        /// </summary>
        protected override void RegisterOutputParams(GH_Component.GH_OutputParamManager pManager)
        {

            pManager.AddPointParameter("Points", "Pt", "The Checkpoints", GH_ParamAccess.list);
        }

        /// <summary>
        /// This is the method that actually does the work.
        /// </summary>
        /// <param name="DA">The DA object is used to retrieve from inputs and store in outputs.</param>
        protected override void SolveInstance(IGH_DataAccess DA)
        {




            List<Curve> iCurves = new List<Curve>();   //00

            bool iHighest = true;  //01

            bool iLowest = false;  //02

            bool iPcenter = false;  //03






            if (!DA.GetDataList<Curve>(0, iCurves)) { return; }     //  00

            if (!DA.GetData(1, ref iHighest)) return;                //01

            if (!DA.GetData(2, ref iLowest)) return;                //02

            if (!DA.GetData(3, ref iPcenter)) return;                //03








            List<Polyline> myPolys222 = new List<Polyline>();

            for (int i = 0; i < iCurves.Count; i++)
            {

                Polyline iPolyL3;  //polyline to work with

                // iCurves[i + oManStIndex].TryGetPolyline(out iPolyL3);

                iCurves[i].TryGetPolyline(out iPolyL3); //visual studio work around

                myPolys222.Add(iPolyL3);
            }










            /*

    List<Point3d> myHighestPoints = new List<Point3d>();

    List<Point3d> myLowestPoints = new List<Point3d>();

    List<Point3d> myPcenters = new List<Point3d>();
    **/

            List<Point3d> myCheckP = new List<Point3d>();



            if (iHighest)
            {

                for (int i = 0; i < myPolys222.Count; i++)
                {

                    Point3d myhightest = new Point3d(0.0, 0.0, -1000000000);

                    for (int j = 0; j < myPolys222[i].Count; j++)
                    {

                        Point3d checkP = myPolys222[i][j];

                        if (checkP.Z > myhightest.Z)
                        {
                            myhightest = checkP;
                        }
                    }

                    myCheckP.Add(myhightest);
                }
            }






            if (iLowest)
            {

                for (int i = 0; i < myPolys222.Count; i++)
                {

                    Point3d myLowest = new Point3d(0.0, 0.0, 10000000000);

                    for (int j = 0; j < myPolys222[i].Count; j++)
                    {

                        Point3d checkP = myPolys222[i][j];

                        if (checkP.Z < myLowest.Z)
                        {
                            myLowest = checkP;
                        }
                    }

                    myCheckP.Add(myLowest);
                }

            }




            if (iPcenter)
            {

                for (int i = 0; i < myPolys222.Count; i++)
                {
                    Point3d myPcenter = PolylineAverage(myPolys222[i]);     //A Function to get the center of a closed polyline

                    myCheckP.Add(myPcenter);
                }

            }







            /*
                oHighestPoints = myHighestPoints;

                oLowest = myLowestPoints;

                oPCenter = myPcenters;
                */

            // oCheckP = myCheckP;

            DA.SetDataList(0, myCheckP);



        }







        public static Point3d PolylineAverage(Polyline iPolyL)     //A Function to get the center of a closed polyline
        {

            Point3d PCenterT2 = new Point3d(0, 0, 0);


            for (int i = 0; i < iPolyL.Count - 1; i++)

            {
                PCenterT2 = PCenterT2 + iPolyL[i];
            }

            Point3d PCenter3 = PCenterT2 / (iPolyL.Count - 1);


            return PCenter3;
        }
















        /// <summary>
        /// Provides an Icon for the component.
        /// </summary>
        protected override System.Drawing.Bitmap Icon
        {
            get
            {
                //You can add image files to your project resources and access them like this:
                // return Resources.IconForThisComponent;


                //  return null;

                return Resource1.CheckPoints;
            }
        }

        /// <summary>
        /// Gets the unique ID for this component. Do not change this ID after release.
        /// </summary>
        public override Guid ComponentGuid
        {
            get { return new Guid("9aeaa71c-7328-4d33-83bc-8d39853a9422"); }
        }
    }
}