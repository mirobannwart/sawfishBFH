﻿using System;
using System.Collections.Generic;

using Grasshopper.Kernel;
using Rhino.Geometry;

namespace cHRC
{
    public class DynamicTrinagulate : GH_Component
    {
        /// <summary>
        /// Initializes a new instance of the MyComponent3 class.
        /// </summary>
        public DynamicTrinagulate()
          : base("03_Dynamictriangulate", "DynTri",
              "Triangulates input curves nou UV based but dynamic in dependence of the distance between the curves",
              "cHRC", "00 Triangulation")
        {
        }

        /// <summary>
        /// Registers all the input parameters for this component.
        /// </summary>
        protected override void RegisterInputParams(GH_Component.GH_InputParamManager pManager)
        {



            pManager.AddCurveParameter("InputCurves", "IC", "The Design Curves, for example counter curves of a shap or output of InputCurvesFlipped", GH_ParamAccess.list); //00

         

            pManager.AddNumberParameter("DivisionFactor", "DF", "The Divisision Factor", GH_ParamAccess.item, 0.0089);  //01


            pManager.AddIntegerParameter("MinimumDivisionAtStart", "MinDS", "The minimum start division The maximal division at the cures start (Add numberes in a data tree according to the tree of input curves for individual Start numbers)", GH_ParamAccess.item, 1); //02

            pManager.AddIntegerParameter("MaximumDivisionAtStart", "MaxDS", "The maximal division at the cures start(Add numberes in a data tree according to the tree of input curves for individual Start numbers)", GH_ParamAccess.item, 3); //03

            pManager.AddIntegerParameter("MinimumDivision", "MinD", "The minimum division", GH_ParamAccess.item, 2); //04

            pManager.AddIntegerParameter("MaximumDivision", "MaxD", "The maximum division: ", GH_ParamAccess.item, 3); //05






        }

        /// <summary>
        /// Registers all the output parameters for this component.
        /// </summary>
        protected override void RegisterOutputParams(GH_Component.GH_OutputParamManager pManager)
        {

            pManager.AddCurveParameter("ZigZagPolylines", "ZZP", "ZigZag Polylines, you will most likely mot us that", GH_ParamAccess.list); //00

            pManager.AddCurveParameter("TrianglePolylines", "TriP", "Triangular polylines, use this one to go on", GH_ParamAccess.list); //01




        }

        /// <summary>
        /// This is the method that actually does the work.
        /// </summary>
        /// <param name="DA">The DA object is used to retrieve from inputs and store in outputs.</param>
        protected override void SolveInstance(IGH_DataAccess DA)
        {


            List<Curve> iCurves = new List<Curve>();   //00



            double iFactor1 = 0.0089; //01


            int iMinStart = 1; //02

            int iMaxStart = 3; //03




            int iMin = 2; //04

            int iMax = 3; //05










            if (!DA.GetDataList<Curve>(0, iCurves)) { return; } //  00

            if (!DA.GetData(1, ref iFactor1)) return; //01

            if (!DA.GetData(2, ref iMinStart)) return;  //02

            if (!DA.GetData(3, ref iMaxStart)) return;  //03

            if (!DA.GetData(4, ref iMin)) return;  //04

            if (!DA.GetData(5, ref iMax)) return;   //05










            Curve myCurve = iCurves[0];


            double CurveLenght = myCurve.GetLength(0);

            double DivOne0 = CurveLenght * iFactor1;

            int DivOne3 = (int)DivOne0;



            int DivOne4;



            if (DivOne3 < iMinStart)

            {

                DivOne4 = iMinStart;
            }
            else

            {
                DivOne4 = DivOne3;
            }



            int DivOne;


            if (DivOne4 > iMaxStart)

            {

                DivOne = iMaxStart;
            }

            else

            {
                DivOne = DivOne4;
            }









            List<int> myDivs = new List<int>();

            myDivs.Add(DivOne);



            List<bool> myBools = new List<bool>();

            myBools.Add(true);

            myBools.Add(true);


            List<Line> myLines = new List<Line>();



            List<Polyline> myPolyLines = new List<Polyline>();


            List<Polyline> myTriPolyLines = new List<Polyline>();






            for (int i = 0; i < iCurves.Count - 1; i++)
            {


                Curve myCurveOne = iCurves[i];

                Curve myCurveTwo = iCurves[i + 1];







                bool myBool;

                if (myCurveTwo.GetLength(0) < myCurveOne.GetLength(0))
                {
                    myBool = true;
                }
                else
                {
                    myBool = false;
                }






                int myDiv0 = myDivs[myDivs.Count - 1];


                int myDiv1;

                if (myBool)
                {
                    myDiv1 = myDivs[myDivs.Count - 1] - 1;
                }
                else
                {
                    myDiv1 = myDivs[myDivs.Count - 1] + 1;
                }



                if (myDiv1 < iMin)
                {
                    myDiv1 = iMin;
                }


                if (myDiv1 > iMax)
                {
                    myDiv1 = iMax;
                }





                myDivs.Add(myDiv1);




                Point3d[] myPointsOne;
                myCurveOne.DivideByCount(myDiv0, true, out myPointsOne);


                Point3d[] myPointsTwo;
                myCurveTwo.DivideByCount(myDiv1, true, out myPointsTwo);


                // if(myDivs[myDivs.Count - 1] != myDivs[myDivs.Count - 2])

                //    if(1 != 2)


                if (myDivs[myDivs.Count - 1] != myDivs[myDivs.Count - 2])

                {

                    if (myBool)
                    {


                        myBools.Add(true);

                        List<Point3d> myWeavePoints = new List<Point3d>();

                        for (int j = 0; j < myPointsOne.GetLength(0); j++)
                        {

                            myWeavePoints.Add(myPointsOne[j]);

                            if (j < myPointsTwo.GetLength(0))
                            {
                                myWeavePoints.Add(myPointsTwo[j]);
                            }


                        }

                        Polyline myPoly = new Polyline(myWeavePoints);
                        myPolyLines.Add(myPoly);



                        List<Polyline> mySuperTriPolys = TriPolyFromWeavedPoints(myWeavePoints);   //Function to creat triangle polylines from a list of weaved points

                        for (int j = 0; j < mySuperTriPolys.Count; j++)
                        {

                            myTriPolyLines.Add(mySuperTriPolys[j]);


                        }


                    }





                    else

                    {

                        myBools.Add(false);

                        List<Point3d> myWeavePoints = new List<Point3d>();

                        for (int j = 0; j < myPointsTwo.GetLength(0); j++)
                        {

                            myWeavePoints.Add(myPointsTwo[j]);


                            if (j < myPointsOne.GetLength(0))
                            {


                                myWeavePoints.Add(myPointsOne[j]);
                            }





                        }

                        Polyline myPoly = new Polyline(myWeavePoints);
                        myPolyLines.Add(myPoly);




                        List<Polyline> mySuperTriPolys = TriPolyFromWeavedPoints(myWeavePoints);   //Function to creat triangle polylines from a list of weaved points

                        for (int j = 0; j < mySuperTriPolys.Count; j++)
                        {

                            myTriPolyLines.Add(mySuperTriPolys[j]);


                        }



                    }







                }


                else

                {



                    if (myBools[myBools.Count - 1] == true)

                    {

                        myBools.Add(false);

                        List<Point3d> myWeavePoints = new List<Point3d>();

                        for (int j = 0; j < myPointsTwo.GetLength(0); j++)
                        {

                            myWeavePoints.Add(myPointsTwo[j]);


                            if (j < myPointsOne.GetLength(0))
                            {


                                myWeavePoints.Add(myPointsOne[j]);
                            }





                        }

                        Polyline myPoly = new Polyline(myWeavePoints);
                        myPolyLines.Add(myPoly);



                        List<Polyline> mySuperTriPolys = TriPolyFromWeavedPoints(myWeavePoints);   //Function to creat triangle polylines from a list of weaved points

                        for (int j = 0; j < mySuperTriPolys.Count; j++)
                        {

                            myTriPolyLines.Add(mySuperTriPolys[j]);


                        }


                    }


                    else

                    {

                        myBools.Add(true);


                        List<Point3d> myWeavePoints = new List<Point3d>();

                        for (int j = 0; j < myPointsOne.GetLength(0); j++)
                        {

                            myWeavePoints.Add(myPointsOne[j]);

                            if (j < myPointsTwo.GetLength(0))
                            {
                                myWeavePoints.Add(myPointsTwo[j]);
                            }


                        }

                        Polyline myPoly = new Polyline(myWeavePoints);

                        myPolyLines.Add(myPoly);






                        List<Polyline> mySuperTriPolys = TriPolyFromWeavedPoints(myWeavePoints);   //Function to creat triangle polylines from a list of weaved points



                        for (int j = 0; j < mySuperTriPolys.Count; j++)   //Flipping the Polyline if its normal Vec is not similar to the Last Polylines NormalVec
                        {

                            myTriPolyLines.Add(mySuperTriPolys[j]);



                        }



                    }


                }



            }




            List<Polyline> mySuperFlippedPolys = FlipPolyToLastPoly(myTriPolyLines);    //Function to flip polylines acording to the angle of its normal to the normal angle of its predeccesor





            /*
             

            A = myPolyLines;

            oTriPoly = mySuperFlippedPolys;

            */


            DA.SetDataList(0, myPolyLines);


            DA.SetDataList(1, mySuperFlippedPolys);



        }









        public List<Polyline> TriPolyFromWeavedPoints(List<Point3d> myWeavePoints)    //Function to creat triangle polylines from a list of weaved points
        {

            List<Polyline> myTriPolyLines = new List<Polyline>();

            for (int j = 0; j < myWeavePoints.Count - 2; j++)
            {


                if (j % 2 == 0)
                {
                    List<Point3d> TriPoints = new List<Point3d>();

                    TriPoints.Add(myWeavePoints[j]);
                    TriPoints.Add(myWeavePoints[j + 1]);
                    TriPoints.Add(myWeavePoints[j + 2]);
                    TriPoints.Add(myWeavePoints[j]);

                    Polyline myTriPoly = new Polyline(TriPoints);

                    myTriPolyLines.Add(myTriPoly);
                }

                else

                {
                    List<Point3d> TriPoints = new List<Point3d>();


                    TriPoints.Add(myWeavePoints[j]);
                    TriPoints.Add(myWeavePoints[j + 2]);
                    TriPoints.Add(myWeavePoints[j + 1]);
                    TriPoints.Add(myWeavePoints[j]);

                    Polyline myTriPoly = new Polyline(TriPoints);

                    myTriPolyLines.Add(myTriPoly);
                }


            }


            return myTriPolyLines;

        }









        public List<Polyline> FlipPolyToLastPoly(List<Polyline> myPolys)    //Function to flip polylines acording to the angle of its normal to the normal angle of its predeccesor
        {

            List<Polyline> myFlippedPolylines = new List<Polyline>();

            for (int i = 0; i < myPolys.Count; i++)
            {


                if (i == 0)

                {
                    myFlippedPolylines.Add(myPolys[i]);
                }


                else

                {

                    Polyline iPoly0 = myPolys[i];

                    Polyline iPoly1 = myPolys[i - 1];


                    Point3d P0 = iPoly0[0];
                    Point3d P1 = iPoly0[1];
                    Point3d P2 = iPoly0[2];

                    Vector3d myVec1 = P1 - P0;
                    Vector3d myVec2 = P1 - P2;

                    myVec1.Unitize();
                    myVec2.Unitize();

                    Vector3d myCrossV1 = Rhino.Geometry.Vector3d.CrossProduct(myVec1, myVec2);


                    Point3d P00 = myFlippedPolylines[myFlippedPolylines.Count - 1][0];
                    Point3d P11 = myFlippedPolylines[myFlippedPolylines.Count - 1][1];
                    Point3d P22 = myFlippedPolylines[myFlippedPolylines.Count - 1][2];

                    Vector3d myVec3 = P11 - P00;
                    Vector3d myVec4 = P11 - P22;

                    bool myVec33333 = myVec3.Unitize();

                    myVec4.Unitize();



                    Vector3d myCrossV2 = Rhino.Geometry.Vector3d.CrossProduct(myVec3, myVec4);

                    //   myVecs.Add(myCrossV2);



                    double myAngle = Rhino.Geometry.Vector3d.VectorAngle(myCrossV1, myCrossV2);

                    double myDegress = Rhino.RhinoMath.ToDegrees(myAngle);

                    //   myAngles.Add(myDegress);



                    if (myDegress <= 90)
                    {
                        myFlippedPolylines.Add(iPoly0);
                    }

                    else

                    {
                        List<Point3d> myFlippedPoints = new List<Point3d>();

                        myFlippedPoints.Add(iPoly0[3]);
                        myFlippedPoints.Add(iPoly0[2]);
                        myFlippedPoints.Add(iPoly0[1]);
                        myFlippedPoints.Add(iPoly0[0]);

                        Polyline myFlippedPoly = new Polyline(myFlippedPoints);


                        myFlippedPolylines.Add(myFlippedPoly);

                    }

                }


            }

            return myFlippedPolylines;

        }


































        /// <summary>
        /// Provides an Icon for the component.
        /// </summary>
        protected override System.Drawing.Bitmap Icon
        {
            get
            {
                //You can add image files to your project resources and access them like this:
                // return Resources.IconForThisComponent;

                //  return null;

                return Resource1.InputDynamic_Tri;

            }
        }

        /// <summary>
        /// Gets the unique ID for this component. Do not change this ID after release.
        /// </summary>
        public override Guid ComponentGuid
        {
            get { return new Guid("28e39402-ce59-4845-b4d8-56bef81e3af3"); }
        }
    }
}