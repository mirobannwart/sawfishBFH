﻿using System;
using System.Collections.Generic;

using Grasshopper.Kernel;
using Rhino.Geometry;

namespace cHRC
{
    public class PolyLineSnap : GH_Component
    {
        /// <summary>
        /// Initializes a new instance of the MyComponent3 class.
        /// </summary>
        public PolyLineSnap()
          : base("09_PolylineSnap", "polySnap",
              "Snaps vertices of a polyline to a surface of a collection of surfaces if the distance to the closest surface is below a toleranc(SnapTolerance) ",
              "cHRC", "01 Adjust")
        {
        }

        /// <summary>
        /// Registers all the input parameters for this component.
        /// </summary>
        protected override void RegisterInputParams(GH_Component.GH_InputParamManager pManager)
        {

            pManager.AddCurveParameter("Polylines", "PL", "Polylines to Check", GH_ParamAccess.list); //00

            pManager.AddSurfaceParameter("Surface", "Srf", "The Surface to Snap on to", GH_ParamAccess.list);  //01

            pManager.AddNumberParameter("SnapTolerance", "T", "The snap tolerance distance", GH_ParamAccess.item, 200.0);  //02
        }

        /// <summary>
        /// Registers all the output parameters for this component.
        /// </summary>
        protected override void RegisterOutputParams(GH_Component.GH_OutputParamManager pManager)
        {
           pManager.AddCurveParameter("Polylines", "Pl", "The snaped polylines", GH_ParamAccess.list); //00
        }

        /// <summary>
        /// This is the method that actually does the work.
        /// </summary>
        /// <param name="DA">The DA object is used to retrieve from inputs and store in outputs.</param>
        protected override void SolveInstance(IGH_DataAccess DA)
        {




            List<Curve> iPolylines = new List<Curve>();   //00

            List<Surface> iSurfaces = new List<Surface>();   //01

            double iSnapTol = 200; //02



            if (!DA.GetDataList<Curve>(0, iPolylines)) { return; } //  00

            if (!DA.GetDataList(1, iSurfaces)) { return; }  //01

            if (!DA.GetData(2, ref iSnapTol)) return;  //02






            List<Polyline> myPolys222 = new List<Polyline>();

            for (int i = 0; i < iPolylines.Count; i++)
            {

                Polyline iPolyL3;  //polyline to work with

                // iCurves[i + oManStIndex].TryGetPolyline(out iPolyL3);

                iPolylines[i].TryGetPolyline(out iPolyL3); //visual studio work around

                myPolys222.Add(iPolyL3);
            }











            List<Point3d> myTestPoints = new List<Point3d>();

            List<Surface> myTestSurfaces = new List<Surface>();


            List<Polyline> AllmyFinalPolylines = new List<Polyline>();



            for (int i = 0; i < myPolys222.Count; i++)
            {


                List<Point3d> myFinalPoints = new List<Point3d>();


                Polyline iPoints = myPolys222[i];



                for (int j = 0; j < iPoints.Count; j++)
                {
                    // myTestPoints.Add(iPoints[i]);


                    List<Surface> myClosestSurfaces = new List<Surface>();



                    for (int k = 0; k < iSurfaces.Count; k++)
                    {



                        double u;
                        double v;

                        iSurfaces[k].ClosestPoint(iPoints[j], out u, out v);


                        Point3d ClosestPoint = iSurfaces[k].PointAt(u, v);

                        double dist = iPoints[j].DistanceTo(ClosestPoint);

                        if (dist < iSnapTol)
                        {
                            myTestPoints.Add(ClosestPoint);
                            myClosestSurfaces.Add(iSurfaces[k]);
                            myTestSurfaces.Add(iSurfaces[k]);

                        }

                    }




                    if (myClosestSurfaces.Count > 0)

                    {


                        double u;
                        double v;

                        myClosestSurfaces[0].ClosestPoint(iPoints[j], out u, out v);


                        Point3d ClosestPoint = myClosestSurfaces[0].PointAt(u, v);



                        myFinalPoints.Add(ClosestPoint);



                    }

                    else

                    {
                        myFinalPoints.Add(iPoints[j]);

                    }



                }



                //List<Polyline> myPolys = new List<Polyline>();

                if (myFinalPoints.Count > 0)
                {

                    Polyline myPoly = new Polyline(myFinalPoints);

                    //myPolys.Add(myPoly);

                    AllmyFinalPolylines.Add(myPoly);

                }





            }








            /*

            oPolylines = AllmyFinalPolylines;

            // oPoints = myFinalPoints;


            oTestPoints = myTestPoints;

            oTestSurfaces = myTestSurfaces;




            */



            DA.SetDataList(0, AllmyFinalPolylines);






        }

        /// <summary>
        /// Provides an Icon for the component.
        /// </summary>
        protected override System.Drawing.Bitmap Icon
        {
            get
            {
                //You can add image files to your project resources and access them like this:
                // return Resources.IconForThisComponent;

                //  return null;

                return Resource1.PolySnap;

            }
        }

        /// <summary>
        /// Gets the unique ID for this component. Do not change this ID after release.
        /// </summary>
        public override Guid ComponentGuid
        {
            get { return new Guid("b29d67eb-52a1-4d6b-9dcb-097bb8dd95fa"); }
        }
    }
}