﻿using System;
using System.Collections.Generic;

using Grasshopper.Kernel;
using Grasshopper.Kernel.Data;
using Grasshopper.Kernel.Types;

using Rhino.Geometry;


namespace cHRC
{
    public class Component_SideAngles : GH_Component
    {
        /// <summary>
        /// Initializes a new instance of the MyComponent1 class.
        /// </summary>
        public Component_SideAngles()
          : base("Side Angles", "Side Angles",
              "Calculates the side angles of a plate based on the sideliners as curves of the plate and a plane for the visualisation",
              "cHRC", "03 Dimensioning")
        {
        }

        /// <summary>
        /// Registers all the input parameters for this component.
        /// </summary>
        protected override void RegisterInputParams(GH_Component.GH_InputParamManager pManager)
        {


            pManager.AddCurveParameter("Line", "L", "Line data tree Input: The side lines of a plate to calculate the angles of the side cuts. (Angles between top side normal vectoir and side normal vector)", GH_ParamAccess.tree); //00





          //  pManager.AddIntegerParameter("PlaneMethod", "PlaneMethod", "0 for Plane X vec paralell to first pollgon edge, 1 for Plane X vec paralell to the polygons longest edge", GH_ParamAccess.item, 0);  //04


            /*

            pManager.AddNumberParameter("PlaneRotate", "PlaneRotate", "Rotation of the plane arount its Z vector in degrees", GH_ParamAccess.item, 0.0);  //05

            pManager.AddIntegerParameter("FlipPlane", "Fliplane", "Flip the Plane(set Plane Y vector negative)", GH_ParamAccess.item, 0); //06


            
            pManager.AddNumberParameter("moveX", "moveX", "Move the plane along its X vector", GH_ParamAccess.item, 0.0);  //07

            pManager.AddNumberParameter("moveY", "moveY", "Move the plane along its y vector", GH_ParamAccess.item, 0.0);  //08

            pManager.AddNumberParameter("moveZ", "moveZ", "Move the plane along its Z vector", GH_ParamAccess.item, 0.0);  //09

            */

            pManager.AddNumberParameter("DegreePlus", "D°+", "The degree Plus Value is Added to the angle between the normal vectors of the sides, this can be usefull to display the angle correctly for a specific tool as circular saw", GH_ParamAccess.item, 0.0);  //10

            pManager.AddIntegerParameter("Round", "R", "Round the angle result", GH_ParamAccess.item, 1); //11



            //     pManager.AddBooleanParameter("Manual iteration", "Manual iteration", "True to limit the iterations", GH_ParamAccess.item, false);  //01

            pManager.AddIntegerParameter("StartIteration", "Si", "StartIndex if Manual iteration is true", GH_ParamAccess.item, -1); //03

            pManager.AddIntegerParameter("MaxIterations", "Mi", "Maximal Iteration Count if Manuak Itreration is true, should not be higher than Cinput Curve count minus start Iteration  index", GH_ParamAccess.item, -1); //02

          

        }






        /// <summary>
        /// Registers all the output parameters for this component.
        /// </summary>
        protected override void RegisterOutputParams(GH_Component.GH_OutputParamManager pManager)

        {

            pManager.AddNumberParameter("Angles", "A°", "A Tree of angles as numbers in degrees", GH_ParamAccess.tree); //06

            pManager.AddPlaneParameter("Planes", "P", "A tree of planes to visualize the angles", GH_ParamAccess.tree); //05
        }





        /// <summary>
        /// This is the method that actually does the work.
        /// </summary>
        /// <param name="DA">The DA object is used to retrieve from inputs and store in outputs.</param>
        protected override void SolveInstance(IGH_DataAccess DA)
        {






            // List<Curve> iCurves = new List<Curve>();   //00



            GH_Structure<GH_Curve> iCurvesTree = new GH_Structure<GH_Curve>();


         //   bool oManItOn = false;  //01

            int oManIt = 1; //02

            int oManStIndex = 1; //03



         //   int iPlaneMethod = 0; //04


            double iPlaneRot = 0.0; //05


            int iPlaneFlip = 1; //06


            double iMoveX = 0.0; //07

            double iMoveY = 0.0; //08

            double iMoveZ = 0.0; //09

            double iPlusDegree = 0.0; //10

            int iRound = 2; //11

            









            //  if (!DA.GetDataTree<GH_Curve>(0, out iCurves0)) return;   //worked in crazy ways tree structure




            //  if (!DA.GetDataList<Curve>(0, iCurvesTree)) { return; }   //00


            if (!DA.GetDataTree<GH_Curve>(0, out iCurvesTree)) return;    //00






       //     if (!DA.GetData(4, ref iPlaneMethod)) return; //04

/*

            if (!DA.GetData(4, ref iPlaneRot)) return;   //05



            if (!DA.GetData(5, ref iPlaneFlip)) return;  //06



            if (!DA.GetData(6, ref iMoveX)) return;  //07

            if (!DA.GetData(7, ref iMoveY)) return;  //08

            if (!DA.GetData(8, ref iMoveZ)) return;  //09

            */


            if (!DA.GetData(1, ref iPlusDegree)) return;  //10

            if (!DA.GetData(2, ref iRound)) return;  //11




            //   if (!DA.GetData(1, ref oManItOn)) return;  //01

            if (!DA.GetData(3, ref oManStIndex)) return; //03

            if (!DA.GetData(4, ref oManIt)) return;  //02












            // Enable to define the iteration start and the iteration count without being out of range all the time




            int myStartIndex = 0;

            int iteration = 0;



            if (oManStIndex == -1 & oManIt == -1)

            {
                myStartIndex = 0;

                iteration = iCurvesTree.Branches.Count;

                //  iteration = 2;
            }





            if (oManStIndex > -1 & oManIt == -1)

            {

                if (oManStIndex < iCurvesTree.Branches.Count)

                {

                    myStartIndex = oManStIndex;

                    iteration = iCurvesTree.Branches.Count - oManStIndex;

                }


                else

                {

                    myStartIndex = iCurvesTree.Branches.Count - 1;

                    iteration = 1;


                }



            }





            if (oManStIndex == -1 & oManIt > -1)

            {


                if (oManIt < iCurvesTree.Branches.Count)

                {
                    myStartIndex = 0;

                    iteration = oManIt;

                }

                else

                {

                    myStartIndex = 0;

                    iteration = iCurvesTree.Branches.Count;
                }


            }





            if (oManStIndex > -1 & oManIt > -1)

            {


                if (oManStIndex < iCurvesTree.Branches.Count)

                {
                    myStartIndex = oManStIndex;


                    if (oManIt + oManStIndex < iCurvesTree.Branches.Count)

                    {
                        iteration = oManIt;
                    }


                    else

                    {
                        iteration = iCurvesTree.Branches.Count - oManStIndex;
                    }



                }



                else

                {
                    myStartIndex = iCurvesTree.Branches.Count - 1;

                    iteration = 1;

                }



            }


















            ///Convert the Grasshopper Tree Input to a List of List for  a more convenient access


            List<List<Curve>> myListOfListsIcurves = new List<List<Curve>>();



            //    for (int i = 0; i < iCurvesTree.BranchCount; i++)

            for (int i = 0; i < iCurvesTree.Branches.Count; i++)
            {

                List<Curve> myCurves = new List<Curve>();



                //for (int i = 0; i < iCurvesTree.Branches.Count; i++)  //visual studio


                for (int j = 0; j < iCurvesTree.Branches[i].Count; j++)


                {
                    // myCurves.Add(iCurvesTree.Branches(i)[j]);

              //this originall c#gh//   myCurves.Add(iCurvesTree.Branches[i][j]);


                    //visual Studio


                     Curve rhinoCurve = null;


                    GH_Convert.ToCurve(iCurvesTree.Branches[i][j], ref rhinoCurve, 0);

                    myCurves.Add(rhinoCurve);


                     
                }

                myListOfListsIcurves.Add(myCurves);


            }








            List<Plane> allMyTopPlanes = new List<Plane>();

            List<int> allMyIndexes = new List<int>();




            List<Plane> SuperallMySidePlanes = new List<Plane>();


            List<Vector3d> allMyVecNormMain = new List<Vector3d>();

            List<Vector3d> allMyVecSide = new List<Vector3d>();



            List<Point3d> allMySideCenterPoints = new List<Point3d>();



            List<double> allMyAngles = new List<double>();



            List<Plane> allMyTextPlanes = new List<Plane>();





            List<List<double>> myAnglesListList = new List<List<double>>();

            List<List<Plane>> myTextPlanesListList = new List<List<Plane>>();









            //Main loop

            //For each Side and the top side a normal vector is created to measure the angle between side side and top



            for (int i = myStartIndex; i < iteration + myStartIndex; i++)
            {


                allMyIndexes.Add(i);



                List<Curve> myCurveList = myListOfListsIcurves[i];   //the curve list to work with

                myCurveList.Add(myCurveList[0]);



                List<Line> myLines = new List<Line>();



                List<Point3d> myTopPoints3d = new List<Point3d>();  //Start and Endpoints  of the input curves in a List

                List <Point3d> myLowPoints3d = new List<Point3d>();




                for (int j = 0; j < myCurveList.Count; j++) //Add Start and Endpoints of the input curves in a List 
                {

                    Point3d St = myCurveList[j].PointAtLength(0.0);

                    Point3d End = myCurveList[j].PointAtLength(myCurveList[j].GetLength());


                    Line theLine = new Line(St, End);

                    myLines.Add(theLine);



                    Point3d myTopP = theLine.PointAtLength(theLine.Length);

                    Point3d myLowP = theLine.PointAtLength(0.0);

                    myTopPoints3d.Add(myTopP);

                    myLowPoints3d.Add(myLowP);

                }





                Polyline myTopPoly = new Polyline(myTopPoints3d);   //The top Polyline

                //myPolylinesTop.Add(myTopPoly);


                Polyline myLowPoly = new Polyline(myLowPoints3d);

                //myPolylinesLow.Add(myLowPoly);



                Point3d myCenterTop = PolylineAverage(myTopPoly);  //The top Polyline centerpoint







                Plane myTopPlane = new Plane(myCenterTop, myLowPoints3d[3] - myLowPoints3d[2], (myCenterTop - myTopPoints3d[2]));   //The top Plane (Z Axis is the top normal) 

                allMyTopPlanes.Add(myTopPlane);                                                                                     // (Cross product would also work...)


                Vector3d myNormal = myTopPlane.ZAxis * -1; //Top Normal flip to down for measuring the angle to the side normal

                allMyVecNormMain.Add(myNormal);








                int iPlaneFlip2;


                if (iPlaneFlip == 0)

                {
                    iPlaneFlip2 = -1;
                }

                else

                {
                    iPlaneFlip2 = 1;
                }






                List<Plane> allSidePlanes = new List<Plane>();

                List<Vector3d> mySideVecs = new List<Vector3d>();







                List<double> myAngles = new List<double>();


                List<Plane> myTextPlanes = new List<Plane>();







                // Calculate the side normal vectors



                for (int j = 0; j < myLines.Count - 1; j++)
                {




                   // The Points of one side

                    List<Point3d> oneSidepoints = new List<Point3d>();

                    oneSidepoints.Add(myLowPoints3d[j + 0]);

                    oneSidepoints.Add(myLowPoints3d[j + 1]);

                    oneSidepoints.Add(myTopPoints3d[j + 1]);

                    oneSidepoints.Add(myTopPoints3d[j + 0]);




                    //the side Centerpoint

                    Point3d mySideCenterp = PointAverage(oneSidepoints);

                    allMySideCenterPoints.Add(mySideCenterp);


                    // A Side Plane, Z Axis is Noprmal of the side, (Cross product would also work...)

                    Plane mySidePl = new Plane(mySideCenterp, oneSidepoints[1] - oneSidepoints[0], oneSidepoints[3] - oneSidepoints[0]);








                    allSidePlanes.Add(mySidePl);

                    SuperallMySidePlanes.Add(mySidePl);


                    Vector3d sideVec = mySidePl.ZAxis;

                    mySideVecs.Add(sideVec);

                    allMyVecSide.Add(sideVec);




                    //Get the Angle between Top and Side Vec

                    double myAngle = Vector3d.VectorAngle(myNormal, sideVec);

                    double myAngleDegree = Rhino.RhinoMath.ToDegrees(myAngle);   //get degrees



                    double myAngleDegreePlus = myAngleDegree + iPlusDegree; //System.Math.Round(myAngleDegree, oRound);   // Add a Value per Input, is relevant for different machines(90 degree cut can be displayed as 0 degree on some mnachines...)

                    double myAngleDegreePlusRoundet = System.Math.Round(myAngleDegreePlus, iRound);    //round the result 



                    allMyAngles.Add(myAngleDegreePlusRoundet);

                    myAngles.Add(myAngleDegreePlusRoundet);






                    // Create the plane For Displaying the Side Angles



                    Vector3d v1 = myTopPoints3d[j] - myTopPoints3d[j + 1];

                    Point3d mpTop = myTopPoints3d[j] + v1 * -0.5;





                    Vector3d myYvec = myCenterTop - mpTop;



                    Plane myTextPl0 = new Plane(mpTop, mySidePl.XAxis, myYvec);



                    Point3d myMovedCenter = mpTop + myTextPl0.XAxis * iMoveX + myTextPl0.YAxis * iMoveY + myTextPl0.ZAxis * iMoveZ;







                    Plane myTextPl = new Plane(myMovedCenter, mySidePl.XAxis, myYvec * iPlaneFlip2);


                    double myRadians = Rhino.RhinoMath.ToRadians(iPlaneRot);

                    myTextPl.Rotate(myRadians, myTopPlane.ZAxis);



                    allMyTextPlanes.Add(myTextPl);

                    myTextPlanes.Add(myTextPl);




                }







                myAnglesListList.Add(myAngles);


                myTextPlanesListList.Add(myTextPlanes);





















                /*



                      List<Plane> myPlanesChose = new List<Plane>();


                      Plane myTopPlane0 = new Plane(myCenterTop, myLowPoints3d[3] - myLowPoints3d[2], (myCenterTop - myTopPoints3d[2]) * iPlaneFlip2);

                      Vector3d myNormalVec = myTopPlane0.ZAxis;


                      myPlanesChose.Add(myTopPlane0);


                      Plane myTopPlaneLongestX = new Plane(myCenterTop, myLongestX, myAdjacantY);

                      myPlanesChose.Add(myTopPlaneLongestX);





                      Plane myTopPlane1 = myPlanesChose[iPlaneMethod];




                      Point3d myMovedCenter = myCenterTop + myTopPlane1.XAxis * iMoveX + myTopPlane1.YAxis * iMoveY + myNormalVec * iMoveZ;


                      Plane myTopPlane = new Plane(myMovedCenter, myTopPlane1.XAxis, myTopPlane1.YAxis);


                      double myRadians = Rhino.RhinoMath.ToRadians(iPlaneRot);

                      myTopPlane.Rotate(myRadians, myTopPlane.ZAxis);


                      allMyTopPlanes.Add(myTopPlane);







                */








            }












            Grasshopper.DataTree<double> myAnglesTree = new Grasshopper.DataTree<double>();        //ListofLists to Tree for the Output


            for (int i = 0; i < myAnglesListList.Count; i++)
            {

                int ListLenght333 = myAnglesListList[i].Count;

                for (int j = 0; j < ListLenght333; j++)
                {

                    myAnglesTree.Add(myAnglesListList[i][j], new GH_Path(i));

                    //myFinalPointsTree.Add(mySuperPoints[i][j], new GH_Path(i));
                }

            }







            Grasshopper.DataTree<Plane> myTextPlanesTree = new Grasshopper.DataTree<Plane>();        //ListofLists to Tree for the Output


            for (int i = 0; i < myTextPlanesListList.Count; i++)
            {

                int ListLenght333 = myTextPlanesListList[i].Count;

                for (int j = 0; j < ListLenght333; j++)
                {

                    myTextPlanesTree.Add(myTextPlanesListList[i][j], new GH_Path(i));

                    //myFinalPointsTree.Add(mySuperPoints[i][j], new GH_Path(i));
                }

            }


            DA.SetDataTree(0, myAnglesTree);


            DA.SetDataTree(1, myTextPlanesTree);

           








            /*



            oAnglesTree = myAnglesTree;

            oTextplaneTree = myTextPlanesTree;














            oAllMyTopPlanes = allMyTopPlanes;


            oAllmyIndexes = allMyIndexes;




            oAllMyVecNormMaim = allMyVecNormMain;


            oSuperallMySidePlanes = SuperallMySidePlanes;


            oAllMySideCenterPoints = allMySideCenterPoints;


            oAllMyVecSide = allMyVecSide;




            oAllMyTextPlanes = allMyTextPlanes;









    */






        }

















        public static Point3d PointAverage(List<Point3d> iPolyL)   // A function to get the Average(center) of a List of Points
        {

            Point3d PCenterT2 = new Point3d(0, 0, 0);


            for (int i = 0; i < iPolyL.Count; i++)

            {
                PCenterT2 = PCenterT2 + iPolyL[i];
            }

            Point3d PCenter3 = PCenterT2 / (iPolyL.Count);


            return PCenter3;
        }








        public static Point3d PolylineAverage(Polyline iPolyL)   // A function to get the Average(center) of a closed curve. The last point is not taken it ist on the position of the first
        {

            Point3d PCenterT2 = new Point3d(0, 0, 0);


            for (int i = 0; i < iPolyL.Count - 1; i++)

            {
                PCenterT2 = PCenterT2 + iPolyL[i];
            }

            Point3d PCenter3 = PCenterT2 / (iPolyL.Count - 1);


            return PCenter3;
        }






        /// <summary>
        /// Provides an Icon for the component.
        /// </summary>
        protected override System.Drawing.Bitmap Icon
        {
            get
            {
                //You can add image files to your project resources and access them like this:
                // return Resources.IconForThisComponent;

                // return null;



                return Resource1.sideangles;
            }
        }

        /// <summary>
        /// Gets the unique ID for this component. Do not change this ID after release.
        /// </summary>
        public override Guid ComponentGuid
        {
            get { return new Guid("6a23ffe9-8898-4734-b67d-d558fa37fda6"); }
        }
    }
}