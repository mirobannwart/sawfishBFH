﻿using System;
using System.Collections.Generic;

using Grasshopper.Kernel;
using Rhino.Geometry;

namespace cHRC
{
    public class MyComponent2 : GH_Component
    {
        /// <summary>
        /// Initializes a new instance of the MyComponent2 class.
        /// </summary>
        public MyComponent2()
          : base("02_FlipInputCurves", "FlipIC",
              "Generates flipped Curves on input curves. Use for Dynamic Triangulation ",
              "cHRC", "00 Triangulation")
        {
        }

        /// <summary>
        /// Registers all the input parameters for this component.
        /// </summary>
        protected override void RegisterInputParams(GH_Component.GH_InputParamManager pManager)
        {





            pManager.AddCurveParameter("InputCurves", "IC", "The Design Curves, normally referenced in Rhino (3 in a list) multiple Lists is possible", GH_ParamAccess.list); //00

   


            pManager.AddNumberParameter("DivisionFactor", "DF", "The Divisision Factor", GH_ParamAccess.item, 0.03);  //01



            pManager.AddIntegerParameter("MinimumDivisionCount", "MinDC", "The minimal division count", GH_ParamAccess.item, 3); //02

            pManager.AddIntegerParameter("MaximumDivisioCount", "MaxDC", "Maximal Iteration Count if larger than -1", GH_ParamAccess.item, 4); //03

            pManager.AddIntegerParameter("NurbsDegree", "D", "The Interpolated NurbsCurve Degree", GH_ParamAccess.item, 3); //04

            pManager.AddIntegerParameter("KnotStyle", "K", "The KnotStyle: ", GH_ParamAccess.item, 1); //05







        }

        /// <summary>
        /// Registers all the output parameters for this component.
        /// </summary>
        protected override void RegisterOutputParams(GH_Component.GH_OutputParamManager pManager)
        {

            pManager.AddPointParameter("Points", "P", "The Points, better use the curves directly", GH_ParamAccess.list); //00

            pManager.AddCurveParameter("FlippedInputCurves", "FC", "The Flipped Input Curves", GH_ParamAccess.list); //01



        }

        /// <summary>
        /// This is the method that actually does the work.
        /// </summary>
        /// <param name="DA">The DA object is used to retrieve from inputs and store in outputs.</param>
        protected override void SolveInstance(IGH_DataAccess DA)
        {



            List<Curve> iCurves = new List<Curve>();   //00



            double iFactor = 0.03; //01


            int iMin = 3; //02

            int iMax = 4; //03




            int iDegree = 3; //04

            int KnotStyle = 1; //05










            if (!DA.GetDataList<Curve>(0, iCurves)) { return; } //  00



            if (!DA.GetData(1, ref iFactor)) return; //01



            if (!DA.GetData(2, ref iMin)) return;  //02



            if (!DA.GetData(3, ref iMax)) return;  //03



            if (!DA.GetData(4, ref iDegree)) return;  //04




            if (!DA.GetData(5, ref KnotStyle)) return;   //05


           



















            double myLength0 = 0;


            for (int i = 0; i < iCurves.Count; i++)
            {
                //double myLength = iCurves[i].GetLength();   //here



                NurbsCurve myCureve000 = iCurves[i].ToNurbsCurve();


                double myLength = myCureve000.GetLength();

                myLength0 = (myLength0 + myLength);

            }



            double myAverage = myLength0 / iCurves.Count;


            double myCount0 = myAverage * iFactor;

            //int myCount = myCount0.ToInt();

            int myCount3 = Convert.ToInt32(myCount0);



            if (myCount3 <= iMin)

            {
                myCount3 = iMin;
            }

            if (myCount3 >= iMax)

            {
                myCount3 = iMax;
            }





            List<Point3d> myPoints = new List<Point3d>();


            List<Curve> myFinalCurves = new List<Curve>();



            for (int i = 0; i < myCount3 + 1; i++)
            {

                List<Point3d> myCurvePoints = new List<Point3d>();



                for (int j = 0; j < iCurves.Count; j++)

                {



                    double myCurveLength = iCurves[j].GetLength();

                    Point3d myPoint = iCurves[j].PointAtLength(myCurveLength / myCount3 * i);

                    myPoints.Add(myPoint);

                    myCurvePoints.Add(myPoint);

                }


                List<CurveKnotStyle> myCurveKnotStyles = new List<CurveKnotStyle>();

                CurveKnotStyle myKnotUniform = Rhino.Geometry.CurveKnotStyle.Uniform;
                myCurveKnotStyles.Add(myKnotUniform);

                CurveKnotStyle myKnotChord = Rhino.Geometry.CurveKnotStyle.Chord;
                myCurveKnotStyles.Add(myKnotChord);

                CurveKnotStyle myKnotChordSquareRoot = Rhino.Geometry.CurveKnotStyle.ChordSquareRoot;
                myCurveKnotStyles.Add(myKnotChordSquareRoot);

                CurveKnotStyle myKnotUniformPeriodic = Rhino.Geometry.CurveKnotStyle.UniformPeriodic;
                myCurveKnotStyles.Add(myKnotUniformPeriodic);



                CurveKnotStyle myKnotChordPeriodic = Rhino.Geometry.CurveKnotStyle.ChordPeriodic;
                myCurveKnotStyles.Add(myKnotChordPeriodic);

                CurveKnotStyle myKnotChordSquareRootPeriodic = Rhino.Geometry.CurveKnotStyle.ChordSquareRootPeriodic;
                myCurveKnotStyles.Add(myKnotChordSquareRootPeriodic);







                //  CurveKnotStyle myKnot  = Rhino.Geometry.CurveKnotStyle.Chord;



                Curve myCurveFinal = Rhino.Geometry.Curve.CreateInterpolatedCurve(myCurvePoints, iDegree, myCurveKnotStyles[KnotStyle]);

                myFinalCurves.Add(myCurveFinal);





            }



            /*

            oTestAv = myCount3;

            oTestPoints = myPoints;

            oCurves = myFinalCurves;


            */


            DA.SetDataList(0, myPoints);


            DA.SetDataList(1, myFinalCurves);













        }

        /// <summary>
        /// Provides an Icon for the component.
        /// </summary>
        protected override System.Drawing.Bitmap Icon
        {
            get
            {
                //You can add image files to your project resources and access them like this:
                // return Resources.IconForThisComponent;
                // return null;


                return Resource1.InputCurves_Flip;

            }
        }

        /// <summary>
        /// Gets the unique ID for this component. Do not change this ID after release.
        /// </summary>
        public override Guid ComponentGuid
        {
            get { return new Guid("16f7aa75-f98c-4873-94d9-9abfe5942f2a"); }
        }
    }
}