﻿using System;
using System.Collections.Generic;

using Grasshopper.Kernel;
using Rhino.Geometry;

namespace cHRC
{
    public class NakedEdges : GH_Component
    {
        /// <summary>
        /// Initializes a new instance of the MyComponent1 class.
        /// </summary>
        public NakedEdges()
          : base("05_Naked Edges", "NKE",
              "Returns a lis of Naked LineSegments, the naked edges of multiple adjacent polylines",
              "cHRC", "01 TopPolyline")
        {
            
        }

        /// <summary>
        /// Registers all the input parameters for this component.
        /// </summary>
        protected override void RegisterInputParams(GH_Component.GH_InputParamManager pManager)
        {


         

            pManager.AddCurveParameter("Polylines", "Pl", "Polylines to get the naked edges , as list", GH_ParamAccess.list); //00

            pManager.AddNumberParameter("CheckDist", "CD", "Checkdistance", GH_ParamAccess.item, 0.01); //01
        }

        /// <summary>
        /// Registers all the output parameters for this component.
        /// </summary>
        protected override void RegisterOutputParams(GH_Component.GH_OutputParamManager pManager)
        {

            pManager.AddCurveParameter("Naked Edges", "NE", "The naked Edges as a lis of lines", GH_ParamAccess.list); //02
        }

        /// <summary>
        /// This is the method that actually does the work.
        /// </summary>
        /// <param name="DA">The DA object is used to retrieve from inputs and store in outputs.</param>
        protected override void SolveInstance(IGH_DataAccess DA)
        {



            List<Curve> iCurves = new List<Curve>();   //00

            double iCheckDist = 0.01;  //01





            if (!DA.GetDataList<Curve>(0, iCurves)) { return; } //  0

            if (!DA.GetData(1, ref iCheckDist)) return;  //11










            List<Polyline> allMyPolylines = new List<Polyline>();



            for (int i = 0; i < iCurves.Count; i++)
            {


                Polyline iPolyL3;  //polyline to work with

                iCurves[i].TryGetPolyline(out iPolyL3); //visual studio work around

                allMyPolylines.Add(iPolyL3);

            }



                List<Line> NakedLines = new List<Line>();

            double myCheckDist = iCheckDist;

            //Geting naked lines

            for (int i = 0; i < allMyPolylines.Count; i++)
            {
                Polyline myPl = allMyPolylines[i];



                for (int j = 0; j < myPl.Count - 1; j++)
                {

                    Line myLine = new Line(myPl[j], myPl[j + 1]);

                    Point3d stP = myLine.From;

                    Point3d enP = myLine.To;

                    Point3d mp = (stP + enP) / 2;

                    List<int> CheckList = new List<int>();


                    for (int k = 0; k < allMyPolylines.Count; k++)
                    {
                        Point3d CP = allMyPolylines[k].ClosestPoint(mp);

                        double myDist = mp.DistanceTo(CP);

                        if (myDist < myCheckDist)
                        {
                            CheckList.Add(1);
                        }
                    }


                    if (CheckList.Count < 2)

                    {

                        NakedLines.Add(myLine);

                    }







                }






            }



          //  A = NakedLines;


            DA.SetDataList(0, NakedLines);




        }

        /// <summary>
        /// Provides an Icon for the component.
        /// </summary>
        protected override System.Drawing.Bitmap Icon
        {
            get
            {
                //You can add image files to your project resources and access them like this:
                // return Resources.IconForThisComponent;
                //  return null;

                return Resource1.Naked_Edges;
            }
        }

        /// <summary>
        /// Gets the unique ID for this component. Do not change this ID after release.
        /// </summary>
        public override Guid ComponentGuid
        {
            get { return new Guid("70c7ad3e-c6d9-4641-b5e0-9ba91493c205"); }
        }
    }
}