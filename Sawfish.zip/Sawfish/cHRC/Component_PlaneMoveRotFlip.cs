﻿using System;
using System.Collections.Generic;

using Grasshopper.Kernel;
using Rhino.Geometry;

namespace cHRC
{
    public class Component_PlaneMoveRotFlip : GH_Component
    {
        /// <summary>
        /// Initializes a new instance of the MyComponent1 class.
        /// </summary>
        public Component_PlaneMoveRotFlip()
          : base("PlaneMoveRotFlip", "PlaneMoveRotFlip",
              "move, Rotate or Flip a a plane on itself",
              "cHRC", "04 Visualize Text")
        {
        }

        /// <summary>
        /// Registers all the input parameters for this component.
        /// </summary>
        protected override void RegisterInputParams(GH_Component.GH_InputParamManager pManager)
        {




            pManager.AddPlaneParameter("Plane", "Pl", "Rotation of the plane arount its Z vector in degrees", GH_ParamAccess.item );  //00



            pManager.AddNumberParameter("Rotate", "R", "Rotation of the plane arount its Z vector in degrees", GH_ParamAccess.item, 0.0);  //01

            pManager.AddIntegerParameter("FlipPlane", "FP", "Flip the Plane(set Plane Y vector negative)", GH_ParamAccess.item, 0); //02



            pManager.AddNumberParameter("moveX", "mX", "Move the plane along its X vector", GH_ParamAccess.item, 0.0);  //03

            pManager.AddNumberParameter("moveY", "mY", "Move the plane along its y vector", GH_ParamAccess.item, 0.0);  //04

            pManager.AddNumberParameter("moveZ", "mZ", "Move the plane along its Z vector", GH_ParamAccess.item, 0.0);  //05



            pManager.AddVectorParameter("PlaneXvec", "XV", "Defines the plane X vector globally", GH_ParamAccess.item, default); //05



        }



        /// <summary>
        /// Registers all the output parameters for this component.
        /// </summary>
        protected override void RegisterOutputParams(GH_Component.GH_OutputParamManager pManager)
        {

            pManager.AddPlaneParameter("Plane", "P", "The moved, fliped or rotated plane", GH_ParamAccess.item);  //00

        }

        /// <summary>
        /// This is the method that actually does the work.
        /// </summary>
        /// <param name="DA">The DA object is used to retrieve from inputs and store in outputs.</param>
        protected override void SolveInstance(IGH_DataAccess DA)
        {




            Plane iPlane = new Plane(); //00


            double iPlaneRot = 0.0; //01


            int iPlaneFlip = 0; //02


            double iMoveX = 0.0; //03

            double iMoveY = 0.0; //04

            double iMoveZ = 0.0; //05


            Vector3d Xglobal = new Vector3d(20,20,20);









            if (!DA.GetData(0, ref iPlane)) return;  //00



 


            if (!DA.GetData(1, ref iPlaneRot)) return;   //01



            if (!DA.GetData(2, ref iPlaneFlip)) return;  //02



            if (!DA.GetData(3, ref iMoveX)) return;  //03

            if (!DA.GetData(4, ref iMoveY)) return;  //04

            if (!DA.GetData(5, ref iMoveZ)) return;  //05

            if (!DA.GetData(6, ref Xglobal)) return;  //05










            int iPlaneFlip2;


            if (iPlaneFlip == 1)

            {
                iPlaneFlip2 = -1;
            }

            else

            {
                iPlaneFlip2 = 1;
            }





                 // Plane 1 with X vector globally defined

                Point3d myMovedCenterG = iPlane.Origin + iPlane.XAxis * iMoveX + iPlane.YAxis * iMoveY + iPlane.ZAxis * iMoveZ;   //move the centert in X  Y  Z


                Plane mPlane2G = new Plane(myMovedCenterG, Xglobal, iPlane.YAxis * iPlaneFlip2);     // moved plane with the  new center and flipe if iPlaneFlip is 1


                double myRadiansG = Rhino.RhinoMath.ToRadians(iPlaneRot);    //For plane rotation:  degrees to radians                   

                mPlane2G.Rotate(myRadiansG, iPlane.ZAxis);  //rotate the plane




            // Plane 2 with X and Y Vector from the input plane

            Point3d myMovedCenter = iPlane.Origin + iPlane.XAxis * iMoveX + iPlane.YAxis * iMoveY + iPlane.ZAxis * iMoveZ;


                Plane mPlane2 = new Plane(myMovedCenter, iPlane.XAxis, iPlane.YAxis * iPlaneFlip2);


                double myRadians = Rhino.RhinoMath.ToRadians(iPlaneRot);

                mPlane2.Rotate(myRadians, iPlane.ZAxis);




            // Output Plane 1 or 2 according to Input ( if a vector which is not 0,0,0 is inputetd to define the planes X vexc globally the Plane 2 will be outputeted, (globally defined X)) 

           if (Xglobal.IsUnitVector)

            {

                DA.SetData(0, mPlane2G);

            }

           else

            {

                DA.SetData(0, mPlane2);

            }





                //  oPlane = mPlane2;




               // DA.SetData(0, mPlane2);



        }

        /// <summary>
        /// Provides an Icon for the component.
        /// </summary>
        protected override System.Drawing.Bitmap Icon
        {
            get
            {
                //You can add image files to your project resources and access them like this:
                // return Resources.IconForThisComponent;

                // return null;

                return Resource1.Planetransform;
            }
        }

        /// <summary>
        /// Gets the unique ID for this component. Do not change this ID after release.
        /// </summary>
        public override Guid ComponentGuid
        {
            get { return new Guid("c98af052-5931-4ff2-97de-9302281ad27a"); }
        }
    }
}
 