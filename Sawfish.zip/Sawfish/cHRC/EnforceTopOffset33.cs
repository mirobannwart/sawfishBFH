﻿using System;
using System.Collections.Generic;

using Grasshopper.Kernel;
using Rhino.Geometry;

namespace cHRC
{
    public class Component_EnforceTopOffset : GH_Component
    {
        /// <summary>
        /// Initializes a new instance of the MyComponent1 class.
        /// </summary>
        public Component_EnforceTopOffset()
          : base("01_EnforceTop", "EnforceTop",
              "creates a top polyline of on each side of a polygon which can be used to make a enforcement beam without complex node cuts",
              "cHRC", "01 TopPolyline")
        {
        }

        /// <summary>
        /// Registers all the input parameters for this component.
        /// </summary>
        protected override void RegisterInputParams(GH_Component.GH_InputParamManager pManager)
        {




            pManager.AddCurveParameter("Polylines", "Pl", "Polyline Input for the offset, as list", GH_ParamAccess.list); //00



            pManager.AddNumberParameter("Width", "W", "The beam width  in mm", GH_ParamAccess.item, 58);  //04

            pManager.AddNumberParameter("Lenght", "L", "Global Lenght of the beams if NodeCutPos is 0  (beam centered on the polyline segment)", GH_ParamAccess.item, 200);  //09


            pManager.AddIntegerParameter("NodeCutPos", "N", " 1 or 0, defines if the beam is cut as close ass possible ath the node or if it has a defined lenght, centered on the polygon edge center", GH_ParamAccess.item, 0);  //07


            pManager.AddNumberParameter("BackDist", "B", "offset back from node closest position if NodeCutPos is 1 (as close as possible to the node) ", GH_ParamAccess.item, 0);  //08



            pManager.AddBooleanParameter("OffsetDirection", "OD", "Defines the offset direction; local Z positiv or negaitv ", GH_ParamAccess.item, true);  //06



            pManager.AddNumberParameter("OffsetTol", "OT", "Intersection Check tolerance, dont think about keep on zero try to increase when something does not work, its to check the offset direction by intersections", GH_ParamAccess.item, 0.0000);  //05



            // pManager.AddBooleanParameter("Manual iteration", "Manual iteration", "True to limit the iterations", GH_ParamAccess.item, false);  //01


            pManager.AddIntegerParameter("StartIteration", "SI", "Start Index if larger than -1", GH_ParamAccess.item, -1); //03


            pManager.AddIntegerParameter("MaxIterations", "MI", "Maximal Iteration count if larger than -1", GH_ParamAccess.item, -1); //02



        }






        /// <summary>
        /// Registers all the output parameters for this component.
        /// </summary>
        protected override void RegisterOutputParams(GH_Component.GH_OutputParamManager pManager)

        {
            pManager.AddCurveParameter("TopPolyline", "TPl", "The top polylineof the enforcement beam with a easy 90 degree cut node situation", GH_ParamAccess.list);  //00
        }


        /// <summary>
        /// This is the method that actually does the work.
        /// </summary>
        /// <param name="DA">The DA object is used to retrieve from inputs and store in outputs.</param>
        protected override void SolveInstance(IGH_DataAccess DA)


        {



            List<Curve> iCurves = new List<Curve>();   //00



            double oWidth = 58; //04

            double oClimbLenght2 = 266; //09



            int oCornerMiddle = 0; //07  

            double oClimbBack = 0; //08

  

            bool oOffsetDirection = true;  //06

            double oOffsetIntersectChecTol = 0.0000; //05





            int oManStIndex = 1; //03

            int oManIt = 1; //02

        





            if (!DA.GetDataList<Curve>(0, iCurves)) { return; } //  0



            if (!DA.GetData(1, ref oWidth)) return; //04



            if (!DA.GetData(2, ref oClimbLenght2)) return;  //09



            if (!DA.GetData(3, ref oCornerMiddle)) return;  //07



            if (!DA.GetData(4, ref oClimbBack)) return;  //08




            if (!DA.GetData(5, ref oOffsetDirection)) return;   //06


            if (!DA.GetData(6, ref oOffsetIntersectChecTol)) return;   //05

         


            if (!DA.GetData(7, ref oManStIndex)) return; //03

            if (!DA.GetData(8, ref oManIt)) return;  //02








            // Enable to define the iteration start and the iteration count without being out of range all the time


            int myStartIndex = 0;

            int iteration = 0;



            if (oManStIndex == -1 & oManIt == -1)

            {
                myStartIndex = 0;

                iteration = iCurves.Count;

                //  iteration = 2;
            }




            if (oManStIndex > -1 & oManIt == -1)

            {

                if (oManStIndex < iCurves.Count)

                {

                    myStartIndex = oManStIndex;

                    iteration = iCurves.Count - oManStIndex;

                }

                else

                {

                    myStartIndex = iCurves.Count - 1;

                    iteration = 1;

                }

            }



            if (oManStIndex == -1 & oManIt > -1)

            {


                if (oManIt < iCurves.Count)

                {
                    myStartIndex = 0;

                    iteration = oManIt;

                }

                else

                {

                    myStartIndex = 0;

                    iteration = iCurves.Count;
                }


            }




            if (oManStIndex > -1 & oManIt > -1)

            {

                if (oManStIndex < iCurves.Count)

                {
                    myStartIndex = oManStIndex;


                    if (oManIt + oManStIndex < iCurves.Count)

                    {
                        iteration = oManIt;
                    }


                    else

                    {
                        iteration = iCurves.Count - oManStIndex;
                    }


                }



                else

                {
                    myStartIndex = iCurves.Count - 1;

                    iteration = 1;

                }


            }






            List<Point3d> pCenters = new List<Point3d>();

           // List<Point3d> AlloKoffsets = new List<Point3d>();

            List<Polyline> AllPolylines = new List<Polyline>();

            List<Polyline> AllBeamPolylines = new List<Polyline>();


            List<Polyline> AllClimbPolylines = new List<Polyline>();

            List<Polyline> AllClimbPolylinesMP = new List<Polyline>();





            // Main Loop


            for (int i = 0; i < iteration; i++)                 
            {




                Polyline iPolyL;  //Polyline to work with




                iCurves[i + myStartIndex].TryGetPolyline(out iPolyL);



                Point3d PCenter = PolylineAverage(iPolyL);

                pCenters.Add(PCenter);




                List<Point3d> OkOffset = OKpointOffset(iPolyL, oWidth, PCenter, oOffsetIntersectChecTol, oOffsetDirection);   //offset the triangle points in theb bisecting angle . It necesarx to define the max possible length of the enforce beams


                /*

                for (int j = 0; j < OkOffset.Count; j++)

                {
                    AlloKoffsets.Add(OkOffset[j]);
                }

                */

                OkOffset.Add(OkOffset[0]); //Ad the first point at the end of the list for a closed polyline





                //Calculate the enforce beam polyline points based on the offseted triangle points


                for (int j = 0; j < OkOffset.Count - 1; j++)

                {


                    List<Point3d> OKClimb = new List<Point3d>();



                    //Two cases: global lenghts or as close as possible at the node:


                    if (oCornerMiddle == 1)


                    {

                        // as close as possible at the nbode:


                        Line myLine = new Line(iPolyL[j], iPolyL[j + 1]);


                        double myCP1t = myLine.ClosestParameter(OkOffset[j]);

                        Point3d myCP1 = myLine.PointAt(myCP1t);


                        double myCP2t = myLine.ClosestParameter(OkOffset[j + 1]);

                        Point3d myCP2 = myLine.PointAt(myCP2t);



                        Vector3d v1 = iPolyL[j] - iPolyL[j + 1];

                        v1.Unitize();



                        Vector3d v2 = v1 * -1;






                        Point3d myFinalClimb0 = myCP1 + v2 * oClimbBack; //  //Move the points back from the position as close as possible at the node in a distance from a input parameter

                        Point3d myFinalClimb1 = myCP2 + v1 * oClimbBack; //

                        Point3d myFinalClimb2 = OkOffset[j + 1] + v1 * oClimbBack;

                        Point3d myFinalClimb3 = OkOffset[j] + v2 * oClimbBack;






                        OKClimb.Add(myFinalClimb0);

                        OKClimb.Add(myFinalClimb1);

                        OKClimb.Add(myFinalClimb2);

                        OKClimb.Add(myFinalClimb3);

                        OKClimb.Add(myFinalClimb0);




                    }

                    else


                    {


                        //with global length and centered on the polyline edge middle point


                        Vector3d v3 = iPolyL[j + 1] - iPolyL[j];


                        Vector3d v3U = iPolyL[j + 1] - iPolyL[j];

                        v3U.Unitize();


                        Point3d myMP1 = iPolyL[j] + v3 / 2;


                        Line myLineOff = new Line(OkOffset[j], OkOffset[j + 1]);

                        double myCPMPt = myLineOff.ClosestParameter(myMP1);

                        Point3d myCPMP = myLineOff.PointAt(myCPMPt);






                        Point3d myFinalClimb5 = myMP1 + v3U * -1 * oClimbLenght2 / 2;

                        Point3d myFinalClimb6 = myMP1 + v3U * oClimbLenght2 / 2;

                        Point3d myFinalClimb7 = myCPMP + v3U * oClimbLenght2 / 2;

                        Point3d myFinalClimb8 = myCPMP + v3U * -1 * oClimbLenght2 / 2;






                        OKClimb.Add(myFinalClimb5);

                        OKClimb.Add(myFinalClimb6);

                        OKClimb.Add(myFinalClimb7);

                        OKClimb.Add(myFinalClimb8);

                        OKClimb.Add(myFinalClimb5);




                    }




                    Polyline myPolyL22 = new Polyline(OKClimb);   // New polyline from the calculated points, in OKClimb are either the points for as close to the node as possible or the points with global lenght



                    AllClimbPolylines.Add(myPolyL22);



                }



            }


            

                


            DA.SetDataList(0, AllClimbPolylines);


        }







        public static Point3d PolylineAverage(Polyline iPolyL)
        {

            Point3d PCenterT2 = new Point3d(0, 0, 0);


            for (int i = 0; i < iPolyL.Count - 1; i++)

            {
                PCenterT2 = PCenterT2 + iPolyL[i];
            }

            Point3d PCenter3 = PCenterT2 / (iPolyL.Count - 1);


            return PCenter3;
        }






        //Function to offset Polyline points in the bisecting angles of the adjacant polylione segments, correct offset distance is calculated with a math sin function

        public static List<Point3d> OKpointOffset(Polyline iPolyL, double width, Point3d myPcenter, double offIntersectTol, bool OffsetDirection)
        {


            List<Point3d> offsets = new List<Point3d>();

            //offsets.Add(iPolyL[0]);


            List<Point3d> planepoints = new List<Point3d>();

            for (int i = 0; i < iPolyL.Count - 1; i++)

            {

                planepoints.Add(iPolyL[i]);
            }




            Plane Pl = new Plane();

            Plane.FitPlaneToPoints(planepoints, out Pl);



            for (int i = 0; i < iPolyL.Count - 1; i++)

            {

                //calculating adjacant vectors

                Vector3d v1 = iPolyL[i] - iPolyL[i + 1];

                v1.Unitize();


                int superindex;

                if (i == 0)

                {
                    superindex = iPolyL.Count - 2;
                }

                else

                {
                    superindex = i - 1;
                }


                Vector3d v2 = iPolyL[i] - iPolyL[superindex];

                v2.Unitize();



                Vector3d sumVector = v1 + v2;   //bisecting vector

                sumVector.Unitize();


                //crucial part to calculate the necessary lenght



                double alpha = Vector3d.VectorAngle(sumVector, v1);


                double Hypothenuse = width / System.Math.Sin(alpha);


                Vector3d movVec = sumVector * Hypothenuse;




                Point3d movedPointPos = iPolyL[i] + movVec;

                Point3d movedPointNeg = iPolyL[i] + -movVec;




                // Sometimes, for example at butterfly polylines the offset happens not aotomatically always into the inside (or outside)direction. Therfore the points are moved in both directions 
                //to decide which one is the correct one by counting intersection events of a line from the Pount to the initial polygon center. = events is inside



                Line testLinePos = new Line(movedPointPos, myPcenter);

                Line testLineNeg = new Line(movedPointNeg, myPcenter);


                var intesectsPos = Rhino.Geometry.Intersect.Intersection.CurveCurve(testLinePos.ToNurbsCurve(), iPolyL.ToNurbsCurve(), offIntersectTol, 0.0);

                int eventsCountPos = intesectsPos.Count;





                List<Point3d> blablaLilst = new List<Point3d>();  //A List in which the correct points are added



                if (OffsetDirection)


                {



                    if (eventsCountPos == 0)

                    {
                        blablaLilst.Add(movedPointPos);


                    }

                    else

                    {
                        blablaLilst.Add(movedPointNeg);
                    }


                }



                else

                {

                    if (eventsCountPos != 0)

                    {
                        blablaLilst.Add(movedPointPos);
                    }

                    else

                    {
                        blablaLilst.Add(movedPointNeg);
                    }



                }



                Point3d projectedPoint = Pl.ClosestPoint(blablaLilst[0]);



                offsets.Add(projectedPoint);






            }



            return offsets;
        }






























        /// <summary>
        /// Provides an Icon for the component.
        /// </summary>
        protected override System.Drawing.Bitmap Icon
        {
            get
            {
                //You can add image files to your project resources and access them like this:
                // return Resources.IconForThisComponent;





                // return null;


                //   return Resource1.enforce_beam;

                return Resource1.enforce_beam_topLast;


            }
        }

        /// <summary>
        /// Gets the unique ID for this component. Do not change this ID after release.
        /// </summary>
        public override Guid ComponentGuid
        {
            get { return new Guid("551a1fa8-28c1-403d-a4b9-21af798e1969"); }
        }
    }
}