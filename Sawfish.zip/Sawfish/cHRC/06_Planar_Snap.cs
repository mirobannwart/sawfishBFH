﻿using System;
using System.Collections.Generic;

using Grasshopper.Kernel;
using Rhino.Geometry;

using System.Linq;

namespace cHRC
{
    public class MyComponent1 : GH_Component
    {
        /// <summary>
        /// Initializes a new instance of the MyComponent1 class.
        /// </summary>
        public MyComponent1()
          : base("06_PlanarSnap", "PSnap",
              "Snaps the sidelines of a beam or plate to a Surface, to adjust edge beams and plates to the ground or a wall (the Surface shuld be Planar for planar results)",
              "cHRC", "02 Offset Geometry")
        {
        }

        /// <summary>
        /// Registers all the input parameters for this component.
        /// </summary>
        protected override void RegisterInputParams(GH_Component.GH_InputParamManager pManager)
        {
            pManager.AddLineParameter("SideLines", "SL", "The Sidelines of beams and or plates", GH_ParamAccess.list); //00

            pManager.AddSurfaceParameter("Surface", "Srf", "The Surface to Snap on to", GH_ParamAccess.list);  //01

            pManager.AddNumberParameter("FindSurfaceTolerance", "ST", "The tolerance within a surface is considered as close enough to snap on to(always from the beam or plates top. Best is if the top nodes ly perfectly in the surface..)", GH_ParamAccess.item, 2.00);  //02

            pManager.AddNumberParameter("SurfaceIntersectTolerance", "SIT", "The Line Brep(!) intersection method tolerance", GH_ParamAccess.item, 0.02);  //03

            pManager.AddNumberParameter("IntersectionLineFactor", "ILF", "The Factor to Extend the Lines which will intersect. Dont think about and keep it quite high", GH_ParamAccess.item, 100.0);  //04

        }


        /// <summary>
        /// Registers all the output parameters for this component.
        /// </summary>
        protected override void RegisterOutputParams(GH_Component.GH_OutputParamManager pManager)
        {

            pManager.AddLineParameter("SideLines", "SLA", "SideLines Adjusted /Snaped list", GH_ParamAccess.list); //02

        }

        /// <summary>
        /// This is the method that actually does the work.
        /// </summary>
        /// <param name="DA">The DA object is used to retrieve from inputs and store in outputs.</param>
        protected override void SolveInstance(IGH_DataAccess DA)
        {





            List<Line> iLines = new List<Line>();   //00

             List<Surface> iSurfaces = new List<Surface>();   //01

           // List<Surface> iSurfaces = null;   //01

            double iSrfTol = 2.0; //02

            double iBrepIntersectTol = 0.02; //03

            double iExtendFactor = 100.0; //04









            if (!DA.GetDataList<Line>(0, iLines)) { return; } //  00

            //   if (!DA.GetDataList(1, ref iSurfaces)) return; //01

            if (!DA.GetDataList(1, iSurfaces)) { return; }

            if (!DA.GetData(2, ref iSrfTol)) return; //02

            if (!DA.GetData(3, ref iBrepIntersectTol)) return; //03

            if (!DA.GetData(4, ref iExtendFactor)) return; //04























           // List<Brep> myTestBreps = new List<Brep>();                        //debug test lists

         //   List<Point3d> myTestPoints = new List<Point3d>();

        //    List<Line> myTestLines = new List<Line>();

         //   List<double> myTestDists = new List<double>();

            List<Line> myFinalLines = new List<Line>();












            // Main loop: by Increment 2 to overstep the nodeback triangualör side parts which should not snap just the long sides of beams and plates should snap 
            //(otherwise two surfaces build one side which can lead to fabrication difficulties)



            for (int i = 0; i < 5; i += 2)
            {


               // Getting the points to work on

                Point3d EndPointI = iLines[i].PointAtLength(iLines[i].Length);
                Point3d EndPointIPlus1 = iLines[i + 1].PointAtLength(iLines[i + 1].Length);

                //myTestPoints.Add(EndPointI);
                // myTestPoints.Add(EndPointIPlus1);

                Point3d StartPointI = iLines[i].PointAtLength(0);
                Point3d StartPointIPlus1 = iLines[i + 1].PointAtLength(0);

                // myTestPoints.Add(StartPointI);
                // myTestPoints.Add(StartPointIPlus1);


                Point3d MPStart = (StartPointI + StartPointIPlus1) / 2;   //from this middle point the surface is searched






                Brep myBrep = getClosestBrep(MPStart, iSurfaces, iSrfTol);   // Function to get the closest surface (brep)

                bool isValid = myBrep.IsValid;  // if noi Brep is getClosestBrep enough null brerps or similar are created. Therfore just going on if a valid brep is found (SNAP SITUATION)


                if (isValid)
                {

                  //  myTestBreps.Add(myBrep);

                  //  myTestPoints.Add(MPStart);



                    //Indexes before and after snap side  to get the Projection vectors

                    int indexMinus;

                    if (i == 0)
                    {
                        indexMinus = iLines.Count - 1;
                    }
                    else
                    {
                        indexMinus = i - 1;
                    }



                    int indexPlus;

                    if (i == 4)
                    {
                        indexPlus = 0;
                    }
                    else
                    {
                        indexPlus = i + 2;
                    }


                  //  Points before and after the snape sides for the Projection vectors

                    Point3d MinusPoint = iLines[indexMinus].PointAtLength(iLines[indexMinus].Length);

                    Point3d PlusPoint = iLines[indexPlus].PointAtLength(iLines[indexPlus].Length);


                    // myTestPoints.Add(MinusPoint);
                    //  myTestPoints.Add(PlusPoint);



                    //Creating intersection lines (Extended)

                    Vector3d myIntesectLineMinusVec = EndPointI - MinusPoint;

                    Vector3d myIntesectLinePlusVec = EndPointIPlus1 - PlusPoint;


                    double myExtendFactor = iExtendFactor;


                    Point3d myIntersectLinePointMinus = EndPointI + myIntesectLineMinusVec * myExtendFactor;
                    Point3d myIntersectLinePointMinus2 = EndPointI + myIntesectLineMinusVec * -myExtendFactor;


                    Point3d myIntersectLinePointPlus = EndPointIPlus1 + myIntesectLinePlusVec * myExtendFactor;
                    Point3d myIntersectLinePointPlus2 = EndPointIPlus1 + myIntesectLinePlusVec * -myExtendFactor;



                    Line myIntersectLineMinus = new Line(myIntersectLinePointMinus, myIntersectLinePointMinus2);

                    Line myIntersectLinePlus = new Line(myIntersectLinePointPlus, myIntersectLinePointPlus2);

                    //myTestLines.Add(myIntersectLineMinus);

                    // myTestLines.Add(myIntersectLinePlus);




                    // Getting The intertsections by a Function (The Fuction Inoput are Lists, therefore Adding the Line and the Brep to a list. (The Function could be improved....)

                    List<Curve> myCurves = new List<Curve>();
                    List<Curve> myCurvesPlus = new List<Curve>();

                    myCurves.Add(myIntersectLineMinus.ToNurbsCurve());
                    myCurvesPlus.Add(myIntersectLinePlus.ToNurbsCurve());

                    List<Brep> myBreps = new List<Brep>();
                    myBreps.Add(myBrep);



                    List<Point3d> mySuperpoints = new List<Point3d>();  

                    LineBrepIntersection(myCurves, myBreps, iBrepIntersectTol, ref mySuperpoints);



                    List<Point3d> mySuperpointsPlus = new List<Point3d>(); //Intersectionpoint out list


                    LineBrepIntersection(myCurvesPlus, myBreps, iBrepIntersectTol, ref mySuperpointsPlus);


                    Point3d myFinalPointI = mySuperpoints[0];
                    Point3d myFinalPointIPlus = mySuperpointsPlus[0];


                   // myTestPoints.Add(myFinalPointI);
                 //   myTestPoints.Add(myFinalPointIPlus);




                    //Finbal Lines


                    Line myFinalLineI = new Line(StartPointI, myFinalPointI);

                    Line myFinalLineIPlus = new Line(StartPointIPlus1, myFinalPointIPlus);



                 //   myTestLines.Add(myFinalLineI);

                 //   myTestLines.Add(myFinalLineIPlus);



                    myFinalLines.Add(myFinalLineI);

                    myFinalLines.Add(myFinalLineIPlus);









                }

                else

                {

                    myFinalLines.Add(iLines[i]);

                    myFinalLines.Add(iLines[i + 1]);

                }






            }








            DA.SetDataList(0, myFinalLines);




            /*
            oTestClosestBrep = myTestBreps;

            oTestPoints = myTestPoints;

            oTestLines = myTestLines;

            oTestDists = myTestDists;

            oFinalLines = myFinalLines;
*/







        }





        //Function to get the closestSurface from a Point


        public Brep getClosestBrep(Point3d testPoint, List<Surface> testSurfaces, double Tol)    
        {

            // List<Brep> ListBreps = new List<Brep>();

            Brep startPBrep = new Brep();


            for (int j = 0; j < testSurfaces.Count; j++)
            {

                Point3d srfCPstartP = new Point3d();

                double u;
                double v;

                testSurfaces[j].ClosestPoint(testPoint, out u, out v);
                srfCPstartP = testSurfaces[j].PointAt(u, v);


                double distStartP = testPoint.DistanceTo(srfCPstartP);

                if (distStartP < Tol)
                {


                    startPBrep = testSurfaces[j].ToBrep();

                }

            }


            /*bool isValid =  startPBrep.IsValid;


             if (isValid)

             {

               return startPBrep;

             }

          */

            return startPBrep;

        }









        // A Void (Whats that??) to get a brep Line Intersection Point



        public void LineBrepIntersection(List<Curve> myCurvesList, List<Brep> myBrepList, double tol, ref List<Point3d> thePoints)


        {

            for (int i = 0; i < myCurvesList.Count; i++)


            {
                Curve crv = myCurvesList[i];

                if (crv == null) continue;

                for (int j = 0; j < myBrepList.Count; j++)
                {
                    Brep brep = myBrepList[j];

                    if (brep == null) continue;

                    BrepFace[] faces = myBrepList[j].Faces.ToArray();

                    for (int f = 0; f < faces.Length; f++)

                    {
                        BrepFace face = faces[f];

                        Curve[] myCurves;

                        Point3d[] myPoints;

                        Rhino.Geometry.Intersect.Intersection.CurveBrepFace(crv, face, tol, out myCurves, out myPoints);

                        List<Point3d> myPoints2 = myPoints.ToList();

                        thePoints = myPoints2;

                    }

                }
            }

        }












        /// <summary>
        /// Provides an Icon for the component.
        /// </summary>
        protected override System.Drawing.Bitmap Icon
        {
            get
            {
                //You can add image files to your project resources and access them like this:
                // return Resources.IconForThisComponent;
                //return null;


                return Resource1.Planar_Snap222;
            }
        }

        /// <summary>
        /// Gets the unique ID for this component. Do not change this ID after release.
        /// </summary>
        public override Guid ComponentGuid
        {
            get { return new Guid("ca704653-188a-46b3-b0a0-41edcc06fa7a"); }
        }
    }
}