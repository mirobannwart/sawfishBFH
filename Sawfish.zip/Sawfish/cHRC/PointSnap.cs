﻿using System;
using System.Collections.Generic;

using Grasshopper.Kernel;
using Rhino.Geometry;

namespace cHRC
{
    public class PointSnap : GH_Component
    {
        /// <summary>
        /// Initializes a new instance of the MyComponent3 class.
        /// </summary>
        public PointSnap()
          : base("10_PointSnap", "PtSnap",
              "Snaps Points to a surface of a collection of surfaces if the Points Surfaceclosestpoint on the closest surface is below a tolerance",
              "cHRC", "01 Adjust")
        {
        }

        /// <summary>
        /// Registers all the input parameters for this component.
        /// </summary>
        protected override void RegisterInputParams(GH_Component.GH_InputParamManager pManager)
        {

            pManager.AddPointParameter("Points", "Pt", "Points to snap", GH_ParamAccess.list); //00

            pManager.AddSurfaceParameter("Surface", "Srf", "The Surface to Snap on to", GH_ParamAccess.list);  //01

            pManager.AddNumberParameter("SnapTolerance", "T", "The snap tolerance distance", GH_ParamAccess.item, 100.0);  //02

        }

        /// <summary>
        /// Registers all the output parameters for this component.
        /// </summary>
        protected override void RegisterOutputParams(GH_Component.GH_OutputParamManager pManager)
        {

            pManager.AddPointParameter("SnapedPoints", "SPt", "The snaped points", GH_ParamAccess.list); //00

            pManager.AddCurveParameter("SnapedPolylines", "SPl", "A polyline through the adjusted points", GH_ParamAccess.list); //00
        }

        /// <summary>
        /// This is the method that actually does the work.
        /// </summary>
        /// <param name="DA">The DA object is used to retrieve from inputs and store in outputs.</param>
        protected override void SolveInstance(IGH_DataAccess DA)
        {






            List<Point3d> iPoints = new List<Point3d>();   //00

            List<Surface> iSurfaces = new List<Surface>();   //01

            double iSnapTol = 200; //02



            if (!DA.GetDataList<Point3d>(0, iPoints)) { return; } //  00

            if (!DA.GetDataList(1, iSurfaces)) { return; }  //01

            if (!DA.GetData(2, ref iSnapTol)) return;  //02















            List<Point3d> myTestPoints = new List<Point3d>();

            List<Surface> myTestSurfaces = new List<Surface>();


            List<Point3d> myFinalPoints = new List<Point3d>();





            for (int i = 0; i < iPoints.Count; i++)
            {
                // myTestPoints.Add(iPoints[i]);


                List<Surface> myClosestSurfaces = new List<Surface>();



                for (int j = 0; j < iSurfaces.Count; j++)
                {



                    double u;
                    double v;

                    iSurfaces[j].ClosestPoint(iPoints[i], out u, out v);


                    Point3d ClosestPoint = iSurfaces[j].PointAt(u, v);

                    double dist = iPoints[i].DistanceTo(ClosestPoint);

                    if (dist < iSnapTol)
                    {
                        myTestPoints.Add(ClosestPoint);
                        myClosestSurfaces.Add(iSurfaces[j]);
                        myTestSurfaces.Add(iSurfaces[j]);

                    }

                }




                if (myClosestSurfaces.Count > 0)

                {


                    double u;
                    double v;

                    myClosestSurfaces[0].ClosestPoint(iPoints[i], out u, out v);


                    Point3d ClosestPoint = myClosestSurfaces[0].PointAt(u, v);



                    myFinalPoints.Add(ClosestPoint);



                }

                else

                {
                    myFinalPoints.Add(iPoints[i]);

                }






            }


            List<Polyline> myPolys = new List<Polyline>();

            if (myFinalPoints.Count > 0)
            {

                Polyline myPoly = new Polyline(myFinalPoints);

                myPolys.Add(myPoly);
            }


            /*

            oPolylines = myPolys;

            oPoints = myFinalPoints;


            oTestPoints = myTestPoints;

            oTestSurfaces = myTestSurfaces;

            */



            DA.SetDataList(0, myFinalPoints);

            DA.SetDataList(1, myPolys);







        }

        /// <summary>
        /// Provides an Icon for the component.
        /// </summary>
        protected override System.Drawing.Bitmap Icon
        {
            get
            {
                //You can add image files to your project resources and access them like this:
                // return Resources.IconForThisComponent;

                // return null;

                return Resource1.PointSnap;
            }
        }

        /// <summary>
        /// Gets the unique ID for this component. Do not change this ID after release.
        /// </summary>
        public override Guid ComponentGuid
        {
            get { return new Guid("32ad3b35-c84c-4913-8150-b2044a58430b"); }
        }
    }
}