﻿using System;
using System.Collections.Generic;

using Grasshopper.Kernel;
using Rhino.Geometry;



using Grasshopper.Kernel.Data;



namespace cHRC
{
    public class MyComponent4 : GH_Component
    {
        /// <summary>
        /// Initializes a new instance of the MyComponent4 class.
        /// </summary>
        public MyComponent4()
          : base("05_0ffset_dif_polygon_AD_3_hex_super.", "05_Off_dif_poly_hex3_s",
              "Non Plus Ultra 3",
              "cHRC", "05 WIP agentTPI + and more")
        {
        }
        /// <summary>
        /// Registers all the input parameter for this component.
        /// </summary>
        protected override void RegisterInputParams(GH_Component.GH_InputParamManager pManager)
        {



            pManager.AddCurveParameter("Polylines", "Pl", "Polyline Input for the offset, as list", GH_ParamAccess.list); //00

            pManager.AddNumberParameter("Thickness", "T", "The material thickness, structural height in mm", GH_ParamAccess.item, 27);  //01

            pManager.AddNumberParameter("NodeBackLow", "BL", "Distance in mm to make the lower node outcut", GH_ParamAccess.item, 60);  //02

            pManager.AddNumberParameter("CheckDist", "CD", "The Distance from the polygon edges middlepoint to the neighbourpolygon in which the neighbour polygon is considered a neighbour (not a naked edge)", GH_ParamAccess.item, 0.01); //03

            pManager.AddNumberParameter("AngleEffect", "AF", "Effect of the Anglefactor 0 = no effect, 1 = full effect hhmmm is that through? its more remap target 1...", GH_ParamAccess.item, 1);  //04

            pManager.AddNumberParameter("ThresholdAngle", "TA", "Nodesituations with higher top inside Angles will not be affected by the angle correction", GH_ParamAccess.item, 45);  //05

            pManager.AddNumberParameter("adjustFindpointsFactor", "CDAdjust", "Adjust check Distance factor of the edge lenght", GH_ParamAccess.item, 0.35);  //06

            pManager.AddIntegerParameter("CheckStepsNodeback", "CSt", "Accuracy of the nodeback function", GH_ParamAccess.item, 50);  //07

            pManager.AddNumberParameter("ApproxMaxTopAngle", "AprtA", "Works together with AngleEffect (remap initial 0 to AprtA) MAybe around 140 for Triangles and less for beams becaus their inside tob angles are lower  ", GH_ParamAccess.item, 140);  //08

            pManager.AddLineParameter("NakedEdge", "NK", "Naked Edges to check Edgesituation, is necessary!! From Trianglesn not from beams, (as list)", GH_ParamAccess.list); //09




            pManager.AddBooleanParameter("Apply_Plane_intersction_node_Middle", "PIM", "If True a simplified plane intersection node calculation is applied in the middle of the structure (not edge): no node outcut is applied where possible: if there are 3 or less  unique planes which meeet  at one Point ", GH_ParamAccess.item, true);  //10

            pManager.AddBooleanParameter("Apply_Plane_intersction_node_Edge", "PIE", "If True a simplified plane intersection node calculation is applied at edge situations, this can produce not planar edge sides: no node outcut is applied where possible: if there are 3 or less  unique planes which meeet  at one Point ", GH_ParamAccess.item, false);  //11

            pManager.AddNumberParameter("CheckAngle", "CA", "The check angle between planes normal vectors to find unique planes at one node. Note that two beams in one triangle have the same normal vector", GH_ParamAccess.item, 0.07); //12

            pManager.AddNumberParameter("EdgeNodeBackFactor", "ENBF", "A Factor as a multiplicator oft the material thickness to define the nodeback distance at middle situations (two plane offset) adjacent two edges  ", GH_ParamAccess.item, 0.5); //13



        }

        /// <summary>
        /// Registers all the output parameters for this component.
        /// </summary>
        protected override void RegisterOutputParams(GH_Component.GH_OutputParamManager pManager)
        {


            pManager.AddCurveParameter("SideLines", "SLA", "SideLines Adjusted as Tree TEST", GH_ParamAccess.tree); //02



        }



        /// <summary>
        /// This is the method that actually does the work.
        /// </summary>
        /// <param name="DA">The DA object is used to retrieve from inputs and store in outputs.</param>
        protected override void SolveInstance(IGH_DataAccess DA)
        {


            List<Curve> iCurves = new List<Curve>();   //00

            double oHeight = 27; //01


            double oNodeBackUK = 120; //02


            double iCheckDist = 0.01; //03


            double AngleFactoEfect1 = 1.0; //04


            double ThresholdAngle = 45; //05


            double AdjustCeckDistFactor = 45; //06

            int checksteps = 60; //07

            double ApproxMaxTopAngle = 140; //08

            List<Line> NakedEdges = new List<Line>();   //09



            bool Apply_Plane_intersction_node_Middle = true; //10

            bool Apply_Plane_intersction_node_Edge = false; //11

            double CheckAngle = 0.07;  //12

            double EdgeNodeBackFactor = 1.0;  //13











            if (!DA.GetDataList<Curve>(0, iCurves)) { return; } //  0


            if (!DA.GetData(1, ref oHeight)) return; //01


            if (!DA.GetData(2, ref oNodeBackUK)) return;   //02


            if (!DA.GetData(3, ref iCheckDist)) return;  //03

            if (!DA.GetData(4, ref AngleFactoEfect1)) return;  //04  


            if (!DA.GetData(5, ref ThresholdAngle)) return;  //05


            if (!DA.GetData(6, ref AdjustCeckDistFactor)) return;  //06

            if (!DA.GetData(7, ref checksteps)) return;  //07



            if (!DA.GetData(8, ref ApproxMaxTopAngle)) return;  //08

            if (!DA.GetDataList<Line>(9, NakedEdges)) { return; } //  09





            if (!DA.GetData(10, ref Apply_Plane_intersction_node_Middle)) return;  //10

            if (!DA.GetData(11, ref Apply_Plane_intersction_node_Edge)) return;  //11

            if (!DA.GetData(12, ref CheckAngle)) { return; } //  12

            if (!DA.GetData(13, ref EdgeNodeBackFactor)) { return; } //  13















            //Expiring:


            var myDay = System.DateTime.Now.Day;

            var myMonth = System.DateTime.Now.Month;

            var myYear = System.DateTime.Now.Year;

            /*
            A = myDay;

            B = myMonth;

            C = myYear;
            */

            //ExpiringTime

            int check = 1;

            int expYear = 999999999;

            int expMonth = 03;

            int expDay = 27;



            if (myYear > expYear)
            {
                check = 0;
            }

            if (myYear == expYear)
            {
                if (myMonth > expMonth)
                {
                    check = 0;
                }

                if (myMonth == expMonth)
                {

                    if (myDay > expDay)
                    {
                        check = 0;
                    }

                }

            }



            //  E = check;



















            int myStartIndex = 0;

            int iteration = iCurves.Count;




            List<Vector3d> myNormals = new List<Vector3d>();

            List<Polyline> Icurves22 = new List<Polyline>();

            List<List<NurbsCurve>> myListListCurves = new List<List<NurbsCurve>>();

            List<NurbsCurve> myListListCurves55555555 = new List<NurbsCurve>();

            List<Point3d> myPolyCentrs = new List<Point3d>();

            List<List<NurbsCurve>> myListListSuperSideLines = new List<List<NurbsCurve>>();

            List<Line> Testlines = new List<Line>();



            // List<Point3d> TestPoints = new List<Point3d>();






            //Loop through all input polylines to get all neighbour normal vectors and neighbour polygon centers which are necessary to offset the plate correctly  (Edge offset in the bisecting angle to the neighbour)

            for (int i = 0; i < iCurves.Count; i++)
            {
                Polyline iPolyL3;  //polyline to work with

                iCurves[i].TryGetPolyline(out iPolyL3); //visual studio work around

                Icurves22.Add(iPolyL3); // polyline to work with, List


                myPolyCentrs.Add(PolylineAverage(iPolyL3));  //the polyline center point by a function

                myNormals.Add(PolygonNormal(iPolyL3)); //the Polygon Normal  by a function
            }






            if (check != 0)  //Expiring if

            {



                // main loop, find lower points / Sidleines1 


                for (int i = 0; i < iteration; i++)
                {
                    Polyline iPolyL0;  //polyline to work with
                    iCurves[i + myStartIndex].TryGetPolyline(out iPolyL0); //necessary in visual studio 

                    //Get the UK points of the plate by a a function see functions

                    List<NurbsCurve> mySuperSideLines = UKpointOffsetLine(NakedEdges, ApproxMaxTopAngle, checksteps, iPolyL0, oHeight, myPolyCentrs[i + myStartIndex], Icurves22, myPolyCentrs, myNormals, oNodeBackUK, iCheckDist, AngleFactoEfect1, ThresholdAngle, Apply_Plane_intersction_node_Middle, Apply_Plane_intersction_node_Edge, CheckAngle, EdgeNodeBackFactor);

                    myListListSuperSideLines.Add(mySuperSideLines);

                }

            }//Expiring



                    //  setting node back align.... Sidleines 2 Adjusted

                    List<List<Line>> myListListSuperSideLinesAdjusted0 = SetNodeBackToAngleAdjust(myListListSuperSideLines, AdjustCeckDistFactor);


            //   Remove duplicated lines

            List<List<Line>> myListListSuperSideLinesAdjusted = new List<List<Line>>();

            for (int i = 0; i < myListListSuperSideLinesAdjusted0.Count; i++)
            {
                List<Line> LineList = RemoveDuplicates(myListListSuperSideLinesAdjusted0[i], 0.06);
                myListListSuperSideLinesAdjusted.Add(LineList);
            }










            //OUTPUTS LIST TO TREE


            //ListofLists to Tree for the Output  Sidlines not align

            Grasshopper.DataTree<NurbsCurve> myFinalSuperlinesTree = new Grasshopper.DataTree<NurbsCurve>();

            for (int i = 0; i < myListListSuperSideLines.Count; i++)
            {
                int ListLenght333 = myListListSuperSideLines[i].Count;

                for (int j = 0; j < ListLenght333; j++)
                {
                    myFinalSuperlinesTree.Add(myListListSuperSideLines[i][j], new GH_Path(i));

                }

            }





            //ListofLists to Tree for the Output  Sidlines  align

            Grasshopper.DataTree<Line> myListListSuperSideLinesAdjustedTree = new Grasshopper.DataTree<Line>();

            for (int i = 0; i < myListListSuperSideLinesAdjusted.Count; i++)
            {
                int ListLenght333 = myListListSuperSideLinesAdjusted[i].Count;

                for (int j = 0; j < ListLenght333; j++)
                {
                    myListListSuperSideLinesAdjustedTree.Add(myListListSuperSideLinesAdjusted[i][j], new GH_Path(i));

                }

            }



            //OUTPUTS


            DA.SetDataTree(0, myListListSuperSideLinesAdjustedTree); //myListListSuperSideLinesAdjusted

            //  DA.SetDataList(3, TestPoints);

        }







        //FUNCTIONS


        //A Function to get the center of a closed polyline
        public static Point3d PolylineAverage(Polyline iPolyL)
        {
            Point3d PCenterT2 = new Point3d(0, 0, 0);

            for (int i = 0; i < iPolyL.Count - 1; i++)
            {
                PCenterT2 = PCenterT2 + iPolyL[i];
            }

            Point3d PCenter3 = PCenterT2 / (iPolyL.Count - 1);

            return PCenter3;
        }



        // A Function to get  the polyline normal
        public static Vector3d PolygonNormal(Polyline iPolyL3)
        {
            Vector3d v4 = iPolyL3[0] - iPolyL3[1];
            Vector3d v5 = iPolyL3[0] - iPolyL3[2];

            Vector3d myNormal = Vector3d.CrossProduct(v4, v5);
            myNormal.Unitize();

            return myNormal;
        }




        //function to remap values

        public static double map(double s, double a1, double a2, double b1, double b2)
        {
            return b1 + (s - a1) * (b2 - b1) / (a2 - a1);
        }





        // A Function to get  the inside angles of a polygon

        public static List<double> InsideAngleListDegree(Polyline iPolyL)
        {

            List<double> inSideAnglesL = new List<double>();

            for (int i = 0; i < iPolyL.Count - 1; i++)
            {
                Vector3d v11 = iPolyL[i] - iPolyL[i + 1];
                v11.Unitize();

                int superindex;

                if (i == 0)
                {
                    superindex = iPolyL.Count - 2;
                }

                else
                {
                    superindex = i - 1;
                }

                Vector3d v22 = iPolyL[i] - iPolyL[superindex];
                v22.Unitize();

                double myAngle1 = Vector3d.VectorAngle(v11, v22);  //EVENT v22 mal -1
                double insideAngle = Rhino.RhinoMath.ToDegrees(myAngle1);

                inSideAnglesL.Add(insideAngle);

            }

            return inSideAnglesL;

        }









        // A Function to offset the plate  top polyline points to the lower level
        // The endpoints of the edges are moved in the bisecting vector of the adjacant polyline normal vectors. To get the correct and uniform material Thickness offset Distance is calculated with a math cosinus function 
        //in dependence of the material thickness.  
        //If an edge is naked and there is no neighbour polyline,
        //the edges Endpoints are moved in the polylines normal vector: Distance: Matetrial Thickness

        public static List<NurbsCurve> UKpointOffsetLine(List<Line> NakedEdges, double ApproxMaxTopAngle, int checksteps, Polyline iPolyL, double height, Point3d myPcenter, List<Polyline> allMyPolylines, List<Point3d> allmyPcenters, List<Vector3d> superNormals, double nodeBack, double myCheckDist, double anglefactorEffectFactor, double thresholdAngle, bool Apply_Plane_intersction_node_Middle, bool Apply_Plane_intersction_node_Edge, double CheckAngle, double EdgeNodeBackFactor)
        {


            List<NurbsCurve> mySideLines = new List<NurbsCurve>();


            List<Line> NakedLines = NakedEdges;





            // Getting the inside angles by a function and remap to angle factors 

            List<double> inSideAnglesL = InsideAngleListDegree(iPolyL);    //see function
            List<double> inSideAnglesLFactors = new List<double>();


            for (int i = 0; i < inSideAnglesL.Count; i++)
            {

                double anglefactor = map(inSideAnglesL[i], 0, ApproxMaxTopAngle, 1.0 + anglefactorEffectFactor, 1.0);


                if (inSideAnglesL[i] < thresholdAngle)
                {
                    inSideAnglesLFactors.Add(anglefactor);
                }
                else
                {
                    inSideAnglesLFactors.Add(1.0);
                }

            }

            inSideAnglesLFactors.Add(inSideAnglesLFactors[0]);  //  Add the first at last..




            Point3d TheCenter = PolylineAverage(iPolyL);




            //MAIN LOOP through PolylinePoints


            for (int i = 0; i < iPolyL.Count - 1; i++)
            {
                //getting edge Vector, edge Middelpoint, edge lenght, Initial Points

                Point3d initialEdgeStartP = iPolyL[i];
                Point3d initialEdgeEndP = iPolyL[i + 1];


                Vector3d v1 = initialEdgeStartP - initialEdgeEndP;

                Point3d mp0 = initialEdgeStartP + v1 * -0.5;

                double EdgeLength = initialEdgeStartP.DistanceTo(initialEdgeEndP);



                List<Point3d> myNeighbourCenterPoints = new List<Point3d>();
                List<Vector3d> myNeighbourVectors = new List<Vector3d>();


                List<Polyline> myNeighbourpolylinesStart1 = new List<Polyline>();  //without self

                List<Polyline> myNeighbourpolylinesEnd2 = new List<Polyline>();   //without self


                List<Polyline> myNeighbourpolylinesStart1withSelf = new List<Polyline>();  //with self

                List<Polyline> myNeighbourpolylinesEnd2withSelf = new List<Polyline>();   //with self


                // myNeighbourpolylinesEnd2withSelf myNeighbourpolylinesStart1withSelf


                //getting Neighbour center points, and neighbour normal vectors from a list with all center points and and normals

                for (int j = 0; j < allMyPolylines.Count; j++)
                {
                    Polyline myPl = allMyPolylines[j];



                    //Neighbours from Edge Middlepoints MP

                    Point3d myCPmp = myPl.ClosestPoint(mp0);

                    double DistanceMP0 = mp0.DistanceTo(myCPmp);

                    if (DistanceMP0 < myCheckDist)
                    {
                        myNeighbourCenterPoints.Add(allmyPcenters[j]);
                        myNeighbourVectors.Add(superNormals[j]);
                    }





                    //Neighbours from initial edge Startpoint (initialEdgeStartP) //without self

                    Point3d myCst = myPl.ClosestPoint(initialEdgeStartP);

                    double DistanceST = initialEdgeStartP.DistanceTo(myCst);

                    if (DistanceST < myCheckDist)
                    {
                        if (allmyPcenters[j].DistanceTo(TheCenter) > myCheckDist)
                        {
                            myNeighbourpolylinesStart1.Add(allMyPolylines[j]);

                        }

                    }




                    //Neighbours from intial edge Endpoint (initialEdgeEndP) //without self

                    Point3d myCen = myPl.ClosestPoint(initialEdgeEndP);

                    double DistanceEnd = initialEdgeEndP.DistanceTo(myCen);

                    if (DistanceEnd < myCheckDist)
                    {
                        if (allmyPcenters[j].DistanceTo(TheCenter) > myCheckDist)
                        {
                            myNeighbourpolylinesEnd2.Add(allMyPolylines[j]);

                        }

                    }







                    //Neighbours from initial edge Startpoint (initialEdgeStartP) //with self

                    Point3d myCst2 = myPl.ClosestPoint(initialEdgeStartP);

                    double DistanceST2 = initialEdgeStartP.DistanceTo(myCst2);

                    if (DistanceST2 < myCheckDist)
                    {

                        myNeighbourpolylinesStart1withSelf.Add(allMyPolylines[j]);



                    }




                    //Neighbours from intial edge Endpoint (initialEdgeEndP) //with self

                    Point3d myCen2 = myPl.ClosestPoint(initialEdgeEndP);

                    double DistanceEnd2 = initialEdgeEndP.DistanceTo(myCen2);

                    if (DistanceEnd2 < myCheckDist)
                    {

                        myNeighbourpolylinesEnd2withSelf.Add(allMyPolylines[j]);

                    }











                }  //+++














                //IF less than 2 neighbours  (EDGE SITUATIONS, event. corner)




                if (myNeighbourCenterPoints.Count == 1)

                {


                    if (Apply_Plane_intersction_node_Edge)

                    {
                        // Function to Set the node Back at Edge Situations  // WITH PLANE INTERSECTION (No Node Outcut iff possible) (can create none planar edge sides)
                        List<NurbsCurve> SideLines1 = NodebackEdgePI(NakedLines, checksteps, myNeighbourpolylinesStart1, myNeighbourpolylinesEnd2, myNeighbourpolylinesStart1withSelf, myNeighbourpolylinesEnd2withSelf, v1, myNeighbourCenterPoints[0], initialEdgeStartP, initialEdgeEndP, height, EdgeLength, inSideAnglesLFactors[i], inSideAnglesLFactors[i + 1], nodeBack, CheckAngle);

                        mySideLines.Add(SideLines1[0]);

                        mySideLines.Add(SideLines1[1]);
                    }

                    else
                    {
                        //Always NodeBack (Edge) => always planar sides


                        // Function to Set the node Back at EDGE Situations  //ALWAYs NODEBACK NO PLANE INTERSECTION
                        List<NurbsCurve> SideLines1 = NodebackEdge(NakedLines, checksteps, myNeighbourpolylinesStart1, myNeighbourpolylinesEnd2, v1, myNeighbourCenterPoints[0], initialEdgeStartP, initialEdgeEndP, height, EdgeLength, inSideAnglesLFactors[i], inSideAnglesLFactors[i + 1], nodeBack);

                        mySideLines.Add(SideLines1[0]);

                        mySideLines.Add(SideLines1[1]);


                    }



                }






                if (myNeighbourCenterPoints.Count > 1)   //IF MORE than 2 neighbours  (MIDDLE SITUATIONS)

                {


                    if (Apply_Plane_intersction_node_Middle)

                    {

                        // Function to Set the node Back at middle Situations // WITH PLANE INTERSECTION   makes sense forhexa and pentagons where 3 unique planes meet at one node

                        List<NurbsCurve> SideLines2 = NodebackMiddlePI(NakedLines, checksteps, myNeighbourpolylinesStart1, myNeighbourpolylinesEnd2, myNeighbourpolylinesStart1withSelf, myNeighbourpolylinesEnd2withSelf, myNeighbourVectors, v1, myNeighbourCenterPoints[0], initialEdgeStartP, initialEdgeEndP, height, EdgeLength, inSideAnglesLFactors[i], inSideAnglesLFactors[i + 1], nodeBack, CheckAngle, EdgeNodeBackFactor);

                    mySideLines.Add(SideLines2[0]);

                    mySideLines.Add(SideLines2[1]);


                    }

                    else
                    {
                        //Always NodeBack  //Always NodeBack (Middle) => also nodeback (nodeoutcut) if just unique 3 planes meet at one node

                        // Function to Set the node Back at MIDDLE Situations //ALWAYs NODEBACK NO PLANE INTERSECTION

                        List<NurbsCurve> SideLines2 = NodebackMiddle(NakedLines, checksteps, myNeighbourpolylinesStart1, myNeighbourpolylinesEnd2, myNeighbourVectors, v1, myNeighbourCenterPoints[0], initialEdgeStartP, initialEdgeEndP, height, EdgeLength, inSideAnglesLFactors[i], inSideAnglesLFactors[i + 1], nodeBack);

                        mySideLines.Add(SideLines2[0]);

                        mySideLines.Add(SideLines2[1]);


                    }





                }



                myNeighbourCenterPoints.Clear();

            }




            return mySideLines;


        }








        // A FUNCTION to set back the lower node //NODEBACK at MIDDLE  SITUATIONS      // WITH PLANE INTERSECTION     

        public static List<NurbsCurve> NodebackMiddlePI(List<Line> NakedEdge, int checkSteps, List<Polyline> myNeighbourpolylinesStart1, List<Polyline> myNeighbourpolylinesEnd2, List<Polyline> myNeighbourpolylinesStart1withSelf, List<Polyline> myNeighbourpolylinesEnd2withSelf, List<Vector3d> myNeighbourVectors, Vector3d v1, Point3d myNeighbourCenterPoint, Point3d initialEdgeStartP, Point3d initialEdgeEndP, double height, double EdgeLength, double THEinSideAnglesLFactor, double THEinSideAnglesLFactor2End, double nodeBack, double CheckAngle, double EdgeNodeBackFactor)
        {

            List<NurbsCurve> mySideLines = new List<NurbsCurve>();  //for return





            Vector3d moveVecSum2 = myNeighbourVectors[0] + myNeighbourVectors[1];  //  myNeighbourVectors[0]
            moveVecSum2.Unitize();

            double alpha = Vector3d.VectorAngle(moveVecSum2, myNeighbourVectors[1]);

            double Hypothenuse = height / System.Math.Cos(alpha);

            Point3d myUKpoint0 = initialEdgeStartP + moveVecSum2 * Hypothenuse * -1;
            Point3d myUKpoint1 = initialEdgeEndP + moveVecSum2 * Hypothenuse * -1;


            v1.Unitize();  // is necesssary!!



            /*
           
            //no nodeback necessary is  necessary if the nodepoint has 3 or less different neighbourplanes 
         



            //Notes:

            If:

            1 Plane: Offset in Plane Z

            2 Different Planes: Bisecting ze Vec in correct length: see above just takemy UKpoint0 and  myUKpoint1  (no NodeBack!)

            3 Different Planes: Plane Plane Plane Intersection Point

            ELSE:

            4 Different Planes and More: Node Back! everything as already in the code 


            */









        //CHECK How many different NeighboursPlanes are at the START POINT





        //A Function to get a list with as many different polygon planes as there are different  polygons (different normal Vecs) in the input list (get all unic planes (get all unic planes around one node).
        //This Function calls other Fuctions(which call functions): PolygonPlane, PolyGonNormal, PolygonAverage

     //   double myNormaCompareChecklTol = 0.07;

            List<Plane> myNiceUniqueNoDupPlanes = UniquePolygonPlanes(myNeighbourpolylinesStart1withSelf, initialEdgeStartP, CheckAngle);





            //BELOW 4 Neighbours: START POINT


            //Is Naked Check START
            //Point3d mpOK = (initialEdgeStartP + initialEdgeEndP) / 2;

            List<int> NakedCheckListStart = new List<int>();

            for (int i = 0; i < NakedEdge.Count; i++)
            {
                Point3d closestP = NakedEdge[i].ClosestPoint(initialEdgeStartP, true);

                double dist = closestP.DistanceTo(initialEdgeStartP);

                if (dist < 0.1)

                {
                    NakedCheckListStart.Add(1);
                }
            }







            Point3d myFinalUkforBelow4neighboursPoint = (myUKpoint0 + myUKpoint1) / 2; //just a point to replace






            



            //  1 Neighbour Plane: Offset in Plane Z and Nodeback if the middle part is edge adjacent  //(StartPoint))


            if (myNiceUniqueNoDupPlanes.Count == 1)
            {

                if (myNeighbourpolylinesStart1.Count > 1 | NakedCheckListStart.Count > 0)
                {

                    //A Function to move a point in a Planes Z vector  + NODEBACK (One Neighbour Plane) 

                    Point3d OffsetPoint1 = OffsetPointInPlaneZNodeBack(myNiceUniqueNoDupPlanes[0], initialEdgeStartP, initialEdgeEndP, height, EdgeNodeBackFactor);
                   
                    }

                else

                {
                    //A Function to move a point in a Planes Z vector (One Neighbour Plane) NO NODEBACK
                    Point3d OffsetPoint1 = OffsetPointInPlaneZ(myNiceUniqueNoDupPlanes[0], initialEdgeStartP, height);

                    myFinalUkforBelow4neighboursPoint = OffsetPoint1;

                }

            }






            /*  //This was before Node Bake middle at edge adjacent try


            //  1 Neighbour Plane: Offset in Plane Z

            if (myNiceUniqueNoDupPlanes.Count == 1)
            {
                //A Function to move a point in a Planes Z vector (One Neighbour Plane)
                Point3d OffsetPoint1 = OffsetPointInPlaneZ(myNiceUniqueNoDupPlanes[0], initialEdgeStartP, height);

                myFinalUkforBelow4neighboursPoint = OffsetPoint1;

            }

        */






















                /*

                //  2 Neighbour Planes: Offset in Bisecting Planes Z in correct length  NO SPECIAL EDGE NODE BACK

                if (myNiceUniqueNoDupPlanes.Count == 2)
                {
                    //A Function to move a point in the bisecting vector of two planes Z vectors.
                    //The amp (vector lenght) is calculated in dependence of the material thickness by the cos function.
                    //(Two Neighbour Planes)

                    Point3d OffsetPoint2 = OffsetPointInTwoPlanesZvec(myNiceUniqueNoDupPlanes, initialEdgeStartP, height);

                    myFinalUkforBelow4neighboursPoint = OffsetPoint2;

                }
                */





                //  2 Neighbour Planes: Offset in Bisecting Planes Z in correct length  WITH EDGE NODE BACK

                if (myNiceUniqueNoDupPlanes.Count == 2)
            {
                //A Function to move a point in the bisecting vector of two planes Z vectors.
                //The amp (vector lenght) is calculated in dependence of the material thickness by the cos function.
                //(Two Neighbour Planes)   

                //WITH NODE BACK

                Point3d OffsetPoint2 = OffsetPointInTwoPlanesZvecNodeBack(myNiceUniqueNoDupPlanes, initialEdgeStartP, initialEdgeEndP, height, EdgeNodeBackFactor);
                

                    myFinalUkforBelow4neighboursPoint = OffsetPoint2;

            }
















            //  3 Neighbour Planes: Intersection Point of offseted Plane Plane Plane

            if (myNiceUniqueNoDupPlanes.Count == 3)
            {

                // A Function to get the intersection point of three offseted Planes  (Three neighbour Planes)
                Point3d myPlaneIntersectionPoint3 = OffsetPlanePlanePlaneIntersectionPoint(myNiceUniqueNoDupPlanes, initialEdgeStartP, height);

                myFinalUkforBelow4neighboursPoint = myPlaneIntersectionPoint3;

            }


            //Adding the  in ifs created sidleines to a list (as Nurb)

            if (myNiceUniqueNoDupPlanes.Count == 1 | myNiceUniqueNoDupPlanes.Count == 2 | myNiceUniqueNoDupPlanes.Count == 3)
            {

                // Create the SideLine below 4 neighbours START P

                Line mySideLineBelow4NeighboursStartP = new Line(initialEdgeStartP, myFinalUkforBelow4neighboursPoint);

                NurbsCurve mySidleineNurbBelow4neighboursStart = mySideLineBelow4NeighboursStartP.ToNurbsCurve();

                mySideLines.Add(mySidleineNurbBelow4neighboursStart);
            }







            // If more than 3 neighbour Planes: Offset with Nodeback for node outcut (StartPoint)



            Point3d UKMP = (myUKpoint0 + myUKpoint1) / 2;

            Vector3d HyperMoveVec = UKMP - myUKpoint0;

            HyperMoveVec.Unitize();

            Point3d myNodeclosest = UKMP;

            double myNodeClosestDist = 10000000000000000;

            double myMoveDist = (UKMP.DistanceTo(myUKpoint0) / checkSteps) * 2;

            double anglefactor0 = THEinSideAnglesLFactor;  //inSideAnglesLFactors[i];



            if (myNiceUniqueNoDupPlanes.Count > 3)

            {



      //her was naked check





                //NODEBACK 


                //   1     Point1 Start of the edge when more than 3 Neighbour Planes






                if (myNeighbourpolylinesStart1.Count > 1 | NakedCheckListStart.Count > 0)

                {


                    // Create points on the edge and check which is the closest to the top node point and not closer than CheckDist (to the top node point)

                    for (int j = 0; j < checkSteps; j++)
                    {
                        Point3d tempCheckPoint = myUKpoint0 + v1 * -1 * myMoveDist * j;

                        // Point3d tempCheckPoint = myUKpoint0 + HyperMoveVec * myMoveDist * j;

                        double tempCheckDist = tempCheckPoint.DistanceTo(initialEdgeStartP);

                        if (tempCheckDist > nodeBack * anglefactor0)
                        {
                            if (tempCheckDist < myNodeClosestDist)
                            {
                                myNodeclosest = tempCheckPoint;
                                myNodeClosestDist = tempCheckDist;
                            }
                        }
                    }


                }

                else

                {

                    myNodeclosest = myUKpoint0;

                }


                // Create the SideLine Start at more than 3 neighbour planes

                Line mySideLine = new Line(initialEdgeStartP, myNodeclosest);

                NurbsCurve mySidleineNurb = mySideLine.ToNurbsCurve();

                mySideLines.Add(mySidleineNurb);


            }






            //BELOW 4 Neighbours: END POINT











            //Is Naked Check END

            //Point3d mpOK = (initialEdgeStartP + initialEdgeEndP) / 2;


            List<int> NakedCheckListEnd = new List<int>();


            for (int i = 0; i < NakedEdge.Count; i++)
            {
                Point3d closestP = NakedEdge[i].ClosestPoint(initialEdgeEndP, true);

                double dist = closestP.DistanceTo(initialEdgeEndP);

                if (dist < 0.1)

                {
                    NakedCheckListEnd.Add(1);
                }
            }



















            Point3d myFinalUkforBelow4neighboursPointEND = (myUKpoint0 + myUKpoint1) / 2; //just a point to replace


            List<Plane> myNiceUniqueNoDupPlanesEnd = UniquePolygonPlanes(myNeighbourpolylinesEnd2withSelf, initialEdgeEndP, CheckAngle);



            /*
            //  1 Neighbour Plane: Offset in Plane Z

            if (myNiceUniqueNoDupPlanesEnd.Count == 1)
            {
                //A Function to move a point in a Planes Z vector (One Neighbour Plane)
                Point3d OffsetPoint1 = OffsetPointInPlaneZ(myNiceUniqueNoDupPlanesEnd[0], initialEdgeEndP, height);

                myFinalUkforBelow4neighboursPointEND = OffsetPoint1;

            }

            */



            //    //  1 Neighbour Plane: Offset in Plane Z and Nodeback if the middle part is edge adjacent  //(EndPoint))


            if (myNiceUniqueNoDupPlanesEnd.Count == 1)
            {

                if (myNeighbourpolylinesEnd2.Count > 1 | NakedCheckListEnd.Count > 0)
                {

                    //A Function to move a point in a Planes Z vector  + NODEBACK (One Neighbour Plane) 

                    //initialEdgeStartP, initialEdgeEndP

                    Point3d OffsetPoint1 = OffsetPointInPlaneZNodeBack(myNiceUniqueNoDupPlanesEnd[0], initialEdgeEndP, initialEdgeStartP, height, EdgeNodeBackFactor);

                }

                else

                {
                    //A Function to move a point in a Planes Z vector (One Neighbour Plane) NO NODEBACK
                    Point3d OffsetPoint1 = OffsetPointInPlaneZ(myNiceUniqueNoDupPlanesEnd[0], initialEdgeEndP, height);

                    myFinalUkforBelow4neighboursPointEND = OffsetPoint1;

                }

            }





















            /*

            //  2 Neighbour Planes: Offset in Bisecting Planes Z in correct length

            if (myNiceUniqueNoDupPlanesEnd.Count == 2)
            {
                //A Function to move a point in the bisecting vector of two planes Z vectors.
                //The amp (vector lenght) is calculated in dependence of the material thickness by the cos function.
                //(Two Neighbour Planes)

                Point3d OffsetPoint2 = OffsetPointInTwoPlanesZvec(myNiceUniqueNoDupPlanesEnd, initialEdgeEndP, height);

                myFinalUkforBelow4neighboursPointEND = OffsetPoint2;

            }

            */








            //  2 Neighbour Planes: Offset in Bisecting Planes Z in correct length  WITH EDGE NODE BACK

            if (myNiceUniqueNoDupPlanesEnd.Count == 2)
            {
                //A Function to move a point in the bisecting vector of two planes Z vectors.
                //The amp (vector lenght) is calculated in dependence of the material thickness by the cos function.
                //(Two Neighbour Planes)   

                //WITH NODE BACK                                                             //initialEdgeStartP, initialEdgeEndP,

                Point3d OffsetPoint2 = OffsetPointInTwoPlanesZvecNodeBack(myNiceUniqueNoDupPlanesEnd, initialEdgeEndP, initialEdgeStartP, height, EdgeNodeBackFactor);


                myFinalUkforBelow4neighboursPointEND = OffsetPoint2;

            }
















            //  3 Neighbour Planes: Intersection Point of offseted Plane Plane Plane

            if (myNiceUniqueNoDupPlanesEnd.Count == 3)
            {

                // A Function to get the intersection point of three offseted Planes  (Three neighbour Planes)
                Point3d myPlaneIntersectionPoint3 = OffsetPlanePlanePlaneIntersectionPoint(myNiceUniqueNoDupPlanesEnd, initialEdgeEndP, height);

                myFinalUkforBelow4neighboursPointEND = myPlaneIntersectionPoint3;

            }


            //Adding the in ifs created sidleins as nurb to a list


            if (myNiceUniqueNoDupPlanesEnd.Count == 1 | myNiceUniqueNoDupPlanesEnd.Count == 2 | myNiceUniqueNoDupPlanesEnd.Count == 3)
            {


                // Create the SideLine below 4 neighbours START P

                Line mySideLineBelow4NeighboursEndP = new Line(initialEdgeEndP, myFinalUkforBelow4neighboursPointEND);

                NurbsCurve mySidleineNurbBelow4neighboursEnd = mySideLineBelow4NeighboursEndP.ToNurbsCurve();

                mySideLines.Add(mySidleineNurbBelow4neighboursEnd);

            }






            if (myNiceUniqueNoDupPlanesEnd.Count > 3)
            {




          











                //2     Point2 End of the edge

                //   Point3d StartRangePointEdge2 = myUKpoint1 + v1 * EdgeLength * 0.3;


                Point3d UKMP2 = (myUKpoint0 + myUKpoint1) / 2;

                Vector3d HyperVec22 = UKMP2 - myUKpoint1;

                HyperVec22.Unitize();


                //   Line TestLine2 = new Line(StartRangePointEdge2, EndRangePointEdge2);
                //   mySideLines.Add(TestLine2.ToNurbsCurve()); //Dangerous, just to check



                Point3d myNodeclosest2 = UKMP2;

                //   Point3d myNodeclosest2 = new Point3d();
                //  Point3d myNodeclosest2 = StartRangePointEdge2;



                double myNodeClosestDist2 = 10000000000000000;

                double anglefactor1 = THEinSideAnglesLFactor2End; //inSideAnglesLFactors[i + 1];







                if (myNeighbourpolylinesEnd2.Count > 1 | NakedCheckListEnd.Count > 0)

                {

                    // Create points on the edge an check which is closest to the top node point and not closer than CheckDist (to the top node point)

                    for (int j = 0; j < checkSteps; j++)
                    {
                        Point3d tempCheckPoint2 = myUKpoint1 + v1 * myMoveDist * j;


                        //  Point3d tempCheckPoint2 = myUKpoint1 + HyperVec22 * myMoveDist * j;


                        double tempCheckDist2 = tempCheckPoint2.DistanceTo(initialEdgeEndP);

                        if (tempCheckDist2 > nodeBack * anglefactor1)
                        {
                            if (tempCheckDist2 < myNodeClosestDist2)
                            {
                                myNodeclosest2 = tempCheckPoint2;
                                myNodeClosestDist2 = tempCheckDist2;
                            }
                        }
                    }


                }

                else

                {

                    myNodeclosest2 = myUKpoint1;

                }






                // Create the SideLine

                Line mySideLine2 = new Line(initialEdgeEndP, myNodeclosest2);

                NurbsCurve mySidleineNurb2 = mySideLine2.ToNurbsCurve();

                mySideLines.Add(mySidleineNurb2);


            }




            return mySideLines;



        }










        //A Function to set back the lower node //NODEBACK at EDGE SITUATIONS              // WITH PLANE INTERSECTION   

        public static List<NurbsCurve> NodebackEdgePI(List<Line> NakedEdge, int checksteps, List<Polyline> myNeighbourpolylinesStart1, List<Polyline> myNeighbourpolylinesEnd2, List<Polyline> myNeighbourpolylinesStart1withSelf, List<Polyline> myNeighbourpolylinesEnd2withSelf, Vector3d v1, Point3d myNeighbourCenterPoint, Point3d initialEdgeStartP, Point3d initialEdgeEndP, double height, double EdgeLength, double THEinSideAnglesLFactor, double THEinSideAnglesLFactor2End, double nodeBack, double CheckAngle)
        {



            List<NurbsCurve> mySideLines = new List<NurbsCurve>();


            //move vec and move

            Vector3d moveVec = Vector3d.CrossProduct(v1, myNeighbourCenterPoint - initialEdgeStartP);

            moveVec.Unitize();

            Point3d myUKpoint0 = initialEdgeStartP + moveVec * height;      //StartEdge

            Point3d myUKpoint1 = initialEdgeEndP + moveVec * height;  //End Edge

            v1.Unitize();  // is necesssary!!





            /*
           
            //no nodeback necessary is  necessary if the nodepoint has 3 or less different neighbourplanes 
         

            //Notes:

            If:

            1 Plane: Offset in Plane Z

            2 Different Planes: Bisecting ze Vec in correct length: see above just takemy UKpoint0 and  myUKpoint1  (no NodeBack!)

            3 Different Planes: Plane Plane Plane Intersection Point

            ELSE:

            4 Different Planes and More: Node Back! everything as already in the code 


            */





            //CHECK How many different NeighboursPlanes are at the START POINT



            //A Function to get a list with as many different polygon planes as there are different  polygons (different normal Vecs) in the input list (get all unic planes (get all unic planes around one node).
            //This Function calls other Fuctions(which call functions): PolygonPlane, PolyGonNormal, PolygonAverage

           // double myNormaCompareChecklTol = 0.07;

            List<Plane> myNiceUniqueNoDupPlanes = UniquePolygonPlanes(myNeighbourpolylinesStart1withSelf, initialEdgeStartP, CheckAngle);

            //initialEdgeEndP for copy



            //BELOW 4 Neighbours: START POINT



            Point3d myFinalUkforBelow4neighboursPoint = (myUKpoint0 + myUKpoint1) / 2; //just a point to replace



            //  1 Neighbour Plane: Offset in Plane Z

            if (myNiceUniqueNoDupPlanes.Count == 1)
            {
                //A Function to move a point in a Planes Z vector (One Neighbour Plane)
                Point3d OffsetPoint1 = OffsetPointInPlaneZ(myNiceUniqueNoDupPlanes[0], initialEdgeStartP, height);

                myFinalUkforBelow4neighboursPoint = OffsetPoint1;

            }




            //  2 Neighbour Planes: Offset in Bisecting Planes Z in correct length

            if (myNiceUniqueNoDupPlanes.Count == 2)
            {
                //A Function to move a point in the bisecting vector of two planes Z vectors.
                //The amp (vector lenght) is calculated in dependence of the material thickness by the cos function.
                //(Two Neighbour Planes)

                Point3d OffsetPoint2 = OffsetPointInTwoPlanesZvec(myNiceUniqueNoDupPlanes, initialEdgeStartP, height);

                myFinalUkforBelow4neighboursPoint = OffsetPoint2;

            }






            //  3 Neighbour Planes: Intersection Point of offseted Plane Plane Plane

            if (myNiceUniqueNoDupPlanes.Count == 3)
            {

                // A Function to get the intersection point of three offseted Planes  (Three neighbour Planes)
                Point3d myPlaneIntersectionPoint3 = OffsetPlanePlanePlaneIntersectionPoint(myNiceUniqueNoDupPlanes, initialEdgeStartP, height);

                myFinalUkforBelow4neighboursPoint = myPlaneIntersectionPoint3;

            }




            if (myNiceUniqueNoDupPlanes.Count == 1 | myNiceUniqueNoDupPlanes.Count == 2 | myNiceUniqueNoDupPlanes.Count == 3)
            {

                // Create the SideLine below 4 neighbours START P

                Line mySideLineBelow4NeighboursStartP = new Line(initialEdgeStartP, myFinalUkforBelow4neighboursPoint);

                NurbsCurve mySidleineNurbBelow4neighboursStart = mySideLineBelow4NeighboursStartP.ToNurbsCurve();

                mySideLines.Add(mySidleineNurbBelow4neighboursStart);
            }


            // If more than 3 neighbour Planes: Offset with Nodeback for node outcut





            Point3d UKMP = (myUKpoint0 + myUKpoint1) / 2;

            Vector3d HyperMoveVec = UKMP - myUKpoint0;

            HyperMoveVec.Unitize();

            double myMoveDist = (UKMP.DistanceTo(myUKpoint0) / checksteps) * 2;

            Point3d myNodeclosest = UKMP;

            double myNodeClosestDist = 10000000000000000;

            double anglefactor0 = THEinSideAnglesLFactor;  // inSideAnglesLFactor[i]





            //Is Naked Check

            Point3d mpOK = (initialEdgeStartP + initialEdgeEndP) / 2;

            List<int> NakedCheckList = new List<int>();

            for (int i = 0; i < NakedEdge.Count; i++)
            {
                Point3d closestP = NakedEdge[i].ClosestPoint(mpOK, true);
                double dist = closestP.DistanceTo(mpOK);
                if (dist < 0.1)
                {
                    NakedCheckList.Add(1);
                }
            }




            //NODEBACK Start P

            if (myNiceUniqueNoDupPlanes.Count > 3)
            {



                //NODEBACK



                // 1 Startpoint of the Edge




                // Create points on the edge an check which is closest to the top node point and not closer than CheckDist (to the top node point)




                if (NakedCheckList.Count > 0)

                {


                    for (int j = 0; j < checksteps; j++)
                    {
                        //Point3d tempCheckPoint = myUKpoint0 + HyperMoveVec * myMoveDist * j;

                        Point3d tempCheckPoint = myUKpoint0 + v1 * -1 * myMoveDist * j;


                        double tempCheckDist = tempCheckPoint.DistanceTo(initialEdgeStartP);



                        if (tempCheckDist > nodeBack * anglefactor0)
                        {
                            if (tempCheckDist < myNodeClosestDist)
                            {
                                myNodeclosest = tempCheckPoint;
                                myNodeClosestDist = tempCheckDist;
                            }
                        }
                    }



                }

                else

                {




                    if (myNeighbourpolylinesStart1.Count > 1)

                    {

                        for (int j = 0; j < checksteps; j++)
                        {
                            //Point3d tempCheckPoint = myUKpoint0 + HyperMoveVec * myMoveDist * j;

                            Point3d tempCheckPoint = myUKpoint0 + v1 * -1 * myMoveDist * j;


                            double tempCheckDist = tempCheckPoint.DistanceTo(initialEdgeStartP);



                            if (tempCheckDist > nodeBack * anglefactor0)
                            {
                                if (tempCheckDist < myNodeClosestDist)
                                {
                                    myNodeclosest = tempCheckPoint;
                                    myNodeClosestDist = tempCheckDist;
                                }
                            }
                        }


                    }


                    else
                    {

                        myNodeclosest = myUKpoint0;


                    }


                }



                //   Point3d myNodeclosest = myUKpoint0;  //checkTest


                // Create the SideLine

                Line mySideLine = new Line(initialEdgeStartP, myNodeclosest);

                NurbsCurve mySidleineNurb = mySideLine.ToNurbsCurve();

                mySideLines.Add(mySidleineNurb);

            }





            //BELOW 4 Neighbours: END POINT


            //A Function to get a list with as many different polygon planes as there are different  polygons (different normal Vecs) in the input list (get all unic planes (get all unic planes around one node).
            //This Function calls other Fuctions(which call functions): PolygonPlane, PolyGonNormal, PolygonAverage




            List<Plane> myNiceUniqueNoDupPlanesEnd = UniquePolygonPlanes(myNeighbourpolylinesEnd2withSelf, initialEdgeEndP, CheckAngle);




            Point3d myFinalUkforBelow4neighboursPointEND = (myUKpoint0 + myUKpoint1) / 2; //just a point to replace



            //  1 Neighbour Plane: Offset in Plane Z

            if (myNiceUniqueNoDupPlanesEnd.Count == 1)
            {
                //A Function to move a point in a Planes Z vector (One Neighbour Plane)
                Point3d OffsetPoint1 = OffsetPointInPlaneZ(myNiceUniqueNoDupPlanesEnd[0], initialEdgeEndP, height);

                myFinalUkforBelow4neighboursPointEND = OffsetPoint1;

            }




            //  2 Neighbour Planes: Offset in Bisecting Planes Z in correct length

            if (myNiceUniqueNoDupPlanesEnd.Count == 2)
            {
                //A Function to move a point in the bisecting vector of two planes Z vectors.
                //The amp (vector lenght) is calculated in dependence of the material thickness by the cos function.
                //(Two Neighbour Planes)

                Point3d OffsetPoint2 = OffsetPointInTwoPlanesZvec(myNiceUniqueNoDupPlanesEnd, initialEdgeEndP, height);

                myFinalUkforBelow4neighboursPointEND = OffsetPoint2;

            }






            //  3 Neighbour Planes: Intersection Point of offseted Plane Plane Plane

            if (myNiceUniqueNoDupPlanesEnd.Count == 3)
            {

                // A Function to get the intersection point of three offseted Planes  (Three neighbour Planes)
                Point3d myPlaneIntersectionPoint3 = OffsetPlanePlanePlaneIntersectionPoint(myNiceUniqueNoDupPlanesEnd, initialEdgeEndP, height);

                myFinalUkforBelow4neighboursPointEND = myPlaneIntersectionPoint3;

            }


            if (myNiceUniqueNoDupPlanesEnd.Count == 1 | myNiceUniqueNoDupPlanesEnd.Count == 2 | myNiceUniqueNoDupPlanesEnd.Count == 3)
            {



                // Create the SideLine below 4 neighbours START P

                Line mySideLineBelow4NeighboursEndP = new Line(initialEdgeEndP, myFinalUkforBelow4neighboursPointEND);

                NurbsCurve mySidleineNurbBelow4neighboursEnd = mySideLineBelow4NeighboursEndP.ToNurbsCurve();

                mySideLines.Add(mySidleineNurbBelow4neighboursEnd);


            }





            if (myNiceUniqueNoDupPlanesEnd.Count > 3)
            {




                // 2  Endpoint of the Edges



                Point3d UKMP2 = (myUKpoint0 + myUKpoint1) / 2;

                Vector3d HyperVec22 = UKMP2 - myUKpoint1;

                HyperVec22.Unitize();


                Point3d myNodeclosest2 = UKMP2;

                double myNodeClosestDist2 = 10000000000000000;

                double anglefactor1 = THEinSideAnglesLFactor2End;  //inSideAnglesLFactors[i + 1];





                // Create points on the edge an check which is closest to the top node point and not closer than CheckDist (to the top node point)



                if (NakedCheckList.Count > 0)

                {

                    for (int j = 0; j < checksteps; j++)
                    {
                        //  Point3d tempCheckPoint2 = myUKpoint1 + HyperVec22 * myMoveDist * j;

                        Point3d tempCheckPoint2 = myUKpoint1 + v1 * myMoveDist * j;

                        double tempCheckDist2 = tempCheckPoint2.DistanceTo(initialEdgeEndP);

                        if (tempCheckDist2 > nodeBack * anglefactor1)
                        {
                            if (tempCheckDist2 < myNodeClosestDist2)
                            {
                                myNodeclosest2 = tempCheckPoint2;
                                myNodeClosestDist2 = tempCheckDist2;
                            }
                        }
                    }
                }

                else
                {



                    if (myNeighbourpolylinesEnd2.Count > 1)

                    {

                        for (int j = 0; j < checksteps; j++)
                        {
                            //  Point3d tempCheckPoint2 = myUKpoint1 + HyperVec22 * myMoveDist * j;

                            Point3d tempCheckPoint2 = myUKpoint1 + v1 * myMoveDist * j;

                            double tempCheckDist2 = tempCheckPoint2.DistanceTo(initialEdgeEndP);

                            if (tempCheckDist2 > nodeBack * anglefactor1)
                            {
                                if (tempCheckDist2 < myNodeClosestDist2)
                                {
                                    myNodeclosest2 = tempCheckPoint2;
                                    myNodeClosestDist2 = tempCheckDist2;
                                }
                            }
                        }

                    }


                    else

                    {

                        myNodeclosest2 = myUKpoint1;
                    }

                }


                // Point3d myNodeclosest2 = myUKpoint1;  //just check

                // Create the SideLine

                Line mySideLine2 = new Line(initialEdgeEndP, myNodeclosest2);

                NurbsCurve mySidleineNurb2 = mySideLine2.ToNurbsCurve();

                mySideLines.Add(mySidleineNurb2);


            }


            return mySideLines;





        }










        // A FUNCTION to set back the lower node //NODEBACK at MIDDLE  SITUATIONS   //NO PLANE INTERSECTION ALWAYS NODE BACK   

        public static List<NurbsCurve> NodebackMiddle(List<Line> NakedEdge, int checkSteps, List<Polyline> myNeighbourpolylinesStart1, List<Polyline> myNeighbourpolylinesEnd2, List<Vector3d> myNeighbourVectors, Vector3d v1, Point3d myNeighbourCenterPoint, Point3d initialEdgeStartP, Point3d initialEdgeEndP, double height, double EdgeLength, double THEinSideAnglesLFactor, double THEinSideAnglesLFactor2End, double nodeBack)
        {

            List<NurbsCurve> mySideLines = new List<NurbsCurve>();  //for return



            Vector3d moveVecSum2 = myNeighbourVectors[0] + myNeighbourVectors[1];  //  myNeighbourVectors[0]
            moveVecSum2.Unitize();

            double alpha = Vector3d.VectorAngle(moveVecSum2, myNeighbourVectors[1]);

            double Hypothenuse = height / System.Math.Cos(alpha);

            Point3d myUKpoint0 = initialEdgeStartP + moveVecSum2 * Hypothenuse * -1;
            Point3d myUKpoint1 = initialEdgeEndP + moveVecSum2 * Hypothenuse * -1;







            v1.Unitize();  // is necesssary!!





            //Is Naked Check START

            //Point3d mpOK = (initialEdgeStartP + initialEdgeEndP) / 2;



            List<int> NakedCheckListStart = new List<int>();



            for (int i = 0; i < NakedEdge.Count; i++)
            {
                Point3d closestP = NakedEdge[i].ClosestPoint(initialEdgeStartP, true);

                double dist = closestP.DistanceTo(initialEdgeStartP);

                if (dist < 0.1)

                {
                    NakedCheckListStart.Add(1);
                }
            }









            //Is Naked Check END

            //Point3d mpOK = (initialEdgeStartP + initialEdgeEndP) / 2;



            List<int> NakedCheckListEnd = new List<int>();



            for (int i = 0; i < NakedEdge.Count; i++)
            {
                Point3d closestP = NakedEdge[i].ClosestPoint(initialEdgeEndP, true);

                double dist = closestP.DistanceTo(initialEdgeEndP);

                if (dist < 0.1)

                {
                    NakedCheckListEnd.Add(1);
                }
            }
















            //NODEBACK


            //   1     Point1 Start of the edge


            Point3d UKMP = (myUKpoint0 + myUKpoint1) / 2;

            Vector3d HyperMoveVec = UKMP - myUKpoint0;

            HyperMoveVec.Unitize();



            //   Line TestLine1 = new Line(StartRangePointEdge, EndRangePointEdge);

            //   mySideLines.Add(TestLine1.ToNurbsCurve());  //Dangerous, just to check




            Point3d myNodeclosest = UKMP;

            //   Point3d myNodeclosest = new Point3d();
            //  Point3d myNodeclosest = StartRangePointEdge;


            double myNodeClosestDist = 10000000000000000;


            //  int checkSteps = 50;

            double myMoveDist = (UKMP.DistanceTo(myUKpoint0) / checkSteps) * 2;

            double anglefactor0 = THEinSideAnglesLFactor;  //inSideAnglesLFactors[i];






            if (myNeighbourpolylinesStart1.Count > 1 | NakedCheckListStart.Count > 0)

            {


                // Create points on the edge and check which is the closest to the top node point and not closer than CheckDist (to the top node point)

                for (int j = 0; j < checkSteps; j++)
                {
                    Point3d tempCheckPoint = myUKpoint0 + v1 * -1 * myMoveDist * j;

                    // Point3d tempCheckPoint = myUKpoint0 + HyperMoveVec * myMoveDist * j;

                    double tempCheckDist = tempCheckPoint.DistanceTo(initialEdgeStartP);

                    if (tempCheckDist > nodeBack * anglefactor0)
                    {
                        if (tempCheckDist < myNodeClosestDist)
                        {
                            myNodeclosest = tempCheckPoint;
                            myNodeClosestDist = tempCheckDist;
                        }
                    }
                }


            }

            else

            {

                myNodeclosest = myUKpoint0;

            }





            // Create the SideLine

            Line mySideLine = new Line(initialEdgeStartP, myNodeclosest);

            NurbsCurve mySidleineNurb = mySideLine.ToNurbsCurve();

            mySideLines.Add(mySidleineNurb);







            //2     Point2 End of the edge

            //   Point3d StartRangePointEdge2 = myUKpoint1 + v1 * EdgeLength * 0.3;


            Point3d UKMP2 = (myUKpoint0 + myUKpoint1) / 2;

            Vector3d HyperVec22 = UKMP2 - myUKpoint1;

            HyperVec22.Unitize();


            //   Line TestLine2 = new Line(StartRangePointEdge2, EndRangePointEdge2);
            //   mySideLines.Add(TestLine2.ToNurbsCurve()); //Dangerous, just to check



            Point3d myNodeclosest2 = UKMP2;

            //   Point3d myNodeclosest2 = new Point3d();
            //  Point3d myNodeclosest2 = StartRangePointEdge2;



            double myNodeClosestDist2 = 10000000000000000;

            double anglefactor1 = THEinSideAnglesLFactor2End; //inSideAnglesLFactors[i + 1];







            if (myNeighbourpolylinesEnd2.Count > 1 | NakedCheckListEnd.Count > 0)

            {

                // Create points on the edge an check which is closest to the top node point and not closer than CheckDist (to the top node point)

                for (int j = 0; j < checkSteps; j++)
                {
                    Point3d tempCheckPoint2 = myUKpoint1 + v1 * myMoveDist * j;


                    //  Point3d tempCheckPoint2 = myUKpoint1 + HyperVec22 * myMoveDist * j;


                    double tempCheckDist2 = tempCheckPoint2.DistanceTo(initialEdgeEndP);

                    if (tempCheckDist2 > nodeBack * anglefactor1)
                    {
                        if (tempCheckDist2 < myNodeClosestDist2)
                        {
                            myNodeclosest2 = tempCheckPoint2;
                            myNodeClosestDist2 = tempCheckDist2;
                        }
                    }
                }


            }

            else

            {

                myNodeclosest2 = myUKpoint1;

            }






            // Create the SideLine

            Line mySideLine2 = new Line(initialEdgeEndP, myNodeclosest2);

            NurbsCurve mySidleineNurb2 = mySideLine2.ToNurbsCurve();

            mySideLines.Add(mySidleineNurb2);


            return mySideLines;


        }










        //A Function to set back the lower node //NODEBACK at EDGE SITUATIONS  //NO PLANE INTERSECTION ALWAYS NODE BACK   

        public static List<NurbsCurve> NodebackEdge(List<Line> NakedEdge, int checksteps, List<Polyline> myNeighbourpolylinesStart1, List<Polyline> myNeighbourpolylinesEnd2, Vector3d v1, Point3d myNeighbourCenterPoint, Point3d initialEdgeStartP, Point3d initialEdgeEndP, double height, double EdgeLength, double THEinSideAnglesLFactor, double THEinSideAnglesLFactor2End, double nodeBack)
        {



            List<NurbsCurve> mySideLines = new List<NurbsCurve>();


            //move vec and move

            Vector3d moveVec = Vector3d.CrossProduct(v1, myNeighbourCenterPoint - initialEdgeStartP);

            moveVec.Unitize();

            Point3d myUKpoint0 = initialEdgeStartP + moveVec * height;      //StartEdge

            Point3d myUKpoint1 = initialEdgeEndP + moveVec * height;  //End Edge

            v1.Unitize();  // is necesssary!!



            //Is Naked Check

            Point3d mpOK = (initialEdgeStartP + initialEdgeEndP) / 2;



            List<int> NakedCheckList = new List<int>();



            for (int i = 0; i < NakedEdge.Count; i++)
            {
                Point3d closestP = NakedEdge[i].ClosestPoint(mpOK, true);

                double dist = closestP.DistanceTo(mpOK);

                if (dist < 0.1)

                {
                    NakedCheckList.Add(1);
                }
            }








            //Vector3d v1 = initialEdgeStartP - initialEdgeEndP;

            //NODEBACK



            // 1 Startpoint of the Edge





            Point3d UKMP = (myUKpoint0 + myUKpoint1) / 2;

            Vector3d HyperMoveVec = UKMP - myUKpoint0;

            HyperMoveVec.Unitize();

            double myMoveDist = (UKMP.DistanceTo(myUKpoint0) / checksteps) * 2;


            //  Point3d myNodeclosest = new Point3d();
            Point3d myNodeclosest = UKMP;

            double myNodeClosestDist = 10000000000000000;


            //  int checkSteps = 50;



            double anglefactor0 = THEinSideAnglesLFactor;  // inSideAnglesLFactor[i]


            // Create points on the edge an check which is closest to the top node point and not closer than CheckDist (to the top node point)




            if (NakedCheckList.Count > 0)

            {


                for (int j = 0; j < checksteps; j++)
                {
                    //Point3d tempCheckPoint = myUKpoint0 + HyperMoveVec * myMoveDist * j;

                    Point3d tempCheckPoint = myUKpoint0 + v1 * -1 * myMoveDist * j;


                    double tempCheckDist = tempCheckPoint.DistanceTo(initialEdgeStartP);



                    if (tempCheckDist > nodeBack * anglefactor0)
                    {
                        if (tempCheckDist < myNodeClosestDist)
                        {
                            myNodeclosest = tempCheckPoint;
                            myNodeClosestDist = tempCheckDist;
                        }
                    }
                }



            }

            else

            {




                if (myNeighbourpolylinesStart1.Count > 1)

                {

                    for (int j = 0; j < checksteps; j++)
                    {
                        //Point3d tempCheckPoint = myUKpoint0 + HyperMoveVec * myMoveDist * j;

                        Point3d tempCheckPoint = myUKpoint0 + v1 * -1 * myMoveDist * j;


                        double tempCheckDist = tempCheckPoint.DistanceTo(initialEdgeStartP);



                        if (tempCheckDist > nodeBack * anglefactor0)
                        {
                            if (tempCheckDist < myNodeClosestDist)
                            {
                                myNodeclosest = tempCheckPoint;
                                myNodeClosestDist = tempCheckDist;
                            }
                        }
                    }


                }


                else
                {

                    myNodeclosest = myUKpoint0;


                }


            }

            //   Point3d myNodeclosest = myUKpoint0;  //checkTest




            // Create the SideLine

            Line mySideLine = new Line(initialEdgeStartP, myNodeclosest);

            NurbsCurve mySidleineNurb = mySideLine.ToNurbsCurve();

            mySideLines.Add(mySidleineNurb);








            // 2  Endpoint of the Edges



            Point3d UKMP2 = (myUKpoint0 + myUKpoint1) / 2;

            Vector3d HyperVec22 = UKMP2 - myUKpoint1;

            HyperVec22.Unitize();


            Point3d myNodeclosest2 = UKMP2;

            double myNodeClosestDist2 = 10000000000000000;

            double anglefactor1 = THEinSideAnglesLFactor2End;  //inSideAnglesLFactors[i + 1];





            // Create points on the edge an check which is closest to the top node point and not closer than CheckDist (to the top node point)



            if (NakedCheckList.Count > 0)

            {

                for (int j = 0; j < checksteps; j++)
                {
                    //  Point3d tempCheckPoint2 = myUKpoint1 + HyperVec22 * myMoveDist * j;

                    Point3d tempCheckPoint2 = myUKpoint1 + v1 * myMoveDist * j;

                    double tempCheckDist2 = tempCheckPoint2.DistanceTo(initialEdgeEndP);

                    if (tempCheckDist2 > nodeBack * anglefactor1)
                    {
                        if (tempCheckDist2 < myNodeClosestDist2)
                        {
                            myNodeclosest2 = tempCheckPoint2;
                            myNodeClosestDist2 = tempCheckDist2;
                        }
                    }
                }
            }

            else
            {



                if (myNeighbourpolylinesEnd2.Count > 1)

                {


                    for (int j = 0; j < checksteps; j++)
                    {
                        //  Point3d tempCheckPoint2 = myUKpoint1 + HyperVec22 * myMoveDist * j;

                        Point3d tempCheckPoint2 = myUKpoint1 + v1 * myMoveDist * j;

                        double tempCheckDist2 = tempCheckPoint2.DistanceTo(initialEdgeEndP);

                        if (tempCheckDist2 > nodeBack * anglefactor1)
                        {
                            if (tempCheckDist2 < myNodeClosestDist2)
                            {
                                myNodeclosest2 = tempCheckPoint2;
                                myNodeClosestDist2 = tempCheckDist2;
                            }
                        }
                    }

                }


                else

                {

                    myNodeclosest2 = myUKpoint1;
                }

            }


            // Point3d myNodeclosest2 = myUKpoint1;  //just check

            // Create the SideLine

            Line mySideLine2 = new Line(initialEdgeEndP, myNodeclosest2);

            NurbsCurve mySidleineNurb2 = mySideLine2.ToNurbsCurve();

            mySideLines.Add(mySidleineNurb2);




            return mySideLines;





        }

























        // Correct Sidleines: A fucntion to set back lower nodepoints to the points setted back in dependdence of the to inside angle 
        //(nicht zurückgesetzte Punkte auf die zurückgesetzten zurücksetzten dort wo sonst ein Absatz entstehen würde wegen dem Winkelabhängigen zurücksetzen)
        //Checks if nodes(Endpoints at outcut/nodeback low) of neighbours are on the edge (low) to correct / shorten the edge to the neigbour point on it

        public static List<List<Line>> SetNodeBackToAngleAdjust(List<List<NurbsCurve>> myListListSuperSideLines, double AdjustCeckDistFactor)
        {


            List<List<Line>> myListListSuperSideLinesAdjusted = new List<List<Line>>();  //return






            // Adding the first Sideline (of the sublist)  at the last position (of the sublist)


            List<List<NurbsCurve>> myListListSuperSideLinesAndStartAtEnd = new List<List<NurbsCurve>>();
            List<Point3d> allLowPoints = new List<Point3d>();




            for (int i = 0; i < myListListSuperSideLines.Count; i++)
            {
                List<NurbsCurve> tempNC = new List<NurbsCurve>();

                for (int j = 0; j < myListListSuperSideLines[i].Count; j++)
                {
                    tempNC.Add(myListListSuperSideLines[i][j]);


                    allLowPoints.Add(myListListSuperSideLines[i][j].PointAtEnd);
                }

                tempNC.Add(tempNC[0]);                                      //here Out of range
                myListListSuperSideLinesAndStartAtEnd.Add(tempNC);
            }








            for (int i = 0; i < myListListSuperSideLinesAndStartAtEnd.Count; i++)
            {
                List<Line> AdjustedLines = new List<Line>();


                for (int j = 0; j < myListListSuperSideLinesAndStartAtEnd[i].Count - 1; j++)
                {


                    if (j % 2 == 0)
                    {



                        //      Console.WriteLine("Test");


                        NurbsCurve myNurb = myListListSuperSideLinesAndStartAtEnd[i][j];
                        NurbsCurve myNurb2 = myListListSuperSideLinesAndStartAtEnd[i][j + 1];

                        Point3d p1 = myNurb.PointAtEnd;
                        Point3d p2 = myNurb2.PointAtEnd;

                        Point3d p1StartTop = myNurb.PointAtStart;
                        Point3d p2EndTop = myNurb2.PointAtStart;


                        Line myLine = new Line(p1, p2);

                        //Testlines.Add(myLine);


                        List<Point3d> potentialPoints = new List<Point3d>();


                        Point3d mySuperAdjustedFinalStart = new Point3d();

                        Point3d mySuperAdjustedFinalEnd = new Point3d();


                        for (int k = 0; k < allLowPoints.Count; k++)
                        {
                            Point3d myCP = myLine.ClosestPoint(allLowPoints[k], true);


                            if (myCP.DistanceTo(allLowPoints[k]) < 0.01)

                            {

                                double t1 = myLine.ClosestParameter(myCP);


                                // double tE = myLine.ClosestParameter(myLine.ToNurbsCurve().PointAtEnd);   //HERE OUT OF RANGE OR NULL

                                double myLineLength2 = myLine.Length;
                                Point3d myEndPoint = myLine.PointAtLength(myLineLength2);

                                double tE = myLine.ClosestParameter(myEndPoint);

                                if (t1 != 0 && t1 != tE)
                                {
                                    potentialPoints.Add(allLowPoints[k]);
                                    //TestPoints.Add(allLowPoints[k]);
                                }
                            }

                        }




                        //Point3d start = myLine.ToNurbsCurve().PointAtStart;   //hereNull
                        //Point3d End = myLine.ToNurbsCurve().PointAtEnd;



                        double myLineLength3 = myLine.Length;

                        Point3d start = myLine.PointAtLength(0);  //hereNull
                        Point3d End = myLine.PointAtLength(myLineLength3);



                        //potentialPoints.Add(start);
                        //potentialPoints.Add(End);
                        //Point3d mp222 = (start + End) / 2;



                        if (potentialPoints.Count > 0)
                        {
                            Point3d myAdjusted = new Point3d();
                            double myCheckDist333 = 200000000000;

                            for (int l = 0; l < potentialPoints.Count; l++)
                            {
                                double tDist = start.DistanceTo(potentialPoints[l]);

                                if (tDist < myCheckDist333)
                                {
                                    myCheckDist333 = tDist;
                                    myAdjusted = potentialPoints[l];
                                }
                            }


                            double AdjusDistTol = myLine.Length * AdjustCeckDistFactor;
                            // double AdjusDistTol = myLine.Length * 0.38;    AdjustCeckDistFactor


                            double rangeDist = myAdjusted.DistanceTo(start);

                            if (rangeDist < AdjusDistTol)
                            {
                                mySuperAdjustedFinalStart = myAdjusted;
                            }


                            else
                            {
                                mySuperAdjustedFinalStart = start;
                            }




                            Point3d myAdjusted2 = new Point3d();
                            double myCheckDist444 = 200000000000;

                            for (int l = 0; l < potentialPoints.Count; l++)
                            {
                                double tDist2 = End.DistanceTo(potentialPoints[l]);

                                if (tDist2 < myCheckDist444)
                                {
                                    myCheckDist444 = tDist2;
                                    myAdjusted2 = potentialPoints[l];
                                }
                            }



                            double rangeDist2 = myAdjusted2.DistanceTo(End);

                            if (rangeDist2 < AdjusDistTol)
                            {
                                mySuperAdjustedFinalEnd = myAdjusted2;
                            }

                            else
                            {
                                mySuperAdjustedFinalEnd = End;
                            }

                        }




                        else
                        {
                            mySuperAdjustedFinalStart = start;
                            mySuperAdjustedFinalEnd = End;
                        }





                        Line AdjustedLine1Start = new Line(p1StartTop, mySuperAdjustedFinalStart);

                        Line AdjustedLine2End = new Line(p2EndTop, mySuperAdjustedFinalEnd);

                        AdjustedLines.Add(AdjustedLine1Start);
                        AdjustedLines.Add(AdjustedLine2End);



                        //Testlines.Add(AdjustedLine1Start);
                        // Testlines.Add(AdjustedLine2End);




                    }  //here/close bracket



                }



                myListListSuperSideLinesAdjusted.Add(AdjustedLines);
            }

            return myListListSuperSideLinesAdjusted;

        }








        // A Function to get  the polyline Plane

        public static Plane PolygonPlane(Polyline iPolyL3)
        {
            //Vector3d v4 = iPolyL3[0] - iPolyL3[1];
            // Vector3d v5 = iPolyL3[0] - iPolyL3[2];


            // find the longes polyline edge to use it as Plane x Vec


            Vector3d myLongestX = new Vector3d();

            Vector3d myAdjacantY = new Vector3d();

            double myLongestDist = 0.000000000000001;



            // find the longes polyline edge to use it as Plane x Vec

            for (int j = 0; j < iPolyL3.Count - 1; j++)
            {

                double tDist = iPolyL3[j].DistanceTo(iPolyL3[j + 1]);

                if (tDist > myLongestDist)

                {
                    myLongestDist = tDist;

                    myLongestX = iPolyL3[j] - iPolyL3[j + 1];


                    if (j < 2)

                    {
                        myAdjacantY = (iPolyL3[j + 1] - iPolyL3[j + 2]);
                    }

                    else

                    {
                        myAdjacantY = (iPolyL3[j] - iPolyL3[j - 1]);
                    }

                }

            }



            Point3d PCenterT2 = new Point3d(0, 0, 0);

            for (int i = 0; i < iPolyL3.Count - 1; i++)
            {
                PCenterT2 = PCenterT2 + iPolyL3[i];
            }

            Point3d PCenter3 = PCenterT2 / (iPolyL3.Count - 1);


            Plane myTopPlane0 = new Plane(PCenter3, myLongestX, myAdjacantY * -1);


            return myTopPlane0;
        }








        //A Function to move a point in a Planes Z vector  (One Neighbour Plane)

        public static Point3d OffsetPointInPlaneZ(Plane myPlane0, Point3d iCheckpoint, double iOffsetDistMat)
        {
            Vector3d PlaneZvec = myPlane0.ZAxis;

            Point3d myMovedPoint1 = iCheckpoint + PlaneZvec * iOffsetDistMat;

            return myMovedPoint1;

        }




        //A Function to move a point in a Planes Z vector  + NODEBACK (One Neighbour Plane) 

        public static Point3d OffsetPointInPlaneZNodeBack(Plane myPlane0, Point3d iCheckpoint, Point3d NodeBackPoint, double iOffsetDistMat, double FactorEdgeNodeBack)
        {
            Vector3d PlaneZvec = myPlane0.ZAxis;

            Point3d myMovedPoint2 = iCheckpoint + PlaneZvec * iOffsetDistMat;


            Vector3d NodeBackVec = NodeBackPoint - iCheckpoint;

            NodeBackVec.Unitize();

            Point3d myMovedPoint3 = myMovedPoint2 + NodeBackVec * iOffsetDistMat * FactorEdgeNodeBack;

            return myMovedPoint3;
      

        }



























        //A Function to move a point in the bisecting vector of two planes Z vectors.
        //The amp (vector lenght) is calculated in dependence of the material thickness by the cos function.
        //(Two Neighbour Planes)

        public static Point3d OffsetPointInTwoPlanesZvec(List<Plane> myNiceUniqueNoDupPlanes, Point3d iCheckpoint, double iOffsetDistMat)
        {
            
            Plane myPlane0 = myNiceUniqueNoDupPlanes[0];
            Plane myPlane1 = myNiceUniqueNoDupPlanes[1];


            Vector3d moveVecSum2 = myPlane0.ZAxis + myPlane1.ZAxis;
            moveVecSum2.Unitize();

            double alpha = Vector3d.VectorAngle(moveVecSum2, myPlane0.ZAxis);

            double Hypothenuse = iOffsetDistMat / System.Math.Cos(alpha);

            Point3d myMovedPoint2 = iCheckpoint + moveVecSum2 * Hypothenuse;


            return myMovedPoint2;

            


            /*  //NodeBack in Cross vec

            Plane myPlane0 = myNiceUniqueNoDupPlanes[0];
            Plane myPlane1 = myNiceUniqueNoDupPlanes[1];


            Vector3d moveVecSum2 = myPlane0.ZAxis + myPlane1.ZAxis;
            moveVecSum2.Unitize();

            double alpha = Vector3d.VectorAngle(moveVecSum2, myPlane0.ZAxis);

            double Hypothenuse = iOffsetDistMat / System.Math.Cos(alpha);

            Point3d myMovedPoint2 = iCheckpoint + moveVecSum2 * Hypothenuse;



            Vector3d XprodVec = Vector3d.CrossProduct(myPlane0.ZAxis, myPlane1.ZAxis);

            XprodVec.Unitize();

            Point3d myMovedPoint3 = myMovedPoint2 + XprodVec * 50;


            return myMovedPoint3;

            */



        }

        //A Function to move a point in the bisecting vector of two planes Z vectors.
        //The amp (vector lenght) is calculated in dependence of the material thickness by the cos function.
        //(Two Neighbour Planes)   

        //WITH NODE BACK


        public static Point3d OffsetPointInTwoPlanesZvecNodeBack(List<Plane> myNiceUniqueNoDupPlanes, Point3d iCheckpoint, Point3d NodeBackPoint, double iOffsetDistMat, double FactorEdgeNodeBack)
        {

      

            Plane myPlane0 = myNiceUniqueNoDupPlanes[0];
            Plane myPlane1 = myNiceUniqueNoDupPlanes[1];


            Vector3d moveVecSum2 = myPlane0.ZAxis + myPlane1.ZAxis;
            moveVecSum2.Unitize();

            double alpha = Vector3d.VectorAngle(moveVecSum2, myPlane0.ZAxis);

            double Hypothenuse = iOffsetDistMat / System.Math.Cos(alpha);

            Point3d myMovedPoint2 = iCheckpoint + moveVecSum2 * Hypothenuse;



            Vector3d NodeBackVec = NodeBackPoint - iCheckpoint;

            NodeBackVec.Unitize();

            Point3d myMovedPoint3 = myMovedPoint2 + NodeBackVec * iOffsetDistMat * FactorEdgeNodeBack;


            return myMovedPoint3;

        

        }














        // A Function to get the intersection point of three offseted Planes   (Three neighbour Planes)

        public static Point3d OffsetPlanePlanePlaneIntersectionPoint(List<Plane> myNiceUniqueNoDupPlanes, Point3d iCheckpoint, double iOffsetDistMat)
        {

            //  Plane Plane Plane Offset and intersection

            List<Plane> myOffsetedPlanes = new List<Plane>();


            for (int i = 0; i < myNiceUniqueNoDupPlanes.Count; i++)
            {
                Plane myPlaneToOffset = myNiceUniqueNoDupPlanes[i];

                Point3d PlaneCenter = myPlaneToOffset.Origin;

                Vector3d PlaneZvec = myPlaneToOffset.ZAxis;

                Point3d myMovedOrigin = PlaneCenter + PlaneZvec * iOffsetDistMat;

                Plane myMovedPlane = new Plane(myMovedOrigin, myPlaneToOffset.XAxis, myPlaneToOffset.YAxis);

                myOffsetedPlanes.Add(myMovedPlane);

            }

            Plane myPlane0 = myOffsetedPlanes[0];
            Plane myPlane1 = myOffsetedPlanes[1];
            Plane myPlane2 = myOffsetedPlanes[2];

            Point3d myPlaneIntersectionPoint3;

            Rhino.Geometry.Intersect.Intersection.PlanePlanePlane(myPlane0, myPlane1, myPlane2, out myPlaneIntersectionPoint3);


            // oOffsetPoints3 = myPlaneIntersectionPoint3;

            return myPlaneIntersectionPoint3;

        }













        //A Function to get a list with as many different polygon planes as there are different  polygons (different normal Vecs) in the input list (get all unic planes around one node).
        //This Function calls other Fuctions(which call functions): PolygonPlane, PolyGonNormal, PolygonAverage

        public static List<Plane> UniquePolygonPlanes(List<Polyline> iPolyNeighbours, Point3d iCheckpoint, double myNormaCompareChecklTol)
        {


            List<Plane> myNoDupPlanes = new List<Plane>();

            /*
            Plane myPlane0 = new Plane();

            if (iPolyNeighbours.Count > 0)

            {
                Plane myPlane22 = PolygonPlane(iPolyNeighbours[0]);

            }  
            
            */

            //Brake here out of range


            Plane myPlane0 = PolygonPlane(iPolyNeighbours[0]);

            myNoDupPlanes.Add(myPlane0);



            /*
                List<Point3d> myPolyNoDupCentres = new List<Point3d>();

                Point3d myPcenter = PolylineAverage(iPolyNeighbours[0]);

                myPolyNoDupCentres.Add(myPcenter);

            */



            List<Vector3d> myNoDupNormals = new List<Vector3d>();

            Vector3d myNormal0 = PolygonNormal(iPolyNeighbours[0]);

            myNoDupNormals.Add(myNormal0);




            for (int i = 1; i < iPolyNeighbours.Count; i++)
            {

                Vector3d myNormalCheckI = PolygonNormal(iPolyNeighbours[i]);

                List<int> myCheckInts = new List<int>();



                for (int j = 0; j < myNoDupNormals.Count; j++)
                {

                    Vector3d myNormalCheckJ = myNoDupNormals[j];

                    double myCheckAngle = Rhino.Geometry.Vector3d.VectorAngle(myNormalCheckJ, myNormalCheckI);

                    double myCheckAngleDegree = Rhino.RhinoMath.ToDegrees(myCheckAngle);


                    if (myCheckAngleDegree < myNormaCompareChecklTol)
                    {
                        myCheckInts.Add(j);
                    }

                }



                if (myCheckInts.Count == 0)
                {

                    myNoDupNormals.Add(myNormalCheckI);

                    /*

                    Point3d mypcenter = PolylineAverage(iPolyNeighbours[i]);

                    myPolyNoDupCentres.Add(mypcenter);
                    */


                    Plane myNoDupPlane = PolygonPlane(iPolyNeighbours[i]);

                    myNoDupPlanes.Add(myNoDupPlane);

                }

                //myCheckInts.Clear();


            }


            return myNoDupPlanes;

        }


















        // A Function to remove duplicated lines calls also fuctions below...
        public static List<Line> RemoveDuplicates(List<Line> lines, double tolerance)
        {


            // Copy original list
            List<Line> clean = new List<Line>(lines);



            // Clean up the list of duplicates
            for (int i = 0; i < clean.Count; i++)
            {
                Line line = clean[i];

                for (int j = clean.Count - 1; j > i; j--)
                {
                    Line other = clean[j];

                    bool dup = AreDuplicate(line, other, tolerance);
                    if (dup == true)
                    {
                        clean.RemoveAt(j);
                    }
                }
            }

            return clean;


        }









        // Returns true if end points of lines are similar under tolerance value
        public static bool AreDuplicate(Line lineA, Line lineB, double tolerance)

        {
            // Compare starting points
            if (
              (AreSimilar(lineA.From, lineB.From, tolerance) && AreSimilar(lineA.To, lineB.To, tolerance))
              || (AreSimilar(lineA.From, lineB.To, tolerance) && AreSimilar(lineA.To, lineB.From, tolerance))
              )

            {
                return true;
            }

            else

            {

                return false;

            }
        }






        // Returns true if coordinates of points are similar under a threshold value
        public static bool AreSimilar(Point3d a, Point3d b, double tol)

        {
            bool similar = Math.Abs(a.X - b.X) < tol
              && Math.Abs(a.Y - b.Y) < tol
              && Math.Abs(a.Z - b.Z) < tol;

            return similar;
        }








        //MORE



        /// <summary>
        /// Provides an Icon for the component.
        /// </summary>
        protected override System.Drawing.Bitmap Icon
        {
            get
            {
                //You can add image files to your project resources and access them like this:
                // return Resources.IconForThisComponent;

                // return Resource1.dif_polygon_tr3;

                // return null;

                return Resource1.wip_333;
            }
        }
        public override Guid ComponentGuid
        {
            get { return new Guid("d1024c68-2375-4d7d-995e-988694607fa5"); }
        }
    }
}