﻿using System;
using System.Collections.Generic;

using Grasshopper.Kernel;
using Rhino.Geometry;



using Grasshopper.Kernel.Data;

namespace cHRC
{
    public class Component_Solid_Beam_Enforce : GH_Component
    {
        /// <summary>
        /// Initializes a new instance of the MyComponent1 class.
        /// </summary>
        public Component_Solid_Beam_Enforce()
          : base("01_EnforcementBeam", "EnforcementBeam",
              "A beam with a 90 degree cut at its end, as inforcement of plates with reduced node complexity",
              "cHRC", "02 Offset Geometry")
        {
        }

        /// <summary>
        /// Registers all the input parameters for this component.
        /// </summary>
        protected override void RegisterInputParams(GH_Component.GH_InputParamManager pManager)

        {



            pManager.AddCurveParameter("Polylines", "Pl", "Polyline Input for the offset, as list", GH_ParamAccess.list); //00



            pManager.AddNumberParameter("Thickness", "T", "The material thickness, structural height in mm", GH_ParamAccess.item, 50);  //05

            pManager.AddNumberParameter("OffsetBeam", "OB", "Offset the whole beam, for example if there is a plate on top of the beam based on the same input as the beam", GH_ParamAccess.item, 0.0);  //04

      



            pManager.AddBooleanParameter("CalcLines", "L", "If true, calculates the beams  side  curves, can be used as input for the  ClosedBrep component)  ", GH_ParamAccess.item, true);  //06

        //    pManager.AddBooleanParameter("CalcBrep", "CalcBrep", " If true, calculates an closed Brep  ", GH_ParamAccess.item, true);  //07

            pManager.AddBooleanParameter("CalcMesh", "M", "If true, calculates am mesh of each beam)  ", GH_ParamAccess.item, false);  //08



            pManager.AddNumberParameter("CheckDist", "CD", "The Distance from the polygon edges middlepoint to the neighbourpolygon in which the neighbour polygon is considered a neighbour (not a naked edge)", GH_ParamAccess.item, 0.01); //03



            //  pManager.AddBooleanParameter("Manual iteration", "Manual iteration", "True to limit the iterations", GH_ParamAccess.item, false);  //01

            pManager.AddIntegerParameter("StartIteration", "Si", "StartIndex if Manual iteration is true", GH_ParamAccess.item, -1); //03

            pManager.AddIntegerParameter("MaxIterations", "Mi", "Maximal Iteration Count if Manuak Itreration is true, should not be higher than Cinput Curve count minus start Iteration  index", GH_ParamAccess.item, -1); //02




        }

        /// <summary>
        /// Registers all the output parameters for this component.
        /// </summary>
        protected override void RegisterOutputParams(GH_Component.GH_OutputParamManager pManager)

        {

            pManager.AddCurveParameter("TopPolyline", "TPl", "The top polyline possibly with node outcut", GH_ParamAccess.list);  //00

            pManager.AddCurveParameter("Lowerpolyline", "LPl", "The lower polyline  with node outcut", GH_ParamAccess.list);  //01

            pManager.AddCurveParameter("SideCurves", "SC", "SideCurves as Tree", GH_ParamAccess.tree); //05


            //  pManager.AddCurveParameter("SideCurves", "SideCurves", "The curves (line-like) connecting the top and the lower polyline", GH_ParamAccess.list);  //02

          //  pManager.AddBrepParameter("Brep", "Brep", "A  List of closed Breps for each beam compoinent if CalcBrep input is true", GH_ParamAccess.list);  //03

            pManager.AddMeshParameter("Meshes", "M", "A  List of meshes for each beam compoinent if ClacMesh input is true", GH_ParamAccess.list);  //04



          //  pManager.AddCurveParameter("SideCurvesTreeC", "SideCurvesTreeC", "SideCurves as Tree", GH_ParamAccess.tree); //06

        }



        /// <summary>
        /// This is the method that actually does the work.
        /// </summary>
        /// <param name="DA">The DA object is used to retrieve from inputs and store in outputs.</param>
        protected override void SolveInstance(IGH_DataAccess DA)
        {







            List<Curve> iCurves = new List<Curve>();   //00




            double oHeight = 27; //05


            double oClimbOffset = 27; //04


    

       




            bool oCalcLines = true; //06

         //   bool oCalcBrep = false; //06


            bool oCalcMesh = true; //08


            double iCheckDist = 0.01;




            //       bool oManItOn = false;  //01

            int oManStIndex = -1; //03

            int oManIt = -1; //02

       




            //  if (!DA.GetDataTree<GH_Curve>(0, out iCurves0)) return;   //worked in crazy ways tree structure




            if (!DA.GetDataList<Curve>(0, iCurves)) { return; } //  0


            if (!DA.GetData(1, ref oHeight)) return;   //05




            if (!DA.GetData(2, ref oClimbOffset)) return; //04






            if (!DA.GetData(3, ref oCalcLines)) return;  //06

       //     if (!DA.GetData(4, ref oCalcBrep)) return;  //07


            if (!DA.GetData(4, ref oCalcMesh)) return;  //08



            //  if (!DA.GetData(1, ref oManItOn)) return;  //01

            if (!DA.GetData(5, ref iCheckDist)) return;  //11



            if (!DA.GetData(6, ref oManStIndex)) return; //03

            if (!DA.GetData(7, ref oManIt)) return;  //02











            //Expiring:


            var myDay = System.DateTime.Now.Day;

            var myMonth = System.DateTime.Now.Month;

            var myYear = System.DateTime.Now.Year;

            /*
            A = myDay;

            B = myMonth;

            C = myYear;
            */

            //ExpiringTime

            int check = 1;

            int expYear = 999999999;

            int expMonth = 03;

            int expDay = 27;



            if (myYear > expYear)
            {
                check = 0;
            }

            if (myYear == expYear)
            {
                if (myMonth > expMonth)
                {
                    check = 0;
                }

                if (myMonth == expMonth)
                {

                    if (myDay > expDay)
                    {
                        check = 0;
                    }

                }

            }



            //  E = check;





































            /*

            int iteration;

            int StartIndex;

            // int oManStIndex = 0;

            if (oManItOn == true)

            {
                iteration = oManIt;

                StartIndex = oManStIndex;
            }

            else

            {
                iteration = iCurves.Count;

                StartIndex = 0;
            }

            */










            // Enable to define the iteration start and the iteration count without being out of range all the time



            int myStartIndex = 0;

            int iteration = 0;



            if (oManStIndex == -1 & oManIt == -1)

            {
                myStartIndex = 0;

                iteration = iCurves.Count;

                //  iteration = 2;
            }





            if (oManStIndex > -1 & oManIt == -1)

            {

                if (oManStIndex < iCurves.Count)

                {

                    myStartIndex = oManStIndex;

                    iteration = iCurves.Count - oManStIndex;

                }


                else

                {

                    myStartIndex = iCurves.Count - 1;

                    iteration = 1;


                }



            }





            if (oManStIndex == -1 & oManIt > -1)

            {


                if (oManIt < iCurves.Count)

                {
                    myStartIndex = 0;

                    iteration = oManIt;

                }

                else

                {

                    myStartIndex = 0;

                    iteration = iCurves.Count;
                }


            }





            if (oManStIndex > -1 & oManIt > -1)

            {


                if (oManStIndex < iCurves.Count)

                {
                    myStartIndex = oManStIndex;


                    if (oManIt + oManStIndex < iCurves.Count)

                    {
                        iteration = oManIt;
                    }


                    else

                    {
                        iteration = iCurves.Count - oManStIndex;
                    }



                }



                else

                {
                    myStartIndex = iCurves.Count - 1;

                    iteration = 1;

                }



            }








            List<Point3d> pCenters2 = new List<Point3d>();


            List<Polyline> AllBeamPolylinesUK = new List<Polyline>();

            List<Polyline> AllBeamPolylinesOK = new List<Polyline>();



            List<Point3d> testPointsOriginal = new List<Point3d>();


            List<NurbsCurve> allConnectLines = new List<NurbsCurve>();




            List<Brep> allBreps = new List<Brep>();

            List<Mesh> allMeshes = new List<Mesh>();




            List<Vector3d> myNormals = new List<Vector3d>();





            List<Polyline> StudioPolylines = new List<Polyline>();



            List<List<NurbsCurve>> myListListCurves = new List<List<NurbsCurve>>();




            //Loop through all input polylines to get all neighbour normal vectors and neighbour polygon centers which are necessary to offset the beam correctly  (Edge offset in the bisecting angle to the neighbour)

            if (check != 0)  //Expiring if

            {



                for (int i = 0; i < iCurves.Count; i++)

                {




                    Polyline iPolyL3;  //the polyline to work with



                    //   Polyline iPolyL3;


                    // iCurves[i + oManStIndex].TryGetPolyline(out iPolyL3);


                    iCurves[i].TryGetPolyline(out iPolyL3);

                    StudioPolylines.Add(iPolyL3);



                    Point3d pCenter = PolylineAverage(iPolyL3);

                    //  Point3d pCenter = PolylineAverage(iCurves[i]);

                    pCenters2.Add(pCenter);





                    // Polyline iPolyL3 = iCurves[i];


                    Vector3d v4 = iPolyL3[0] - iPolyL3[1];

                    //v4.Unitize();

                    Vector3d v5 = iPolyL3[0] - iPolyL3[2];

                    //v5.Unitize();


                    Vector3d myNormal = Vector3d.CrossProduct(v4, v5);

                    myNormal.Unitize();

                    myNormals.Add(myNormal);


                }



            }//7Expiring



            // Main loop, its based on the node (code) Component_Solid_Beam



            for (int i = 0; i < iteration; i++)
            {


                //Polyline iPolyL0 = iCurves[i + StartIndex];




                Polyline iPolyL0;  //the polyline to work with



                //   Polyline iPolyL3;


                // iCurves[i + oManStIndex].TryGetPolyline(out iPolyL3);


                iCurves[i + myStartIndex].TryGetPolyline(out iPolyL0);



                // Offset function is called twice: so the beam can be constructed between the two offsets(with different offset distance) 
                //this is to move the beam globally down if a plate is on its top




                //List<Point3d> myUKpoints = UKpointOffset(iPolyL0, oHeight + oClimbOffset, pCenters2[i + StartIndex], StudioPolylines, pCenters2, myNormals);

                List<Point3d> myUKpoints = UKpointOffset(iPolyL0, oHeight + oClimbOffset, pCenters2[i + myStartIndex], StudioPolylines, pCenters2, myNormals, iCheckDist);

                myUKpoints.Add(myUKpoints[0]);

                Polyline UKpolyLine1 = new Polyline(myUKpoints);


                AllBeamPolylinesUK.Add(UKpolyLine1);




                // List<Point3d> myOKpointsOffset = UKpointOffset(iPolyL0, oClimbOffset, pCenters2[i + StartIndex], StudioPolylines, pCenters2, myNormals);

                List<Point3d> myOKpointsOffset = UKpointOffset(iPolyL0, oClimbOffset, pCenters2[i + myStartIndex], StudioPolylines, pCenters2, myNormals, iCheckDist);

                myOKpointsOffset.Add(myOKpointsOffset[0]);

                Polyline myOKoffsetPolyline = new Polyline(myOKpointsOffset);


                AllBeamPolylinesOK.Add(myOKoffsetPolyline);




                List<NurbsCurve> Connectlines = new List<NurbsCurve>();



                if (oCalcLines)   // create the side lines


                {


                    for (int j = 0; j < myUKpoints.Count; j++)

                    {

                        Line myLine = new Line(myUKpoints[j], myOKpointsOffset[j]);

                        NurbsCurve myLine2 = myLine.ToNurbsCurve();

                        allConnectLines.Add(myLine2);

                        Connectlines.Add(myLine2);

                    }

                }



                myListListCurves.Add(Connectlines);


                //Brep calculation is in the code/node Closed Brep

                /*

                if (oCalcBrep) //create Breps is not used in the end

                {

                    var myBrep = Brep.CreateFromLoft(Connectlines, Point3d.Unset, Point3d.Unset, LoftType.Straight, false)[0];

                    // myBrep.CapPlanarHoles(0.001);



                    var myBrep2 = myBrep.CapPlanarHoles(0.001);

                    allBreps.Add(myBrep2);





                    //allBreps2.Add(collectBrep);

                }



                */






                if (oCalcMesh) // calculate a mesh representation of the beam

                {

                    Mesh myMesh = new Mesh();

                    for (int j = 0; j < myUKpoints.Count; j++)
                    {
                        myMesh.Vertices.Add(myUKpoints[j]);


                    }



                    for (int j = 0; j < myOKpointsOffset.Count; j++)
                    {

                        myMesh.Vertices.Add(myOKpointsOffset[j]);

                    }





                    myMesh.Faces.AddFace(3, 0, 1, 2);

                    myMesh.Faces.AddFace(3 + myOKpointsOffset.Count, 0 + myOKpointsOffset.Count, 1 + myOKpointsOffset.Count, 2 + myOKpointsOffset.Count);




                    // myUKpoints.Count-1

                    for (int j = 0; j < myUKpoints.Count - 1; j++)
                    {

                        myMesh.Faces.AddFace(j, j + 1, j + myOKpointsOffset.Count + 1, j + myOKpointsOffset.Count);

                    }








                    myMesh.Normals.ComputeNormals();


                    myMesh.UnifyNormals();


                    myMesh.Normals.ComputeNormals();





                    allMeshes.Add(myMesh);





                }



























            }











            /*


            oBeamPolylinesUK = AllBeamPolylinesUK;

            oBeamPolylinesOK = AllBeamPolylinesOK;




            oAllConnectlinesTop = allConnectLines;

            oAllBreps = allBreps;


            oAllMeshes = allMeshes;


    */









            Grasshopper.DataTree<Curve> myFinalCurvesTreeC = new Grasshopper.DataTree<Curve>();        //ListofLists to Tree for the Output


            int BranchCount222 = myListListCurves.Count;


            for (int i = 0; i < myListListCurves.Count; i++)

            {

                int ListLenght333 = myListListCurves[i].Count;

                for (int j = 0; j < ListLenght333; j++)

                {

                    myFinalCurvesTreeC.Add(myListListCurves[i][j], new GH_Path(i));

                    //myFinalPointsTree.Add(mySuperPoints[i][j], new GH_Path(i));
                }


            }









            Grasshopper.DataTree<Curve> myFinalCurvesTreeO = new Grasshopper.DataTree<Curve>();        //ListofLists to Tree for the Output


            /// int BranchCount222 = myListListCurves.Count;


            for (int i = 0; i < myListListCurves.Count; i++)

            {

                int ListLenght333 = myListListCurves[i].Count - 1;

                for (int j = 0; j < ListLenght333; j++)

                {

                    myFinalCurvesTreeO.Add(myListListCurves[i][j], new GH_Path(i));

                    //myFinalPointsTree.Add(mySuperPoints[i][j], new GH_Path(i));
                }


            }






            DA.SetDataList(0, AllBeamPolylinesOK);

            DA.SetDataList(1, AllBeamPolylinesUK);

            DA.SetDataTree(2, myFinalCurvesTreeO);

            //DA.SetDataList(2, allConnectLines);

          //  DA.SetDataList(3, allBreps);


            DA.SetDataList(3, allMeshes);



        //    DA.SetDataTree(6, myFinalCurvesTreeC);













        }







        public static Point3d PolylineAverage(Polyline iPolyL)
        {

            Point3d PCenterT2 = new Point3d(0, 0, 0);


            for (int i = 0; i < iPolyL.Count - 1; i++)

            {
                PCenterT2 = PCenterT2 + iPolyL[i];
            }

            Point3d PCenter3 = PCenterT2 / (iPolyL.Count - 1);


            return PCenter3;
        }





        // A Function to offset the beam  top polyline points

        // The endpoints of the edges are moved in the bisecting vector of the adjacant polyline normal vectors. To get the correct and uniform material Thickness offset Distance is calculated with a math cosinus function 
        //in dependence of the material thickness.
        //If an edge is naked and therte is no neighbour polyline,
        //the edges Endpoints are moved in the polylines normal vector: Distance: Matetrial Thickness








        public static List<Point3d> UKpointOffset(Polyline iPolyL, double height, Point3d myPcenter, List<Polyline> allMyPolylines, List<Point3d> allmyPcenters, List<Vector3d> superNormals, double myCheckdist)
        {




            List<Point3d> test2 = new List<Point3d>();






            Vector3d v1 = iPolyL[0] - iPolyL[1];  // Edge vector

            Point3d mp0 = iPolyL[0] + v1 * -0.5; //Middle point




            List<Point3d> myNeighbourCenterPoints = new List<Point3d>();

            List<Vector3d> myNeighbourVectors = new List<Vector3d>();


            //Find the neighbour polylines of the current polyline edge
          

            for (int i = 0; i < allMyPolylines.Count; i++)
            {



                Polyline myPl = allMyPolylines[i];

                Point3d myCP = myPl.ClosestPoint(mp0);

                double Distance = mp0.DistanceTo(myCP);




                if (Distance < myCheckdist)
                {

                    myNeighbourCenterPoints.Add(allmyPcenters[i]);

                    myNeighbourVectors.Add(superNormals[i]);
                }

            }




            // Offset Points of naked edges in the polylines normal vector : Distance: Material thickness

            if (myNeighbourCenterPoints.Count < 2)


            {
                for (int i = 0; i < iPolyL.Count - 1; i++)

                {


                    Point3d myUKpoint0 = iPolyL[i] + myNeighbourVectors[0] * height * -1;

                    test2.Add(myUKpoint0);

                }

            }



            // Offset Points of not naked edges in the in the bisecting vector of the polylines normal vector and the adjacant polylines normal vector. Disatnce  with math cosinus in dependence of the material thickness


            else

            {


                Vector3d moveVecSum2 = myNeighbourVectors[0] + myNeighbourVectors[1];

                moveVecSum2.Unitize();


                double alpha = Vector3d.VectorAngle(moveVecSum2, myNeighbourVectors[1]);

                double Hypothenuse = height / System.Math.Cos(alpha);


                Point3d myUKpoint0 = iPolyL[0] + moveVecSum2 * Hypothenuse * -1;

                Point3d myUKpoint1 = iPolyL[1] + moveVecSum2 * Hypothenuse * -1;




                Vector3d moveVec22 = Vector3d.CrossProduct(v1, iPolyL[1] - iPolyL[2]) * -1;

                moveVec22.Unitize();


                Point3d myUKpoint2 = iPolyL[2] + moveVec22 * height;

                Point3d myUKpoint3 = iPolyL[3] + moveVec22 * height;



                test2.Add(myUKpoint0);

                test2.Add(myUKpoint1);

                test2.Add(myUKpoint2);

                test2.Add(myUKpoint3);

                //test2.Add(myUKpoint0);



            }


            return test2;


        }









        /// <summary>
        /// Provides an Icon for the component.
        /// </summary>
        protected override System.Drawing.Bitmap Icon
        {
            get
            {
                //You can add image files to your project resources and access them like this:
                // return Resources.IconForThisComponent;
                //  return null;


                //  return Resource1.enforce_beam_solid;

                return Resource1.enforce_beam_solidLast;
            }

        }

        /// <summary>
        /// Gets the unique ID for this component. Do not change this ID after release.
        /// </summary>
        public override Guid ComponentGuid
        {
            get { return new Guid("18ec453c-06c1-456b-9006-54f8c13870b9"); }
        }
    }
}