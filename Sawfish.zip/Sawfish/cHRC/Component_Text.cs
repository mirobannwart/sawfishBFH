﻿using System;
using System.Collections.Generic;

using Grasshopper.Kernel;
using Rhino.Geometry;



using Grasshopper.Kernel.Data;

namespace cHRC
{
    public class Component_Text : GH_Component
    {
        /// <summary>
        /// Initializes a new instance of the MyComponent1 class.
        /// </summary>
        public Component_Text()
          : base("Text", "Text",
              "Creates text as curves from a  String on a plane ",
              "cHRC", "04 Visualize Text")
        {
        }

        /// <summary>
        /// Registers all the input parameters for this component.
        /// </summary>
        protected override void RegisterInputParams(GH_Component.GH_InputParamManager pManager)
        {



           



            pManager.AddTextParameter("Starttext", "ST", "A text string which is added before each main text", GH_ParamAccess.item, ""); //01

            pManager.AddTextParameter("MainText", "T", "The main text string as list corelating with the plane input", GH_ParamAccess.list); //02

            pManager.AddTextParameter("EndText", "ET", "A text string which is added after each main text", GH_ParamAccess.item, ""); //03


            pManager.AddPlaneParameter("Planes", "P", "Polyline Input for the offset, as list", GH_ParamAccess.list); //00



            pManager.AddTextParameter("Font", "F", "A text string of your font: Centurygotic, Arial ..., ", GH_ParamAccess.item, "Centurygotic"); //04

            pManager.AddNumberParameter("FontSize", "FS", "Guess what: the size of your font", GH_ParamAccess.item, 50.00);  //05

            pManager.AddBooleanParameter("Bold", "B", "If True the text is bold", GH_ParamAccess.item, false);  //06


        }

        /// <summary>
        /// Registers all the output parameters for this component.
        /// </summary>
        protected override void RegisterOutputParams(GH_Component.GH_OutputParamManager pManager)

        {
            pManager.AddCurveParameter("TextCurves", "TC", "A List of Curves showing your text", GH_ParamAccess.tree);  //00
        }




        /// <summary>
        /// This is the method that actually does the work.
        /// </summary>
        /// <param name="DA">The DA object is used to retrieve from inputs and store in outputs.</param>
        protected override void SolveInstance(IGH_DataAccess DA)
        {






            string iExtraTextS = ""; //01

            List<string> iTextMain = new List<string>();   //02

            string iExtraTextE = "cHRC";  //03



            List<Plane> iPlanes = new List<Plane>();   //00




            string iFont = "Centurygotic"; //04

            double iFontSize = 50.0; //05


            bool iBold = false;  //06








            if (!DA.GetData(0, ref iExtraTextS)) return;  //01

            if (!DA.GetDataList<string>(1, iTextMain)) { return; } //  0

            if (!DA.GetData(2, ref iExtraTextE)) return; //03



            if (!DA.GetDataList<Plane>(3, iPlanes)) { return; } //  0













            if (!DA.GetData(4, ref iFont)) return; //04

            if (!DA.GetData(5, ref iFontSize)) return;   //05

            if (!DA.GetData(6, ref iBold)) return;  //06







            List<List<Curve>> myTextCurvesListList = new List<List<Curve>>();




            //Main Loop to at Text to every plane

            for (int i = 0; i < iPlanes.Count; i++)
            {


                List<Curve> myTextCurves = new List<Curve>();



                string myString;



     

                // Define The Text.. If text  input list  matches the plane  input list: at each text to each plane. else Ad text 0 to each plane
                


                    if (iTextMain.Count == iPlanes.Count)

                    {

                        myString = iExtraTextS + iTextMain[i] + iExtraTextE;
                    }


                    else



                    {
                        myString = iExtraTextS + iTextMain[0] + iExtraTextE;

                    }



                


                // string myString = iExtraTextS + iTextMain[i] + iExtraTextE;


                //Bold or not bold

                int iBold2;

                if (iBold)

                {

                    iBold2 = 1;
                }
                else
                {
                    iBold2 = 0;

                }







                //Create the textcurves from the string

                var mysupertextObject = Curve.CreateTextOutlines(myString, iFont, iFontSize, iBold2, true, iPlanes[i], 1.0, 0.001);


                int l = mysupertextObject.GetLength(0);


                for (int j = 0; j < l; j++)
                {

                    myTextCurves.Add(mysupertextObject[j]);
                }


                myTextCurvesListList.Add(myTextCurves);



            }








            Grasshopper.DataTree<Curve> myFinalTextCurvesTree = new Grasshopper.DataTree<Curve>();        //ListofLists to Tree for the Output




            for (int i = 0; i < myTextCurvesListList.Count; i++)

            {

                int ListLenght = myTextCurvesListList[i].Count;

                for (int j = 0; j < ListLenght; j++)

                {

                    myFinalTextCurvesTree.Add(myTextCurvesListList[i][j], new GH_Path(i));

                }


            }





            //  oTextCurves = myFinalTextCurvesTree;                        //Output






            DA.SetDataTree(0, myFinalTextCurvesTree);
























        }

        /// <summary>
        /// Provides an Icon for the component.
        /// </summary>
        protected override System.Drawing.Bitmap Icon
        {
            get
            {
                //You can add image files to your project resources and access them like this:
                // return Resources.IconForThisComponent;

                //return null;

                return Resource1.text_this;



            }
        }

        /// <summary>
        /// Gets the unique ID for this component. Do not change this ID after release.
        /// </summary>
        public override Guid ComponentGuid
        {
            get { return new Guid("277ded68-c6ef-45b2-b0f0-318ec4cda34e"); }
        }
    }
}