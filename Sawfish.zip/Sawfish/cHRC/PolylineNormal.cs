﻿using System;
using System.Collections.Generic;

using Grasshopper.Kernel;
using Rhino.Geometry;

namespace cHRC
{
    public class PolylineNormal : GH_Component
    {
        /// <summary>
        /// Initializes a new instance of the MyComponent3 class.
        /// </summary>
        public PolylineNormal()
          : base("01_PolylineNormalvector", "PolyNormV",
              "PolylineNormalvector calculates the normal vector and centerpoint of a polyline",
              "cHRC", "01 Adjust")
        {
        }

        /// <summary>
        /// Registers all the input parameters for this component.
        /// </summary>
        protected override void RegisterInputParams(GH_Component.GH_InputParamManager pManager)
        {

            pManager.AddCurveParameter("Polylines", "Pl", "The Polylines", GH_ParamAccess.list); //00


            pManager.AddNumberParameter("Amplitude", "Amp", "The Normal Vector Length", GH_ParamAccess.item, 1);  //01

        }

        /// <summary>
        /// Registers all the output parameters for this component.
        /// </summary>
        protected override void RegisterOutputParams(GH_Component.GH_OutputParamManager pManager)
        {
            pManager.AddPointParameter("PolylineCenters", "PC", "Centerpoints of the polylines", GH_ParamAccess.list);

            pManager.AddPointParameter("NormalVectors", "NV", "(Amplified) NormalVectors of the polylines", GH_ParamAccess.list);

        }

        /// <summary>
        /// This is the method that actually does the work.
        /// </summary>
        /// <param name="DA">The DA object is used to retrieve from inputs and store in outputs.</param>
        protected override void SolveInstance(IGH_DataAccess DA)
        {




            List<Curve> myPolys = new List<Curve>();   //00

            double iAmp = 1.0;   //01



            if (!DA.GetDataList<Curve>(0, myPolys)) { return; } //  00

            if (!DA.GetData(1, ref iAmp)) return;




            List<Point3d> myCenters = new List<Point3d>();

            List<Vector3d> myVecs = new List<Vector3d>();






            List<Polyline> myPolys222 = new List<Polyline>();

            for (int i = 0; i < myPolys.Count; i++)
            {

                Polyline iPolyL3;  //polyline to work with

                // iCurves[i + oManStIndex].TryGetPolyline(out iPolyL3);

                myPolys[i].TryGetPolyline(out iPolyL3); //visual studio work around

                myPolys222.Add(iPolyL3);
            }









            for (int i = 0; i < myPolys222.Count; i++)
            {


                Polyline iPoly0 = myPolys222[i];


                Point3d P0 = iPoly0[0];
                Point3d P1 = iPoly0[1];
                Point3d P2 = iPoly0[2];

                Vector3d myVec1 = P1 - P0;
                Vector3d myVec2 = P1 - P2;

                myVec1.Unitize();
                myVec2.Unitize();

                Vector3d myCrossV1 = Rhino.Geometry.Vector3d.CrossProduct(myVec1, myVec2);

                myCrossV1.Unitize();

                Vector3d myCrossV1AMP = myCrossV1 * iAmp;

                myVecs.Add(myCrossV1AMP);

                Point3d polyCenter = PolylineAverage(iPoly0);  //A Function to get the center of a closed polyline

                myCenters.Add(polyCenter);



            }

            /*

            oCenters = myCenters;

            oVecs = myVecs;

            */




            DA.SetDataList(0, myCenters);

            DA.SetDataList(1, myVecs);


        }






        public static Point3d PolylineAverage(Polyline iPolyL)     //A Function to get the center of a closed polyline
        {

            Point3d PCenterT2 = new Point3d(0, 0, 0);


            for (int i = 0; i < iPolyL.Count - 1; i++)

            {
                PCenterT2 = PCenterT2 + iPolyL[i];
            }

            Point3d PCenter3 = PCenterT2 / (iPolyL.Count - 1);


            return PCenter3;
        }













        /// <summary>
        /// Provides an Icon for the component.
        /// </summary>
        protected override System.Drawing.Bitmap Icon
        {
            get
            {
                //You can add image files to your project resources and access them like this:
                // return Resources.IconForThisComponent;

                //  return null;

                return Resource1.PolyNormal;

            }
        }

        /// <summary>
        /// Gets the unique ID for this component. Do not change this ID after release.
        /// </summary>
        public override Guid ComponentGuid
        {
            get { return new Guid("0bc16d20-5287-499b-ae8a-7e0c732c25cf"); }
        }
    }
}