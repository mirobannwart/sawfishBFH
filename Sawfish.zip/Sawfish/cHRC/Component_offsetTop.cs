﻿using System;
using System.Collections.Generic;

using Grasshopper.Kernel;
using Grasshopper.Kernel.Data;
using Grasshopper.Kernel.Types;

using Rhino.Geometry;

// In order to load the result of this wizard, you will also need to
// add the output bin/ folder of this project to the list of loaded
// folder in Grasshopper.
// You can use the _GrasshopperDeveloperSettings Rhino command for that.

namespace cHRC
{
    public class cHRCComponent : GH_Component
    {
        /// <summary>
        /// Each implementation of GH_Component must provide a public 
        /// constructor without any arguments.
        /// Category represents the Tab in which the component will appear, 
        /// Subcategory the panel. If you use non-existing tab or panel names, 
        /// new tabs/panels will automatically be created.
        /// </summary>
        public cHRCComponent()
          : base("02 Offset Top cHRC", "OffsetTop cHRC",
              "Constructs polyline offsets and a beampolylines which can be used  to construct solid beams",
              "cHRC", "01 TopPolyline")
        {
        }

        /// <summary>
        /// Registers all the input parameters for this component.
        /// </summary>
        protected override void RegisterInputParams(GH_Component.GH_InputParamManager pManager)
        {
            // Use the pManager object to register your input parameters.
            // You can often supply default values when creating parameters.
            // All parameters must have the correct access type. If you want 
            // to import lists or trees of values, modify the ParamAccess flag.
            /*
            pManager.AddPlaneParameter("Plane", "P", "Base plane for spiral", GH_ParamAccess.item, Plane.WorldXY);
            pManager.AddNumberParameter("Inner Radius", "R0", "Inner radius for spiral", GH_ParamAccess.item, 1.0);
            pManager.AddNumberParameter("Outer Radius", "R1", "Outer radius for spiral", GH_ParamAccess.item, 10.0);
            pManager.AddIntegerParameter("Turns", "T", "Number of turns between radii", GH_ParamAccess.item, 10);
            */


            pManager.AddCurveParameter("Polylines", "Pl", "Polyline Input for the offset", GH_ParamAccess.list); //00

          //  pManager.AddBooleanParameter("Manual iteration", "Manual iteration", "True to limit the iterations", GH_ParamAccess.item, false);  //01



            pManager.AddNumberParameter("OffsetLength", "OL", "Offset Distance in mm", GH_ParamAccess.item, 58);  //04

            pManager.AddNumberParameter("IntersectTolerance", "IT", "Intersection Check tolerance, dont think about keep on zero try to increase when something does not work, its to check the offset direction by intersections", GH_ParamAccess.item, 0.0000);  //05

            pManager.AddBooleanParameter("OffsetDirection", "OD", "Flip the offset direction by a bool  true or false", GH_ParamAccess.item, true);  //06



            pManager.AddIntegerParameter("StartIteration", "Si", " Start Iteration if larger than -1", GH_ParamAccess.item, -1); //03



            pManager.AddIntegerParameter("MaxIterations", "Mi", "Maximal Iteration if larger than -1", GH_ParamAccess.item, -1); //02

          



            // If you want to change properties of certain parameters, 
            // you can use the pManager instance to access them by index:
            //pManager[0].Optional = true;
        }

        /// <summary>
        /// Registers all the output parameters for this component.
        /// </summary>
        protected override void RegisterOutputParams(GH_Component.GH_OutputParamManager pManager)
        {
            // Use the pManager object to register your output parameters.
            // Output parameters do not have default values, but they too must have the correct access type.

            // pManager.AddCurveParameter("Spiral", "S", "Spiral curve", GH_ParamAccess.item);


            //   pManager.AddPointParameter("PolygonCenters", "PolygonCenters", "The Polygon Centers", GH_ParamAccess.list);  //00


            pManager.AddCurveParameter("OffsetBeamPolyline", "BPl", "The Offseted Beam Polyline", GH_ParamAccess.list);  //02

            pManager.AddCurveParameter("OffsetPolyline", "Pl", "The Offseted Polyline", GH_ParamAccess.list);  //01

           




            // Sometimes you want to hide a specific parameter from the Rhino preview.
            // You can use the HideParameter() method as a quick way:
            //pManager.HideParameter(0);
        }

        /// <summary>
        /// This is the method that actually does the work.
        /// </summary>
        /// <param name="DA">The DA object can be used to retrieve data from input parameters and 
        /// to store data in output parameters.</param>
        protected override void SolveInstance(IGH_DataAccess DA)
        {
            // First, we need to retrieve all data from the input parameters.
            // We'll start by declaring variables and assigning them starting values.

        

             List<Curve> iCurves = new List<Curve>();   //00

            // List<NullReferenceException> iCurves = new List<NullReferenceException>();   //00


           // GH_Structure<GH_Curve> iCurves0 = new GH_Structure<GH_Curve>();  //worked in crazy ways





      

            double oWidth = 50; //04

            double oOffsetIntersectChecTol = 0.0000; //05

            bool oOffsetDirection = true; //06


            // bool oManItOn = false;  //01

        

            int oManStIndex = -1; //03

            int oManIt = -1; //02












            // Then we need to access the input parameters individually. 
            // When data cannot be extracted from a parameter, we should abort this method.

      


            if (!DA.GetDataList<Curve>(0, iCurves)) { return; } //  0


          //  if (!DA.GetDataTree<GH_Curve>(0, out iCurves0)) return;   //worked in crazy ways tree structure



            if (!DA.GetData(1, ref oWidth)) return;

            if (!DA.GetData(2, ref oOffsetIntersectChecTol)) return;

            if (!DA.GetData(3, ref oOffsetDirection)) return;



            //   if (!DA.GetData(1, ref oManItOn)) return;  //01

            if (!DA.GetData(4, ref oManStIndex)) return;

            if (!DA.GetData(5, ref oManIt)) return;







            /*


            int iteration;                                      // Manual or full listlenght auto iteration

            if (oManIt >= 0 & oManIt2 < iCurves.Count)

            {
                iteration = oManIt2;
            }

            else

            {
                iteration = iCurves.Count;
            }



            */



            // Enable to define the iteration start and the iteration count without being out of range all the time

            int myStartIndex = 0;

            int iteration = 0;



            if (oManStIndex == -1  & oManIt == -1 )

            {
                myStartIndex = 0;

                iteration = iCurves.Count;

              //  iteration = 2;
            }





            if (oManStIndex > -1   & oManIt == -1)

            {

                if (oManStIndex < iCurves.Count)

                {

                    myStartIndex = oManStIndex;

                    iteration = iCurves.Count - oManStIndex;

                }


                else

                {

                    myStartIndex = iCurves.Count -1 ;

                    iteration = 1;


                }



            }





            if (oManStIndex == -1  & oManIt > -1)

            {
              

                if (oManIt < iCurves.Count)

                {
                    myStartIndex = 0;

                    iteration = oManIt;

                }

                else

                {

                    myStartIndex = 0;

                    iteration = iCurves.Count;
                }
               

            }





            if (oManStIndex > -1 & oManIt > -1)

            {


                if (oManStIndex < iCurves.Count)

                {
                  myStartIndex = oManStIndex;


                    if(oManIt + oManStIndex < iCurves.Count)

                    {
                        iteration = oManIt;
                    }


                    else

                    {
                        iteration = iCurves.Count - oManStIndex;
                    }



                }



                else

                {
                    myStartIndex = iCurves.Count - 1;

                    iteration = 1;

                }



            }



























             List<Point3d> pCenters = new List<Point3d>();            // Lists..

            List<Point3d> AlloKoffsets = new List<Point3d>();

            List<Polyline> AllPolylines = new List<Polyline>();

            List<Polyline> AllBeamPolylines = new List<Polyline>();











            for (int i = 0; i < iteration; i++)                          // Main code tocreate offset in each polyline
            {



                // Polyline iPolyL = iCurves[i + oManStIndex]; //ToPolyline vor visual Studio c#....


                Polyline iPolyL;


                //  iCurves[i + myStartIndex].TryGetPolyline(out iPolyL);


                iCurves[i + myStartIndex].TryGetPolyline(out iPolyL);

                




                Point3d PCenter = PolylineAverage(iPolyL);              // Function for the polygon center, used as input for the offsetfunction

                pCenters.Add(PCenter);                                  //(to distinguish between inside and outside offset, see functions)




                List<Point3d> OkOffset = OKpointOffset(iPolyL, oWidth, PCenter, oOffsetIntersectChecTol, oOffsetDirection);   // Function to create the offset

                for (int j = 0; j < OkOffset.Count; j++)

                {
                    AlloKoffsets.Add(OkOffset[j]);
                }



                OkOffset.Add(OkOffset[0]);



                Polyline offsetPolyline = new Polyline(OkOffset);       //Inside Polyline from offseted points

                AllPolylines.Add(offsetPolyline);







                List<Polyline> beamPolylines = beamPolyline(iPolyL, OkOffset);      //OK Polylines per Beam



                for (int j = 0; j < beamPolylines.Count; j++)

                {

                    AllBeamPolylines.Add(beamPolylines[j]);


                }


            }



            /*


            oPcenters = pCenters;                                     //Output

            oPolylines_offset_triangle_inside = AllPolylines;

            oBeamPolylines = AllBeamPolylines;

    */





         //   DA.SetDataList(0, pCenters);


            DA.SetDataList(0, AllBeamPolylines);

            DA.SetDataList(1, AllPolylines);

           






            // Finally assign the spiral to the output parameter.
            // DA.SetData(0, spiral);

        }







        //Function to get the Polyline(closed) Center (Average)


        public static Point3d PolylineAverage(Polyline iPolyL)
        {

            Point3d PCenterT2 = new Point3d(0, 0, 0);


            for (int i = 0; i < iPolyL.Count - 1; i++)

            {
                PCenterT2 = PCenterT2 + iPolyL[i];
            }

            Point3d PCenter3 = PCenterT2 / (iPolyL.Count - 1);


            return PCenter3;
        }






        //Function to create the OK polyline Offset by offseting the vertices in the bisecting angle in the correct lenght(by angle function sinus)


        public static List<Point3d> OKpointOffset(Polyline iPolyL, double width, Point3d myPcenter, double offIntersectTol, bool OffsetDirection)
        {


            List<Point3d> offsets = new List<Point3d>();


            List<Point3d> planepoints = new List<Point3d>();

            for (int i = 0; i < iPolyL.Count - 1; i++)

            {

                planepoints.Add(iPolyL[i]);
            }




            Plane Pl = new Plane();

            Plane.FitPlaneToPoints(planepoints, out Pl);



            for (int i = 0; i < iPolyL.Count - 1; i++)

            {



                Vector3d v1 = iPolyL[i] - iPolyL[i + 1];

                v1.Unitize();


                int superindex;

                if (i == 0)

                {
                    superindex = iPolyL.Count - 2;
                }

                else

                {
                    superindex = i - 1;
                }


                Vector3d v2 = iPolyL[i] - iPolyL[superindex];

                v2.Unitize();



                Vector3d sumVector = v1 + v2;

                sumVector.Unitize();



                double alpha = Vector3d.VectorAngle(sumVector, v1);


                double Hypothenuse = width / System.Math.Sin(alpha);


                Vector3d movVec = sumVector * Hypothenuse;




                Point3d movedPointPos = iPolyL[i] + movVec;     //Creat Intersection Lines from offsetted points to the polygon center to test if

                Point3d movedPointNeg = iPolyL[i] + -movVec;      //the offset goes inside or outside off the initial polyline

                //(0 interssection  events with the polyline means inside, one intersectionb event means the Outside)


                Line testLinePos = new Line(movedPointPos, myPcenter);

                Line testLineNeg = new Line(movedPointNeg, myPcenter);


                var intesectsPos = Rhino.Geometry.Intersect.Intersection.CurveCurve(testLinePos.ToNurbsCurve(), iPolyL.ToNurbsCurve(), offIntersectTol, 0.0);

                int eventsCountPos = intesectsPos.Count;




                List<Point3d> blablaLilst = new List<Point3d>();



                if (OffsetDirection)


                {



                    if (eventsCountPos == 0)

                    {
                        blablaLilst.Add(movedPointPos);


                    }

                    else

                    {
                        blablaLilst.Add(movedPointNeg);
                    }


                }



                else

                {

                    if (eventsCountPos != 0)

                    {
                        blablaLilst.Add(movedPointPos);
                    }

                    else

                    {
                        blablaLilst.Add(movedPointNeg);
                    }



                }



                Point3d projectedPoint = Pl.ClosestPoint(blablaLilst[0]);



                offsets.Add(projectedPoint);



            }



            return offsets;
        }





        //create the OK (Oberkannt= top line)beam from the initial polyline points and the offseted points


        public static List<Polyline> beamPolyline(Polyline iPolyL1, List<Point3d> OkOffset1)
        {


            List<Polyline> beamsPolylines = new List<Polyline>();

            for (int i = 0; i < iPolyL1.Count - 1; i++)

            {

                List<Point3d> okbeamPts1 = new List<Point3d>();


                okbeamPts1.Add(iPolyL1[i]);

                okbeamPts1.Add(iPolyL1[i + 1]);

                okbeamPts1.Add(OkOffset1[i + 1]);

                okbeamPts1.Add(OkOffset1[i]);

                okbeamPts1.Add(iPolyL1[i]);


                Polyline beamOKPolyline1 = new Polyline(okbeamPts1);

                beamsPolylines.Add(beamOKPolyline1);





            }

            return beamsPolylines;

        }






























        /// <summary>
        /// The Exposure property controls where in the panel a component icon 
        /// will appear. There are seven possible locations (primary to septenary), 
        /// each of which can be combined with the GH_Exposure.obscure flag, which 
        /// ensures the component will only be visible on panel dropdowns.
        /// </summary>
        public override GH_Exposure Exposure
        {
            get { return GH_Exposure.primary; }
        }

        /// <summary>
        /// Provides an Icon for every component that will be visible in the User Interface.
        /// Icons need to be 24x24 pixels.
        /// </summary>
        protected override System.Drawing.Bitmap Icon
        {
            get
            {
                // You can add image files to your project resources and access them like this:
                //return Resources.IconForThisComponent;
                // return null;


                // return Resource1.offset257;


                return Resource1.offset257_black;
            }
        }

        /// <summary>
        /// Each component must have a unique Guid to identify it. 
        /// It is vital this Guid doesn't change otherwise old ghx files 
        /// that use the old ID will partially fail during loading.
        /// </summary>
        public override Guid ComponentGuid
        {
            get { return new Guid("c0a73b58-acbb-4af0-bb69-795b0d34ed22"); }
        }
    }
}
