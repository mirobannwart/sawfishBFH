﻿using System;
using System.Collections.Generic;

using Grasshopper.Kernel;
using Rhino.Geometry;

namespace cHRC
{
    public class GetPolyAtClosestP : GH_Component
    {
        /// <summary>
        /// Initializes a new instance of the MyComponent3 class.
        /// </summary>
        public GetPolyAtClosestP()
          : base("06_GetPolyAtClosestPoint", "GetPoly",
              "Get Polylimce in a distance Range",
              "cHRC", "01 Adjust")
        {
        }

        /// <summary>
        /// Registers all the input parameters for this component.
        /// </summary>
        protected override void RegisterInputParams(GH_Component.GH_InputParamManager pManager)
        {
            pManager.AddCurveParameter("Polylines", "Pl", "The Polylines", GH_ParamAccess.list); //00

            pManager.AddPointParameter("PointsRemove", "RPt", "Within the Range (input Range R) around this points polylines will be removed ", GH_ParamAccess.list); //0

            pManager.AddNumberParameter("Range", "R", "The remove range / distance", GH_ParamAccess.item, 500.0);  //02


        }

        /// <summary>
        /// Registers all the output parameters for this component.
        /// </summary>
        protected override void RegisterOutputParams(GH_Component.GH_OutputParamManager pManager)
        {
            pManager.AddCurveParameter("Polylines", "PL", "Polylines without the removed ones", GH_ParamAccess.list); //00

        }

        /// <summary>
        /// This is the method that actually does the work.
        /// </summary>
        /// <param name="DA">The DA object is used to retrieve from inputs and store in outputs.</param>
        protected override void SolveInstance(IGH_DataAccess DA)
        {



            List<Curve> myPolys = new List<Curve>();   //00

            List<Point3d> iTest2 = new List<Point3d>();   //01

            double iTol = 0.9;  //02




            if (!DA.GetDataList<Curve>(0, myPolys)) { return; } //  00

            if (!DA.GetDataList<Point3d>(1, iTest2)) { return; } //  01

            if (!DA.GetData(2, ref iTol)) return;                //02







            List<Polyline> myPolys222 = new List<Polyline>();

            for (int i = 0; i < myPolys.Count; i++)
            {

                Polyline iPolyL3;  //polyline to work with

                // iCurves[i + oManStIndex].TryGetPolyline(out iPolyL3);

                myPolys[i].TryGetPolyline(out iPolyL3); //visual studio work around

                myPolys222.Add(iPolyL3);
            }












            //List<Polyline> myFlippedPolylines = new List<Polyline>();

            // List<double> myAngles = new List<double>();

            List<Vector3d> myVecs = new List<Vector3d>();




            List<Polyline> myRemovedPolies = FlipPolyToClosestPoint(myPolys222, iTest2, iTol);    //Function name is wrong


            /*

            oRemovedpolys = myRemovedPolies;

            //oAngles = myAngles;

            // oVecs = myVecs;

            */


            DA.SetDataList(0, myRemovedPolies);



        }








        //Function name is wrong
        public List<Polyline> FlipPolyToClosestPoint(List<Polyline> myPolys, List<Point3d> myTestPoints, double myTol)    //Function to remove polylines if in a dist range to their closestpoint
        {


            List<Polyline> myFlippedPolylines = new List<Polyline>();

            for (int i = 0; i < myPolys.Count; i++)
            {


                Polyline iPoly0 = myPolys[i];



                Point3d polyCenter = PolylineAverage(iPoly0);  //A Function to get the center of a closed polyline



                Point3d myClosestPoint = PointClosestPoint(polyCenter, myTestPoints);  //find the closest Points to a point




                if (polyCenter.DistanceTo(myClosestPoint) < myTol)


                {
                    myFlippedPolylines.Add(iPoly0);
                }


            }



            return myFlippedPolylines;

        }







        Point3d PointClosestPoint(Point3d testPoint, List<Point3d> Checkpoints)  //find the closest Points to a point
        {
            Point3d tp = testPoint;

            double myDist = 100000000;
            //int myIndex = 100000000;

            List<Point3d> ClosestPoints = new List<Point3d>();
            Point3d Closest = new Point3d();


            for (int i = 0; i < Checkpoints.Count; i++)
            {
                Point3d SwapPoint = Checkpoints[i];

                double myDist0 = tp.DistanceTo(SwapPoint);

                if (myDist0 < myDist)
                {
                    myDist = myDist0;
                    // myIndex = i;
                    Closest = SwapPoint;
                }

            }

            return Closest;
        }


        public static Point3d PolylineAverage(Polyline iPolyL)     //A Function to get the center of a closed polyline
        {

            Point3d PCenterT2 = new Point3d(0, 0, 0);


            for (int i = 0; i < iPolyL.Count - 1; i++)

            {
                PCenterT2 = PCenterT2 + iPolyL[i];
            }

            Point3d PCenter3 = PCenterT2 / (iPolyL.Count - 1);


            return PCenter3;
        }







        /// <summary>
        /// Provides an Icon for the component.
        /// </summary>
        protected override System.Drawing.Bitmap Icon
        {
            get
            {
                //You can add image files to your project resources and access them like this:
                // return Resources.IconForThisComponent;

                //return null;

                return Resource1.getPoly;
            }
        }





        public override Guid ComponentGuid
        {
            get { return new Guid("42196de4-159a-425d-bace-90c8fd88e2a7"); }
        }
    }
}