﻿using System;
using System.Collections.Generic;

using Grasshopper.Kernel;
using Rhino.Geometry;

namespace cHRC
{
    public class UnifyPolylineToClosest : GH_Component
    {
        /// <summary>
        /// Initializes a new instance of the MyComponent3 class.
        /// </summary>
        public UnifyPolylineToClosest()
          : base("03_UnifyPolylineNormalToClosestPoint", "UniPlNtoClP",
              "Unify the Polylines Normal Vectors (Polyline flip) according to the angle between the polylines normal and a vector to the closestpoint of a point List(Add points where the normals should go, ading multiple points is useful for complex structures consisting of multiple irregular arranged trinagulated surfaces) ",
              "cHRC", "01 Adjust")
        {
        }




        /// <summary>
        /// Registers all the input parameters for this component.
        /// </summary>
        protected override void RegisterInputParams(GH_Component.GH_InputParamManager pManager)
        {



            pManager.AddCurveParameter("Polylines", "Pl", "The Polylines to unify / flip", GH_ParamAccess.list); //00

            pManager.AddPointParameter("FlipPoints", "FPt", "Every polyline searchs the closest point of this list and flippes if the polylines normal vector goes to the other side than the point is", GH_ParamAccess.list); //01


        }

        /// <summary>
        /// Registers all the output parameters for this component.
        /// </summary>
        protected override void RegisterOutputParams(GH_Component.GH_OutputParamManager pManager)
        {


            pManager.AddCurveParameter("FlippedPolylines", "FPl", "The flipped / unified Polylines", GH_ParamAccess.list); //00

        }

        /// <summary>
        /// This is the method that actually does the work.
        /// </summary>
        /// <param name="DA">The DA object is used to retrieve from inputs and store in outputs.</param>
        /// 


        protected override void SolveInstance(IGH_DataAccess DA)
        {



            List<Curve> myPolys = new List<Curve>();   //00

            List<Point3d> iTest2 = new List<Point3d>();   //01



            if (!DA.GetDataList<Curve>(0, myPolys)) { return; } //  00

            if (!DA.GetDataList<Point3d>(1, iTest2)) { return; } //  00






            List<Polyline> myPolys222 = new List<Polyline>();

            for (int i = 0; i < myPolys.Count; i++)
            {

                Polyline iPolyL3;  //polyline to work with

                // iCurves[i + oManStIndex].TryGetPolyline(out iPolyL3);

                myPolys[i].TryGetPolyline(out iPolyL3); //visual studio work around

                myPolys222.Add(iPolyL3);
            }





            //List<Polyline> myFlippedPolylines = new List<Polyline>();

            // List<double> myAngles = new List<double>();

            List<Vector3d> myVecs = new List<Vector3d>();




            List<Polyline> myFlippedPolylines = FlipPolyToClosestPoint(myPolys222, iTest2);    //Function to flip to closest point



            /*
            oFlippedPolylines = myFlippedPolylines;

            //oAngles = myAngles;

            // oVecs = myVecs;

            */


            DA.SetDataList(0, myFlippedPolylines);


        }




        //Function to flip polylines accorting to closest point




        public List<Polyline> FlipPolyToClosestPoint(List<Polyline> myPolys, List<Point3d> myTestPoints)    //Function to flip to closest point
        {


            List<Polyline> myFlippedPolylines = new List<Polyline>();

            for (int i = 0; i < myPolys.Count; i++)
            {





                Polyline iPoly0 = myPolys[i];






                Point3d P0 = iPoly0[0];
                Point3d P1 = iPoly0[1];
                Point3d P2 = iPoly0[2];



                Point3d polyCenter = PolylineAverage(iPoly0);  //A Function to get the center of a closed polyline


                Vector3d myVec1 = P1 - P0;
                Vector3d myVec2 = P1 - P2;

                myVec1.Unitize();
                myVec2.Unitize();

                Vector3d myCrossV1 = Rhino.Geometry.Vector3d.CrossProduct(myVec1, myVec2);




                Point3d myClosestPoint = PointClosestPoint(polyCenter, myTestPoints);  //find the closest Points to a point


                Vector3d VecToClosest = myClosestPoint - polyCenter;

                VecToClosest.Unitize();








                double myAngle = Rhino.Geometry.Vector3d.VectorAngle(myCrossV1, VecToClosest);

                double myDegress = Rhino.RhinoMath.ToDegrees(myAngle);






                if (myDegress <= 90)
                {
                    myFlippedPolylines.Add(iPoly0);
                }



                else

                {
                    List<Point3d> myFlippedPoints = new List<Point3d>();

                    myFlippedPoints.Add(iPoly0[3]);
                    myFlippedPoints.Add(iPoly0[2]);
                    myFlippedPoints.Add(iPoly0[1]);
                    myFlippedPoints.Add(iPoly0[0]);

                    Polyline myFlippedPoly = new Polyline(myFlippedPoints);


                    myFlippedPolylines.Add(myFlippedPoly);

                }




            }





            return myFlippedPolylines;

        }









        Point3d PointClosestPoint(Point3d testPoint, List<Point3d> Checkpoints)  //find the closest Points to a point
        {
            Point3d tp = testPoint;

            double myDist = 100000000;
            //int myIndex = 100000000;

            List<Point3d> ClosestPoints = new List<Point3d>();
            Point3d Closest = new Point3d();


            for (int i = 0; i < Checkpoints.Count; i++)
            {
                Point3d SwapPoint = Checkpoints[i];

                double myDist0 = tp.DistanceTo(SwapPoint);

                if (myDist0 < myDist)
                {
                    myDist = myDist0;
                    // myIndex = i;
                    Closest = SwapPoint;
                }

            }

            return Closest;
        }


        public static Point3d PolylineAverage(Polyline iPolyL)     //A Function to get the center of a closed polyline
        {

            Point3d PCenterT2 = new Point3d(0, 0, 0);


            for (int i = 0; i < iPolyL.Count - 1; i++)

            {
                PCenterT2 = PCenterT2 + iPolyL[i];
            }

            Point3d PCenter3 = PCenterT2 / (iPolyL.Count - 1);


            return PCenter3;
        }















        /// <summary>
        /// Provides an Icon for the component.
        /// </summary>
        protected override System.Drawing.Bitmap Icon
        {
            get
            {
                //You can add image files to your project resources and access them like this:
                // return Resources.IconForThisComponent;
                //  return null;


                return Resource1.Unify_Normal_closest;
            }
        }

        /// <summary>
        /// Gets the unique ID for this component. Do not change this ID after release.
        /// </summary>
        public override Guid ComponentGuid
        {
            get { return new Guid("31855919-2173-4d18-890c-7b730facd983"); }
        }
    }
}