﻿using System;
using System.Collections.Generic;

using Grasshopper.Kernel;
using Grasshopper.Kernel.Data;
using Grasshopper.Kernel.Types;

using Rhino.Geometry;



namespace cHRC
{
    public class Component_InsideAngle : GH_Component
    {
        /// <summary>
        /// Initializes a new instance of the MyComponent1 class.
        /// </summary>
        public Component_InsideAngle()
          : base("InsideAngle", "InsideAngle",
              "Calculates the Angles between polyline segments and a plane for the visualisation",
              "cHRC", "03 Dimensioning")
        {
        }


        /// <summary>
        /// Registers all the input parameters for this component.
        /// </summary>
        protected override void RegisterInputParams(GH_Component.GH_InputParamManager pManager)
        {


            pManager.AddCurveParameter("Polylines", "Pl", "Polyline Input for the offset, as list", GH_ParamAccess.list); //00

            pManager.AddIntegerParameter("Round", "R", "Round the angle result", GH_ParamAccess.item, 1); //07

            pManager.AddNumberParameter("OffsetLength", "OL", "The offset Distance for the text location plane;ha sto be larger than 0.0", GH_ParamAccess.item, 40.00);  //04

            pManager.AddBooleanParameter("OffsetDirection", "OD", "Flip the offset direction by true or false", GH_ParamAccess.item, true);  //06

            pManager.AddNumberParameter("OffsetTol", "OT", "Intersection Check Tolerance, dont think about keep on zero try to increase when something does not work, its to check the offset direction by intersections", GH_ParamAccess.item, 0.0);  //05




            pManager.AddIntegerParameter("StartIteration", "Si", "StartIndex if Manual iteration is true", GH_ParamAccess.item, -1); //03


            pManager.AddIntegerParameter("MaxIterations", "Mi", "Maximal Iteration Count if Manuak Itreration is true, should not be higher than Cinput Curve count minus start Iteration  index", GH_ParamAccess.item, -1); //02

    

        }




        /// <summary>
        /// Registers all the output parameters for this component.
        /// </summary>
        protected override void RegisterOutputParams(GH_Component.GH_OutputParamManager pManager)
        {

            pManager.AddNumberParameter("Angles", "A", "A Tree of angles as numbers in degrees", GH_ParamAccess.tree); //06

            pManager.AddPlaneParameter("Planes", "P", "A tree of planes to visualize the angles", GH_ParamAccess.tree); //05

        }





        /// <summary>
        /// This is the method that actually does the work.
        /// </summary>
        /// <param name="DA">The DA object is used to retrieve from inputs and store in outputs.</param>
        protected override void SolveInstance(IGH_DataAccess DA)
        {




            List<Curve> iCurves = new List<Curve>();   //00


            int oRound = 1; //07


            //  GH_Structure<GH_Curve> iCurvesTree = new GH_Structure<GH_Curve>();



            double oWidth =18.0; //04

            bool oOffsetDirection = true;  //06

            double oOffsetIntersectChecTol = 0.0; //05

   

            double oTextPlaneRot = 0.0; //08

            int oFlipText = 1; //09



            double oMovePlaneX = 0.0; //10

            double oMovePlaneY = 0.0; //11

            double oMovePlaneZ = 0.0; //12



            //     bool oManItOn = false;  //01

            int oManStIndex = 1; //03

            int oManIt = 1; //02

    

            // if (!DA.GetDataTree<GH_Curve>(0, out iCurves0)) return;   //worked in crazy ways tree structure






            if (!DA.GetDataList<Curve>(0, iCurves)) { return; }   //00


            //  if (!DA.GetDataTree<GH_Curve>(0, out iCurvesTree)) return;    //00




            if (!DA.GetData(1, ref oRound)) return;  //07



            if (!DA.GetData(2, ref oWidth)) return;   //04

            if (!DA.GetData(3, ref oOffsetDirection)) return;  //06

            if (!DA.GetData(4, ref oOffsetIntersectChecTol)) return;  //05

          




            //   if (!DA.GetData(1, ref oManItOn)) return;  //01

            if (!DA.GetData(5, ref oManStIndex)) return; //03

            if (!DA.GetData(6, ref oManIt)) return;  //02






            // Enable to define the iteration start and the iteration count without being out of range all the time


            int myStartIndex = 0;

            int iteration = 0;



            if (oManStIndex == -1 & oManIt == -1)

            {
                myStartIndex = 0;

                iteration = iCurves.Count;

                //  iteration = 2;
            }





            if (oManStIndex > -1 & oManIt == -1)

            {

                if (oManStIndex < iCurves.Count)

                {

                    myStartIndex = oManStIndex;

                    iteration = iCurves.Count - oManStIndex;

                }


                else

                {

                    myStartIndex = iCurves.Count - 1;

                    iteration = 1;


                }



            }





            if (oManStIndex == -1 & oManIt > -1)

            {


                if (oManIt < iCurves.Count)

                {
                    myStartIndex = 0;

                    iteration = oManIt;

                }

                else

                {

                    myStartIndex = 0;

                    iteration = iCurves.Count;
                }


            }





            if (oManStIndex > -1 & oManIt > -1)

            {


                if (oManStIndex < iCurves.Count)

                {
                    myStartIndex = oManStIndex;


                    if (oManIt + oManStIndex < iCurves.Count)

                    {
                        iteration = oManIt;
                    }


                    else

                    {
                        iteration = iCurves.Count - oManStIndex;
                    }



                }



                else

                {
                    myStartIndex = iCurves.Count - 1;

                    iteration = 1;

                }



            }










            List<Point3d> pCenters = new List<Point3d>();            // Lists..

            List<Point3d> AlloKoffsets = new List<Point3d>();



            List<List<Plane>> myTextPlanesListList = new List<List<Plane>>();

            List<List<double>> myAnglesListList = new List<List<double>>();





            //Visual Studio c# is slightly diffeenfrom grasshopper skript node c#....

            List<Polyline> myViusualPolylines = new List<Polyline>();



            for (int i = 0; i < iCurves.Count; i++)
            {

                Polyline myPolyL0;

                iCurves[i].TryGetPolyline(out myPolyL0);


                myViusualPolylines.Add(myPolyL0);


            }







            for (int i = 0; i < iteration; i++)                          // Main code tocreate offset in each polyline
            {

                //c#gh//    Polyline iPolyL = iCurves[i + oManStIndex];



                Polyline iPolyL = myViusualPolylines[i + myStartIndex];


                Point3d PCenter = PolylineAverage(iPolyL);              // Function for the polygon center, used as input for the offsetfunction

                pCenters.Add(PCenter);                                  //(to distinguish between inside and outside offset, see functions)




                List<Point3d> OkOffset = OKpointOffset(iPolyL, oWidth, PCenter, oOffsetIntersectChecTol, oOffsetDirection);   // Function to create a polyline offset in the bisecting angles, FOR PLANE POSITIONS


                List<Plane> myTextPlanes = new List<Plane>();


                List<double> myAngles = new List<double>();



                for (int j = 0; j < OkOffset.Count; j++)

                {
                    AlloKoffsets.Add(OkOffset[j]);
                }

                OkOffset.Add(OkOffset[0]);




                //Getting inside angles and text planes

                for (int j = 0; j < OkOffset.Count - 1; j++)

                {

                    // getting the text position planes


                    int mySuperI;

                    //int mySuperI2;

                    Vector3d mySuperXvec;

                    Vector3d mySuperYvec;


                    int flip;

                    if (oFlipText==1)

                    {
                        flip = 1;
                    }

                    else

                    {
                        flip = -1;
                    }



                    mySuperI = j;

                    mySuperXvec = OkOffset[mySuperI] - iPolyL[mySuperI];

                    mySuperYvec = (iPolyL[j] - iPolyL[j + 1]) * flip;

       





                    Vector3d myXVec = OkOffset[j] - iPolyL[j];

                    Vector3d myYVec = iPolyL[j] - iPolyL[j + 1];




                    Plane myPlaneText1 = new Plane(OkOffset[j], mySuperXvec, mySuperYvec);



                    Point3d movedOriginP = myPlaneText1.Origin + myPlaneText1.XAxis * oMovePlaneX + myPlaneText1.YAxis * oMovePlaneY + myPlaneText1.ZAxis * oMovePlaneZ;




                    Plane myPlaneText2 = new Plane(movedOriginP, mySuperXvec, mySuperYvec);




                    double myRad = Rhino.RhinoMath.ToRadians(oTextPlaneRot);



                    myPlaneText2.Rotate(myRad, myPlaneText2.ZAxis);




                    myTextPlanes.Add(myPlaneText2);



                    // Getting the inside angles, ,ake degrees and round

                    double myAngle1 = Vector3d.VectorAngle(myXVec, myYVec * -1);

                    double myAngle2 = myAngle1 * 2;

                    double myAngle3 = Rhino.RhinoMath.ToDegrees(myAngle2);

                    double myAngle4 = System.Math.Round(myAngle3, oRound);



                    myAngles.Add(myAngle4);





                }



                myTextPlanesListList.Add(myTextPlanes);


                myAnglesListList.Add(myAngles);


            }




            // Creating a grasshopper tree from a List of Lists for the grasshopper output


            Grasshopper.DataTree<Plane> myTextPlanesTree = new Grasshopper.DataTree<Plane>();        //ListofLists to Tree for the Output


            for (int i = 0; i < myTextPlanesListList.Count; i++)
            {

                int ListLenght333 = myTextPlanesListList[i].Count;

                for (int j = 0; j < ListLenght333; j++)
                {

                    myTextPlanesTree.Add(myTextPlanesListList[i][j], new GH_Path(i));

                    //myFinalPointsTree.Add(mySuperPoints[i][j], new GH_Path(i));
                }

            }







            Grasshopper.DataTree<double> myAnglesTree = new Grasshopper.DataTree<double>();        //ListofLists to Tree for the Output


            for (int i = 0; i < myAnglesListList.Count; i++)
            {

                int ListLenght333 = myAnglesListList[i].Count;

                for (int j = 0; j < ListLenght333; j++)
                {

                    myAnglesTree.Add(myAnglesListList[i][j], new GH_Path(i));

                    //myFinalPointsTree.Add(mySuperPoints[i][j], new GH_Path(i));
                }

            }






            DA.SetDataTree(0, myAnglesTree);

            DA.SetDataTree(1, myTextPlanesTree);

         



            /*
                       oTextplaneTree = myTextPlanesTree;

                        oAnglesTree = myAnglesTree;

                        oPcenters = pCenters;     //Output

                */





        }












        //Function to get the Polyline(closed) Center (Average)


        public static Point3d PolylineAverage(Polyline iPolyL)
        {

            Point3d PCenterT2 = new Point3d(0, 0, 0);


            for (int i = 0; i < iPolyL.Count - 1; i++)

            {
                PCenterT2 = PCenterT2 + iPolyL[i];
            }

            Point3d PCenter3 = PCenterT2 / (iPolyL.Count - 1);


            return PCenter3;
        }






        //Function to create the OK polyline Offset by offseting the vertices in the bisecting angle in the correct lenght(by angle function sinus)


        public static List<Point3d> OKpointOffset(Polyline iPolyL, double width, Point3d myPcenter, double offIntersectTol, bool OffsetDirection)
        {


            List<Point3d> offsets = new List<Point3d>();


            List<Point3d> planepoints = new List<Point3d>();

            for (int i = 0; i < iPolyL.Count - 1; i++)

            {

                planepoints.Add(iPolyL[i]);
            }




            Plane Pl = new Plane();

            Plane.FitPlaneToPoints(planepoints, out Pl);



            for (int i = 0; i < iPolyL.Count - 1; i++)

            {



                Vector3d v1 = iPolyL[i] - iPolyL[i + 1];

                v1.Unitize();


                int superindex;

                if (i == 0)

                {
                    superindex = iPolyL.Count - 2;
                }

                else

                {
                    superindex = i - 1;
                }


                Vector3d v2 = iPolyL[i] - iPolyL[superindex];

                v2.Unitize();



                Vector3d sumVector = v1 + v2;

                sumVector.Unitize();



                double alpha = Vector3d.VectorAngle(sumVector, v1);


                double Hypothenuse = width / System.Math.Sin(alpha);


                Vector3d movVec = sumVector * Hypothenuse;




                Point3d movedPointPos = iPolyL[i] + movVec;     //Creat Intersection Lines from offsetted points to the polygon center to test if

                Point3d movedPointNeg = iPolyL[i] + -movVec;      //the offset goes inside or outside off the initial polyline

                //(0 interssection  events with the polyline means inside, one intersection event means the Outside)


                Line testLinePos = new Line(movedPointPos, myPcenter);

                Line testLineNeg = new Line(movedPointNeg, myPcenter);


                var intesectsPos = Rhino.Geometry.Intersect.Intersection.CurveCurve(testLinePos.ToNurbsCurve(), iPolyL.ToNurbsCurve(), offIntersectTol, 0.0);

                int eventsCountPos = intesectsPos.Count;




                List<Point3d> blablaLilst = new List<Point3d>();



                if (OffsetDirection)


                {



                    if (eventsCountPos == 0)

                    {
                        blablaLilst.Add(movedPointPos);


                    }

                    else

                    {
                        blablaLilst.Add(movedPointNeg);
                    }


                }



                else

                {

                    if (eventsCountPos != 0)

                    {
                        blablaLilst.Add(movedPointPos);
                    }

                    else

                    {
                        blablaLilst.Add(movedPointNeg);
                    }



                }



                Point3d projectedPoint = Pl.ClosestPoint(blablaLilst[0]);



                offsets.Add(projectedPoint);



            }



            return offsets;
        }






































        /// <summary>
        /// Provides an Icon for the component.
        /// </summary>
        protected override System.Drawing.Bitmap Icon
        {
            get
            {
                //You can add image files to your project resources and access them like this:
                // return Resources.IconForThisComponent;


                // return null;


                return Resource1.InsideAngles;

            }
        }

        /// <summary>
        /// Gets the unique ID for this component. Do not change this ID after release.
        /// </summary>
        public override Guid ComponentGuid
        {
            get { return new Guid("b7d8cb97-3e11-4ceb-9057-83f1c52efaa2"); }
        }
    }
}