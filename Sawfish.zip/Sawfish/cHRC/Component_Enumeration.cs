﻿using System;
using System.Collections.Generic;

using Grasshopper.Kernel;
using Rhino.Geometry;

namespace cHRC
{
    public class Component_Enumeration : GH_Component
    {
        /// <summary>
        /// Initializes a new instance of the MyComponent1 class.
        /// </summary>
        public Component_Enumeration()
          : base("Enumeration", "Enumeration",
              "Creates an Plane at the center of a polyline and the correlating index as number",
              "cHRC", "03 Dimensioning")
        {
        }

        /// <summary>
        /// Registers all the input parameters for this component.
        /// </summary>
        protected override void RegisterInputParams(GH_Component.GH_InputParamManager pManager)
        {

            pManager.AddCurveParameter("Pl", "Pl", "Polyline Input for the offset, as list", GH_ParamAccess.list); //00


            pManager.AddIntegerParameter("PlaneMethod", "PM", "0 for Plane X vector paralell to the first polygon edge, 1 for plane X vector paralell to the polygons longest edge", GH_ParamAccess.item, 0);  //04


            pManager.AddIntegerParameter("StartIteration", "Si", "StartIndex if Manual iteration is true", GH_ParamAccess.item, -1); //03

            pManager.AddIntegerParameter("MaxIterations", "Mi", "Maximal Iteration Count if Manuak Itreration is true, should not be higher than Cinput Curve count minus start Iteration  index", GH_ParamAccess.item, -1); //02


        }





        /// <summary>
        /// Registers all the output parameters for this component.
        /// </summary>
        protected override void RegisterOutputParams(GH_Component.GH_OutputParamManager pManager)
        {


            pManager.AddNumberParameter("Indexes", "i", "The Indexes as numbers correlating to the plane list (i)", GH_ParamAccess.list);  //01

            pManager.AddPlaneParameter("CenterPlanes", "CP", "A List of Planes at the centers of the input polylines", GH_ParamAccess.list);  //00

        }




        /// <summary>
        /// This is the method that actually does the work.
        /// </summary>
        /// <param name="DA">The DA object is used to retrieve from inputs and store in outputs.</param>
        protected override void SolveInstance(IGH_DataAccess DA)
        {


            List<Curve> iCurves = new List<Curve>();   //00



            int iPlaneMethod = 0; //04




            double iPlaneRot = 0.0; //05


            int iPlaneFlip = 0; //06


            double iMoveX = 0.0; //07

            double iMoveY = 0.0; //08

            double iMoveZ = 0.0; //09






            //  bool oManItOn = false;  //01

            int oManStIndex = -1; //03

            int oManIt = -1; //02

          











            if (!DA.GetDataList<Curve>(0, iCurves)) { return; } //  0



            if (!DA.GetData(1, ref iPlaneMethod)) return; //04







            if (!DA.GetData(2, ref oManStIndex)) return; //03


            if (!DA.GetData(3, ref oManIt)) return;  //02






            // Enable to define the iteration start and the iteration count without being out of range all the time



            int myStartIndex = 0;

            int iteration = 0;



            if (oManStIndex == -1 & oManIt == -1)

            {
                myStartIndex = 0;

                iteration = iCurves.Count;

                //  iteration = 2;
            }





            if (oManStIndex > -1 & oManIt == -1)

            {

                if (oManStIndex < iCurves.Count)

                {

                    myStartIndex = oManStIndex;

                    iteration = iCurves.Count - oManStIndex;

                }


                else

                {

                    myStartIndex = iCurves.Count - 1;

                    iteration = 1;


                }



            }





            if (oManStIndex == -1 & oManIt > -1)

            {


                if (oManIt < iCurves.Count)

                {
                    myStartIndex = 0;

                    iteration = oManIt;

                }

                else

                {

                    myStartIndex = 0;

                    iteration = iCurves.Count;
                }


            }





            if (oManStIndex > -1 & oManIt > -1)

            {


                if (oManStIndex < iCurves.Count)

                {
                    myStartIndex = oManStIndex;


                    if (oManIt + oManStIndex < iCurves.Count)

                    {
                        iteration = oManIt;
                    }


                    else

                    {
                        iteration = iCurves.Count - oManStIndex;
                    }



                }



                else

                {
                    myStartIndex = iCurves.Count - 1;

                    iteration = 1;

                }



            }








            List<Plane> allMyTopPlanes = new List<Plane>();


            List<int> allMyIndexes = new List<int>();




            //Main Loop



            for (int i = myStartIndex; i < iteration + myStartIndex; i++)
            {



                Polyline myPolyL;  //polyline to work with


                iCurves[i].TryGetPolyline(out myPolyL);   //c# studio


                allMyIndexes.Add(i);





                List<Point3d> myTopPoints3d = new List<Point3d>();




             //   Polyline myPolyL = iCurves[i];  c# gh




                // Adding polyline points to a list

                for (int j = 0; j < myPolyL.Count; j++)
                {


                    myTopPoints3d.Add(myPolyL[j]);

                }







                Polyline myTopPoly = new Polyline(myTopPoints3d);



                Point3d myCenterTop = PolylineAverage(myTopPoly);



                // find the longes polyline edge to use it as Plane x Vec 


                Vector3d myLongestX = new Vector3d();

                Vector3d myAdjacantY = new Vector3d();

                double myLongestDist = 0.000000000000001;





                int iPlaneFlip2;


                if (iPlaneFlip == 0)

                {
                    iPlaneFlip2 = 1;
                }

                else

                {
                    iPlaneFlip2 = -1;
                }



                // find the longes polyline edge to use it as Plane x Vec 

                for (int j = 0; j < myTopPoints3d.Count - 1; j++)
                {

                    double tDist = myTopPoints3d[j].DistanceTo(myTopPoints3d[j + 1]);

                    if (tDist > myLongestDist)

                    {
                        myLongestDist = tDist;

                        myLongestX = myTopPoints3d[j] - myTopPoints3d[j + 1];


                        if (j < 2)

                        {
                            myAdjacantY = (myTopPoints3d[j + 1] - myTopPoints3d[j + 2]) * (iPlaneFlip2);
                        }

                        else

                        {
                            myAdjacantY = (myTopPoints3d[j] - myTopPoints3d[j - 1]) * (iPlaneFlip2);
                        }

                    }

                }









                List<Plane> myPlanesChose = new List<Plane>();


                // Plane with X vec = first polyline edge

                Plane myTopPlane0 = new Plane(myCenterTop, myTopPoints3d[3] - myTopPoints3d[2], (myCenterTop - myTopPoints3d[2]) * iPlaneFlip2);

                Vector3d myNormalVec = myTopPlane0.ZAxis;


                myPlanesChose.Add(myTopPlane0);



                // Plane with longest edge vec = plane X vec


                Plane myTopPlaneLongestX = new Plane(myCenterTop, myLongestX, myAdjacantY);

                myPlanesChose.Add(myTopPlaneLongestX);


                // choosing the plane...

                Plane myTopPlane1 = myPlanesChose[iPlaneMethod];


                // move the plane

                Point3d myMovedCenter = myCenterTop + myTopPlane1.XAxis * iMoveX + myTopPlane1.YAxis * iMoveY + myNormalVec * iMoveZ;


                Plane myTopPlane = new Plane(myMovedCenter, myTopPlane1.XAxis, myTopPlane1.YAxis);


                //rotate the plane

                double myRadians = Rhino.RhinoMath.ToRadians(iPlaneRot);

                myTopPlane.Rotate(myRadians, myTopPlane.ZAxis);


                allMyTopPlanes.Add(myTopPlane);







            }





            /*

            oAllMyTopPlanes = allMyTopPlanes;


            oAllmyIndexes = allMyIndexes;

    */



            DA.SetDataList(0, allMyIndexes);

            DA.SetDataList(1, allMyTopPlanes);

            



        }











        // A function for the polyline average of closed polylines, note that the last polylinepont(on the first) is not added to the average calculation

        public static Point3d PolylineAverage(Polyline iPolyL)
        {

            Point3d PCenterT2 = new Point3d(0, 0, 0);


            for (int i = 0; i < iPolyL.Count - 1; i++)

            {
                PCenterT2 = PCenterT2 + iPolyL[i];
            }

            Point3d PCenter3 = PCenterT2 / (iPolyL.Count - 1);


            return PCenter3;
        }










        /// <summary>
        /// Provides an Icon for the component.
        /// </summary>
        protected override System.Drawing.Bitmap Icon
        {
            get
            {
                //You can add image files to your project resources and access them like this:
                // return Resources.IconForThisComponent;

                // return null;


                return Resource1.enumeration;


            }
        }

        /// <summary>
        /// Gets the unique ID for this component. Do not change this ID after release.
        /// </summary>
        public override Guid ComponentGuid
        {
            get { return new Guid("6713fe7c-bab2-4c76-93ab-dd2bf2cdcd97"); }
        }
    }
}