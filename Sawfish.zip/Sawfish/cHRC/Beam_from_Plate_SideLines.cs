﻿using System;
using System.Collections.Generic;

using Grasshopper.Kernel;
using Grasshopper.Kernel.Data;
using Grasshopper.Kernel.Types;

using Rhino.Geometry;


namespace cHRC
{
    public class Beam_from_Plate_SideLines : GH_Component
    {
        /// <summary>
        /// Initializes a new instance of the MyComponent7 class.
        /// </summary>
        public Beam_from_Plate_SideLines()
          : base("Beam_from_Plate_SideLines", "BfPS",
              "Creates the sidlelines of beams inside of a plate based on the plates sideline",
           "cHRC", "02 Offset Geometry")
        {
        }

        /// <summary>
        /// Registers all the input parameters for this component.
        /// </summary>
        protected override void RegisterInputParams(GH_Component.GH_InputParamManager pManager)
        {
            // Use the pManager object to register your input parameters.
            // You can often supply default values when creating parameters.
            // All parameters must have the correct access type. If you want 
            // to import lists or trees of values, modify the ParamAccess flag.
            /*
            pManager.AddPlaneParameter("Plane", "P", "Base plane for spiral", GH_ParamAccess.item, Plane.WorldXY);
            pManager.AddNumberParameter("Inner Radius", "R0", "Inner radius for spiral", GH_ParamAccess.item, 1.0);
            pManager.AddNumberParameter("Outer Radius", "R1", "Outer radius for spiral", GH_ParamAccess.item, 10.0);
            pManager.AddIntegerParameter("Turns", "T", "Number of turns between radii", GH_ParamAccess.item, 10);
            */


            pManager.AddCurveParameter("Polylines", "Pl", "Polyline Input for the offset", GH_ParamAccess.list); //00


            pManager.AddNumberParameter("OffsetLength", "OL", "Offset Distance in mm", GH_ParamAccess.item, 58);  //01

            pManager.AddNumberParameter("IntersectTolerance", "IT", "Intersection Check tolerance, dont think about keep on zero try to increase when something does not work, its to check the offset direction by intersections", GH_ParamAccess.item, 0.0000);  //02

            pManager.AddBooleanParameter("OffsetDirection", "OD", "Flip the offset direction by a bool  true or false", GH_ParamAccess.item, true);  //03



         //   pManager.AddIntegerParameter("StartIteration", "Si", " Start Iteration if larger than -1", GH_ParamAccess.item, -1); //04



          //  pManager.AddIntegerParameter("MaxIterations", "Mi", "Maximal Iteration if larger than -1", GH_ParamAccess.item, -1); //05


            pManager.AddCurveParameter("SideLines", "SL", "SideLines / Curves of the Plates ", GH_ParamAccess.tree); //04




            // If you want to change properties of certain parameters, 
            // you can use the pManager instance to access them by index:
            //pManager[0].Optional = true;
        }

        /// <summary>
        /// Registers all the output parameters for this component.
        /// </summary>
        protected override void RegisterOutputParams(GH_Component.GH_OutputParamManager pManager)
        {
            // Use the pManager object to register your output parameters.
            // Output parameters do not have default values, but they too must have the correct access type.

            // pManager.AddCurveParameter("Spiral", "S", "Spiral curve", GH_ParamAccess.item);




            pManager.AddCurveParameter("OffsetBeamPolyline", "BPl", "The Offseted Beam Polyline", GH_ParamAccess.list);  //00

            pManager.AddCurveParameter("OffsetPolyline", "Pl", "The Offseted Polyline", GH_ParamAccess.list);  //01

          //  pManager.AddCurveParameter("OffsetPolyline", "Pl", "The Offseted Polyline", GH_ParamAccess.list);  //02


          //  pManager.AddPointParameter("TestPoints", "TP", "TEEESSSTTT POINT", GH_ParamAccess.list);  //03


            pManager.AddCurveParameter("BeamSideLines", "BSL", "The Beam Sidelines bases on the input plate sidelines", GH_ParamAccess.list);  //02


            // pManager.AddCurveParameter("BeamSideLines", "BSL", "The Beams SideLines", GH_ParamAccess.tree); //04




            // Sometimes you want to hide a specific parameter from the Rhino preview.
            // You can use the HideParameter() method as a quick way:
            //pManager.HideParameter(0);
        }

        /// <summary>
        /// This is the method that actually does the work.
        /// </summary>
        /// <param name="DA">The DA object can be used to retrieve data from input parameters and 
        /// to store data in output parameters.</param>
        protected override void SolveInstance(IGH_DataAccess DA)
        {
            // First, we need to retrieve all data from the input parameters.
            // We'll start by declaring variables and assigning them starting values.



            List<Curve> iCurves = new List<Curve>();   //00

            double oWidth = 50; //01

            double oOffsetIntersectChecTol = 0.0000; //02

            bool oOffsetDirection = true; //03

         //   int oManStIndex = -1; //04

         //   int oManIt = -1; //05



            GH_Structure<GH_Curve> iCurvesTree = new GH_Structure<GH_Curve>();  //04





            // Then we need to access the input parameters individually. 
            // When data cannot be extracted from a parameter, we should abort this method.




            if (!DA.GetDataList<Curve>(0, iCurves)) { return; } //  00



            if (!DA.GetData(1, ref oWidth)) return;  //01

            if (!DA.GetData(2, ref oOffsetIntersectChecTol)) return;  //02

            if (!DA.GetData(3, ref oOffsetDirection)) return;  //03


          //  if (!DA.GetData(4, ref oManStIndex)) return;  //04

          //  if (!DA.GetData(5, ref oManIt)) return;  //05



           if (!DA.GetDataTree<GH_Curve>(4, out iCurvesTree)) return;    //04




           


            /*


            int iteration;                                      // Manual or full listlenght auto iteration

            if (oManIt >= 0 & oManIt2 < iCurves.Count)

            {
                iteration = oManIt2;
            }

            else

            {
                iteration = iCurves.Count;
            }



            */


           /*


            // Enable to define the iteration start and the iteration count without being out of range all the time

            int myStartIndex = 0;

            int iteration = 0;



            if (oManStIndex == -1 & oManIt == -1)

            {
                myStartIndex = 0;

                iteration = iCurves.Count;

                //  iteration = 2;
            }





            if (oManStIndex > -1 & oManIt == -1)

            {

                if (oManStIndex < iCurves.Count)

                {

                    myStartIndex = oManStIndex;

                    iteration = iCurves.Count - oManStIndex;

                }


                else

                {

                    myStartIndex = iCurves.Count - 1;

                    iteration = 1;


                }



            }





            if (oManStIndex == -1 & oManIt > -1)

            {


                if (oManIt < iCurves.Count)

                {
                    myStartIndex = 0;

                    iteration = oManIt;

                }

                else

                {

                    myStartIndex = 0;

                    iteration = iCurves.Count;
                }


            }





            if (oManStIndex > -1 & oManIt > -1)

            {


                if (oManStIndex < iCurves.Count)

                {
                    myStartIndex = oManStIndex;


                    if (oManIt + oManStIndex < iCurves.Count)

                    {
                        iteration = oManIt;
                    }


                    else

                    {
                        iteration = iCurves.Count - oManStIndex;
                    }



                }



                else

                {
                    myStartIndex = iCurves.Count - 1;

                    iteration = 1;

                }



            }



          
           */





            

            ///Convert the Grasshopper Tree Input to a List of List for  a more convenient access


            List<List<Curve>> myListOfListsIcurves = new List<List<Curve>>();



            //    for (int i = 0; i < iCurvesTree.BranchCount; i++)

            for (int i = 0; i < iCurvesTree.Branches.Count; i++)
            {

                List<Curve> myCurves = new List<Curve>();



                //for (int i = 0; i < iCurvesTree.Branches.Count; i++)  //visual studio


                for (int j = 0; j < iCurvesTree.Branches[i].Count; j++)


                {
                    // myCurves.Add(iCurvesTree.Branches(i)[j]);

                    //this originall c#gh//   myCurves.Add(iCurvesTree.Branches[i][j]);


                    //visual Studio


                    Curve rhinoCurve = null;


                    GH_Convert.ToCurve(iCurvesTree.Branches[i][j], ref rhinoCurve, 0);

                    myCurves.Add(rhinoCurve);



                }

                myListOfListsIcurves.Add(myCurves);


            }

            













            List<Point3d> pCenters = new List<Point3d>();            // Lists..

            List<Point3d> AlloKoffsets = new List<Point3d>();

            List<Polyline> AllPolylines = new List<Polyline>();

            List<Polyline> AllBeamPolylines = new List<Polyline>();


            List<List<Line>> myListListbeamLinesSuperAll = new List<List<Line>>();




            // List<Point3d> ALLmyTestPoints = new List<Point3d>();




            // List<Curve> ALLmyTestCurves = new List<Curve>();


            List<List<Curve>> ALLmyTestCurvesListList = new List<List<Curve>>();



            for (int i = 0; i < iCurves.Count; i++)                          // Main code to create offset in each polyline
            {



                // Polyline iPolyL = iCurves[i + oManStIndex]; //ToPolyline vor visual Studio c#....


                Polyline iPolyL;


                //  iCurves[i + myStartIndex].TryGetPolyline(out iPolyL);


                iCurves[i].TryGetPolyline(out iPolyL);






                Point3d PCenter = PolylineAverage(iPolyL);              // Function for the polygon center, used as input for the offsetfunction

                pCenters.Add(PCenter);                                  //(to distinguish between inside and outside offset, see functions)




                List<Point3d> OkOffset = OKpointOffset(iPolyL, oWidth, PCenter, oOffsetIntersectChecTol, oOffsetDirection);   // Function to create the offset

                for (int j = 0; j < OkOffset.Count; j++)

                {
                    AlloKoffsets.Add(OkOffset[j]);
                }



                OkOffset.Add(OkOffset[0]);



                Polyline offsetPolyline = new Polyline(OkOffset);       //Inside Polyline from offseted points

                AllPolylines.Add(offsetPolyline);

                



              //  List<List<Line>> myListListbeamLines = new List<List<Line>>();



                List<Polyline> beamPolylines = beamPolyline(iPolyL, OkOffset, myListOfListsIcurves[i]);      //OK Polylines per Beam






                for (int j = 0; j < beamPolylines.Count; j++)

                {
                    AllBeamPolylines.Add(beamPolylines[j]);
                }





                // List<Point3d> mySuperTestpoints = beamSidLines0(iPolyL, OkOffset, myListOfListsIcurves[i]);




                /*

                for (int j = 0; j < mySuperTestpoints.Count; j++)

                {
                    ALLmyTestPoints.Add(mySuperTestpoints[j]);
                }

                */


                List<List<Curve>> mySuperTestCurves = beamSidLines0(iPolyL, OkOffset, myListOfListsIcurves[i]);


                for (int j = 0; j < mySuperTestCurves.Count; j++)

                {
                    ALLmyTestCurvesListList.Add(mySuperTestCurves[j]);
                }







            }


            /*

            oPcenters = pCenters;                                     //Output
            oPolylines_offset_triangle_inside = AllPolylines;
            oBeamPolylines = AllBeamPolylines;
    */










            


         Grasshopper.DataTree<Curve> myBeamSideLinesTree = new Grasshopper.DataTree<Curve>();        //ListofLists to Tree for the Output


         for (int i = 0; i < ALLmyTestCurvesListList.Count; i++)
         {

             int ListLenght333 = ALLmyTestCurvesListList[i].Count;

             for (int j = 0; j < ListLenght333; j++)
             {

                    myBeamSideLinesTree.Add(ALLmyTestCurvesListList[i][j], new GH_Path(i));

                 //myFinalPointsTree.Add(mySuperPoints[i][j], new GH_Path(i));
             }

         }


         











            //   DA.SetDataList(0, pCenters);


            DA.SetDataList(0, AllBeamPolylines);

            DA.SetDataList(1, AllPolylines);

            // DA.SetDataList(2, ALLmyTestPoints);

            //  DA.SetDataList(2, ALLmyTestCurves);


            DA.SetDataTree(2, myBeamSideLinesTree);









            // Finally assign the spiral to the output parameter.
            // DA.SetData(0, spiral);

        }











        //create the OK (Oberkannt= top line)beam from the initial polyline points and the offseted points And The beam SideCurves


        public static List<List<Curve>> beamSidLines0(Polyline iPolyL1, List<Point3d> OkOffset1, List<Curve> mySideCurvesList)
        {


            List<Polyline> beamsPolylines = new List<Polyline>();

            List<List<Line>> myListListbeamLines = new List<List<Line>>();


            Polyline iPoly0 = iPolyL1;


            Point3d P0 = iPoly0[0];
            Point3d P1 = iPoly0[1];
            Point3d P2 = iPoly0[2];

            Vector3d myVec1 = P1 - P0;
            Vector3d myVec2 = P1 - P2;

            myVec1.Unitize();
            myVec2.Unitize();

            Vector3d myCrossV1 = Rhino.Geometry.Vector3d.CrossProduct(myVec1, myVec2);

            myCrossV1.Unitize();



            Plane myPolyPlaneFromZnormal = new Plane(P0, myCrossV1);




            List<Point3d> myTestPoints = new List<Point3d>();



            List<List<Curve>> myBeamLinesListOfList = new List<List<Curve>>();





            for (int i = 0; i < iPolyL1.Count - 1; i++)

            {

                List<Point3d> okbeamPts1 = new List<Point3d>();


                okbeamPts1.Add(iPolyL1[i]);

                okbeamPts1.Add(iPolyL1[i + 1]);

                okbeamPts1.Add(OkOffset1[i + 1]);

                okbeamPts1.Add(OkOffset1[i]);

                okbeamPts1.Add(iPolyL1[i]);


                Polyline beamOKPolyline1 = new Polyline(okbeamPts1);

                beamsPolylines.Add(beamOKPolyline1);





        



                List<Curve> myBeamLines = new List<Curve>();





               //Beam  SideLines Start


                int myLastIndex;

                if(i == 0)
                {
                    myLastIndex = mySideCurvesList.Count - 1;

                }
                else
                {

                    myLastIndex = (i * 2) -1;
                }



                Curve myCurve0 = mySideCurvesList[myLastIndex];

                Curve myCurve1 = mySideCurvesList[i*2];



                Point3d myEndPoint0 = myCurve0.PointAtEnd;

                Point3d myEndPoint1 = myCurve1.PointAtEnd;

                Line myConnectLine = new Line(myEndPoint0, myEndPoint1);


                Point3d myOkNOToffsetPoint0 = iPolyL1[i];

                Point3d myOKOffset0 = OkOffset1[i];

                Vector3d myBisectingVec = myOKOffset0 - myOkNOToffsetPoint0;


                Plane myIntersectPlane = new Plane(myOkNOToffsetPoint0, myBisectingVec, myCrossV1);


                double myIntTparameter;


                Rhino.Geometry.Intersect.Intersection.LinePlane(myConnectLine, myIntersectPlane, out myIntTparameter);

                Point3d myIntersectionPoint0 = myConnectLine.PointAt(myIntTparameter);


                myTestPoints.Add(myIntersectionPoint0);



                Line mySplitLineStart = new Line(myOkNOToffsetPoint0, myIntersectionPoint0);









                Point3d myDistPointStart = myPolyPlaneFromZnormal.ClosestPoint(myEndPoint0);

                double myThicknessStart = myDistPointStart.DistanceTo(myEndPoint0);



                Point3d myNormalMovedPointStart = myOKOffset0 + myCrossV1 * myThicknessStart;


                Line myNormalMiddleLineStart = new Line(myOKOffset0, myNormalMovedPointStart);













                //Beam  SideLines End


                int myLastIndex_22;

                if (i == iPolyL1.Count - 2)
                {
                    
                    myLastIndex_22 = 0;

                }
                else
                {

                    myLastIndex_22 = (i * 2) + 2;
                }








                Curve myCurve0_22 = mySideCurvesList[(i*2)+1];

                Curve myCurve1_22 = mySideCurvesList[myLastIndex_22];   



                Point3d myEndPoint0_22 = myCurve0_22.PointAtEnd;

                Point3d myEndPoint1_22 = myCurve1_22.PointAtEnd;

                Line myConnectLine_22 = new Line(myEndPoint0_22, myEndPoint1_22);


                Point3d myOkNOToffsetPoint0_22 = iPolyL1[i+1];

                Point3d myOKOffset0_22 = OkOffset1[i+1];

                Vector3d myBisectingVec_22 = myOKOffset0_22 - myOkNOToffsetPoint0_22;


                Plane myIntersectPlane_22 = new Plane(myOkNOToffsetPoint0_22, myBisectingVec_22, myCrossV1);


                double myIntTparameter_22;


                Rhino.Geometry.Intersect.Intersection.LinePlane(myConnectLine_22, myIntersectPlane_22, out myIntTparameter_22);

                Point3d myIntersectionPoint0_22 = myConnectLine_22.PointAt(myIntTparameter_22);

                myTestPoints.Add(myIntersectionPoint0_22);


                Line mySplitLineEnd = new Line(myOkNOToffsetPoint0_22, myIntersectionPoint0_22);






                Point3d myDistPoint = myPolyPlaneFromZnormal.ClosestPoint(myEndPoint0_22);

                double myThickness = myDistPoint.DistanceTo(myEndPoint0_22);



                Point3d myNormalMovedPointEnd = myOKOffset0_22 + myCrossV1 * myThickness;


                Line myNormalMiddleLineEnd = new Line(myOKOffset0_22, myNormalMovedPointEnd);




               myBeamLines.Add(myCurve1);

               myBeamLines.Add(myCurve0_22);

               myBeamLines.Add(mySplitLineEnd.ToNurbsCurve());


               myBeamLines.Add(myNormalMiddleLineEnd.ToNurbsCurve());

               myBeamLines.Add(myNormalMiddleLineStart.ToNurbsCurve());

                

               myBeamLines.Add(mySplitLineStart.ToNurbsCurve());





                //myBeamLinesListOfList



                myBeamLinesListOfList.Add(myBeamLines);



                













            }



            return myBeamLinesListOfList;

        }




























        


        //create the OK (Oberkannt= top line)beam from the initial polyline points and the offseted points And The beam SideCurves


        public static List<Polyline> beamPolyline(Polyline iPolyL1, List<Point3d> OkOffset1, List<Curve> mySideCurvesList)
        {


            List<Polyline> beamsPolylines = new List<Polyline>();

            List<List<Line>> myListListbeamLines = new List<List<Line>>();


            Polyline iPoly0 = iPolyL1;


            Point3d P0 = iPoly0[0];
            Point3d P1 = iPoly0[1];
            Point3d P2 = iPoly0[2];

            Vector3d myVec1 = P1 - P0;
            Vector3d myVec2 = P1 - P2;

            myVec1.Unitize();
            myVec2.Unitize();

            Vector3d myCrossV1 = Rhino.Geometry.Vector3d.CrossProduct(myVec1, myVec2);

            myCrossV1.Unitize();

            






            for (int i = 0; i < iPolyL1.Count - 1; i++)

            {

                List<Point3d> okbeamPts1 = new List<Point3d>();


                okbeamPts1.Add(iPolyL1[i]);

                okbeamPts1.Add(iPolyL1[i + 1]);

                okbeamPts1.Add(OkOffset1[i + 1]);

                okbeamPts1.Add(OkOffset1[i]);

                okbeamPts1.Add(iPolyL1[i]);


                Polyline beamOKPolyline1 = new Polyline(okbeamPts1);

                beamsPolylines.Add(beamOKPolyline1);









                List<Line> myBeamLines = new List<Line>();




                Curve myCurve0 = mySideCurvesList[mySideCurvesList.Count - 1];

                Curve myCurve1 = mySideCurvesList[0];

                Point3d myEndPoint0 = myCurve0.PointAtEnd;

                Point3d myEndPoint1 = myCurve1.PointAtEnd;

                Line myConnectLine = new Line(myEndPoint0, myEndPoint1);


                Point3d myOkNOToffsetPoint0 = iPolyL1[i];

                Point3d myOKOffset0 = OkOffset1[i];

                Vector3d myBisectingVec =   myOKOffset0 - myOkNOToffsetPoint0;


                Plane myIntersectPlane = new Plane(myOkNOToffsetPoint0, myBisectingVec, myCrossV1);


                double myIntTparameter;


                Rhino.Geometry.Intersect.Intersection.LinePlane(myConnectLine, myIntersectPlane, out myIntTparameter);



            }

            return beamsPolylines;

        }




        













        //Function to get the Polyline(closed) Center (Average)


        public static Point3d PolylineAverage(Polyline iPolyL)
        {

            Point3d PCenterT2 = new Point3d(0, 0, 0);


            for (int i = 0; i < iPolyL.Count - 1; i++)

            {
                PCenterT2 = PCenterT2 + iPolyL[i];
            }

            Point3d PCenter3 = PCenterT2 / (iPolyL.Count - 1);


            return PCenter3;
        }























        //Function to create the OK polyline Offset by offseting the vertices in the bisecting angle in the correct lenght(by angle function sinus)


        public static List<Point3d> OKpointOffset(Polyline iPolyL, double width, Point3d myPcenter, double offIntersectTol, bool OffsetDirection)
        {


            List<Point3d> offsets = new List<Point3d>();


            List<Point3d> planepoints = new List<Point3d>();

            for (int i = 0; i < iPolyL.Count - 1; i++)

            {

                planepoints.Add(iPolyL[i]);
            }




            Plane Pl = new Plane();

            Plane.FitPlaneToPoints(planepoints, out Pl);



            for (int i = 0; i < iPolyL.Count - 1; i++)

            {



                Vector3d v1 = iPolyL[i] - iPolyL[i + 1];

                v1.Unitize();


                int superindex;

                if (i == 0)

                {
                    superindex = iPolyL.Count - 2;
                }

                else

                {
                    superindex = i - 1;
                }


                Vector3d v2 = iPolyL[i] - iPolyL[superindex];

                v2.Unitize();



                Vector3d sumVector = v1 + v2;

                sumVector.Unitize();



                double alpha = Vector3d.VectorAngle(sumVector, v1);


                double Hypothenuse = width / System.Math.Sin(alpha);


                Vector3d movVec = sumVector * Hypothenuse;




                Point3d movedPointPos = iPolyL[i] + movVec;     //Creat Intersection Lines from offsetted points to the polygon center to test if

                Point3d movedPointNeg = iPolyL[i] + -movVec;      //the offset goes inside or outside off the initial polyline

                //(0 interssection  events with the polyline means inside, one intersectionb event means the Outside)


                Line testLinePos = new Line(movedPointPos, myPcenter);

                Line testLineNeg = new Line(movedPointNeg, myPcenter);


                var intesectsPos = Rhino.Geometry.Intersect.Intersection.CurveCurve(testLinePos.ToNurbsCurve(), iPolyL.ToNurbsCurve(), offIntersectTol, 0.0);

                int eventsCountPos = intesectsPos.Count;




                List<Point3d> blablaLilst = new List<Point3d>();



                if (OffsetDirection)


                {



                    if (eventsCountPos == 0)

                    {
                        blablaLilst.Add(movedPointPos);


                    }

                    else

                    {
                        blablaLilst.Add(movedPointNeg);
                    }


                }



                else

                {

                    if (eventsCountPos != 0)

                    {
                        blablaLilst.Add(movedPointPos);
                    }

                    else

                    {
                        blablaLilst.Add(movedPointNeg);
                    }



                }



                Point3d projectedPoint = Pl.ClosestPoint(blablaLilst[0]);



                offsets.Add(projectedPoint);



            }



            return offsets;
        }





      




        /// <summary>
        /// The Exposure property controls where in the panel a component icon 
        /// will appear. There are seven possible locations (primary to septenary), 
        /// each of which can be combined with the GH_Exposure.obscure flag, which 
        /// ensures the component will only be visible on panel dropdowns.
        /// </summary>
        public override GH_Exposure Exposure
        {
            get { return GH_Exposure.primary; }
        }

        /// <summary>
        /// Provides an Icon for every component that will be visible in the User Interface.
        /// Icons need to be 24x24 pixels.
        /// </summary>
        protected override System.Drawing.Bitmap Icon
        {
            get
            {
                // You can add image files to your project resources and access them like this:
                //return Resources.IconForThisComponent;
                // return null;


                // return Resource1.offset257;


                return Resource1.PlateToBeam;


            }
        }
        /// <summary>
        /// Gets the unique ID for this component. Do not change this ID after release.
        /// </summary>
        public override Guid ComponentGuid
        {
            get { return new Guid("087d64fd-cebb-4e42-8f6e-a3bb9ba77765"); }
        }
    }
}