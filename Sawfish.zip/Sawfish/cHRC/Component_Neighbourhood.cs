﻿using System;
using System.Collections.Generic;

using Grasshopper.Kernel;
using Grasshopper.Kernel.Data;
using Grasshopper.Kernel.Types;

using Rhino.Geometry;

namespace cHRC
{
    public class Component_Neighbourhood : GH_Component
    {
        /// <summary>
        /// Initializes a new instance of the MyComponent1 class.
        /// </summary>
        public Component_Neighbourhood()
          : base("Neighbourhood", "Neighbourhood",
              "Calculates for each polyline the indexes of adjacant neighbour polylines (The polylines have to touch at the edges; distance 0)",
              "cHRC", "03 Dimensioning")
        {
        }

        /// <summary>
        /// Registers all the input parameters for this component.
        /// </summary>
        protected override void RegisterInputParams(GH_Component.GH_InputParamManager pManager)
        {

            //pManager.AddCurveParameter("Polylines", "Polylines", "Polyline Input for the offset, as list", GH_ParamAccess.tree); //00

            pManager.AddCurveParameter("Polylines", "Pl", "Polyline Input for the offset, as list", GH_ParamAccess.list); //00



            pManager.AddTextParameter("EdgeText", "ET", "The Text with wich a naked edge is described. Note that if oriented oll Edges are naked. Use for oriented geometry this node at the not oriented geometry, the insert the Indexes to the Oriented Text Display", GH_ParamAccess.item, "E"); //02


            pManager.AddNumberParameter("CheckDist", "CD", "The Distance from the polygon edges middlepoint to the neighbourpolygon in which the neighbour polygon is considered a neighbour (not a naked edge)", GH_ParamAccess.item, 0.01); //03



            pManager.AddIntegerParameter("StartIteration", "Si", "StartIndex if Manual iteration is true", GH_ParamAccess.item, -1); //03

            pManager.AddIntegerParameter("MaxIterations", "Mi", "Maximal Iteration Count if Manuak Itreration is true, should not be higher than Cinput Curve count minus start Iteration  index", GH_ParamAccess.item, -1); //02

         



        }

        /// <summary>
        /// Registers all the output parameters for this component.
        /// </summary>
        protected override void RegisterOutputParams(GH_Component.GH_OutputParamManager pManager)
        {


            pManager.AddTextParameter("Indexes", "i", "A Tree of indexes as strings ", GH_ParamAccess.tree); //06

            pManager.AddPlaneParameter("Planes", "P", "A tree of planes to visualize the lengths", GH_ParamAccess.tree); //05



        }

        /// <summary>
        /// This is the method that actually does the work.
        /// </summary>
        /// <param name="DA">The DA object is used to retrieve from inputs and store in outputs.</param>
        protected override void SolveInstance(IGH_DataAccess DA)
        {




            List<Curve> iCurves = new List<Curve>();   //00



            //  GH_Structure<GH_Curve> iCurvesTree = new GH_Structure<GH_Curve>();



            int iPlaneFlip = 0; //05

            double iPlaneRot = 0.0; //04


            double iMoveX = 0.0; //06

            double iMoveY = 0.0; //07

            double iMoveZ = 0.0; //08



            string myEdgeDescription = "E";

            double myCheckDist = 0.01;




            // bool oManItOn = false;  //01

            int oManStIndex = -1; //03

            int oManIt = -1; //02

     








            // if (!DA.GetDataTree<GH_Curve>(0, out iCurves0)) return;   //worked in crazy ways tree structure




            if (!DA.GetDataList<Curve>(0, iCurves)) { return; }   //00


            //  if (!DA.GetDataTree<GH_Curve>(0, out iCurvesTree)) return;    //00










            /*

            if (!DA.GetData(4, ref iPlaneFlip)) return;   //04



            if (!DA.GetData(5, ref iPlaneRot)) return;  //05



            if (!DA.GetData(6, ref iMoveX)) return;  //06

            if (!DA.GetData(7, ref iMoveY)) return;  //07

            if (!DA.GetData(8, ref iMoveZ)) return;  //08

            */





            if (!DA.GetData(1, ref myEdgeDescription)) return;  //02


            if (!DA.GetData(2, ref myCheckDist)) return;  //02


            //  if (!DA.GetData(1, ref oManItOn)) return;  //01

            if (!DA.GetData(3, ref oManStIndex)) return; //03

            if (!DA.GetData(4, ref oManIt)) return;  //02








            // Enable to define the iteration start and the iteration count without being out of range all the time




            int myStartIndex = 0;

            int iteration = 0;



            if (oManStIndex == -1 & oManIt == -1)

            {
                myStartIndex = 0;

                iteration = iCurves.Count;

                //  iteration = 2;
            }





            if (oManStIndex > -1 & oManIt == -1)

            {

                if (oManStIndex < iCurves.Count)

                {

                    myStartIndex = oManStIndex;

                    iteration = iCurves.Count - oManStIndex;

                }


                else

                {

                    myStartIndex = iCurves.Count - 1;

                    iteration = 1;


                }



            }





            if (oManStIndex == -1 & oManIt > -1)

            {


                if (oManIt < iCurves.Count)

                {
                    myStartIndex = 0;

                    iteration = oManIt;

                }

                else

                {

                    myStartIndex = 0;

                    iteration = iCurves.Count;
                }


            }





            if (oManStIndex > -1 & oManIt > -1)

            {


                if (oManStIndex < iCurves.Count)

                {
                    myStartIndex = oManStIndex;


                    if (oManIt + oManStIndex < iCurves.Count)

                    {
                        iteration = oManIt;
                    }


                    else

                    {
                        iteration = iCurves.Count - oManStIndex;
                    }



                }



                else

                {
                    myStartIndex = iCurves.Count - 1;

                    iteration = 1;

                }



            }









            List<List<Plane>> myTextPlanesListList = new List<List<Plane>>();


            List<List<string>> myIndexesListList = new List<List<string>>();






            //Visual Studio c# is slightly diffeenfrom grasshopper skript node c#....

            List<Polyline> myViusualPolylines = new List<Polyline>();


            for (int i = 0; i < iCurves.Count; i++)
            {
                Polyline myPolyL0;

                iCurves[i].TryGetPolyline(out myPolyL0);

                myViusualPolylines.Add(myPolyL0);
            }






            // Main loop


            for (int i = 0; i < iteration; i++)
            {


                // c#gh// Polyline myPolyL = iCurves[i + StartIndex];


                // Point3d myCenter = PolylineAverage(iPolyL0);



                /*

                Polyline myPolyL;


                // iCurves[i + oManStIndex].TryGetPolyline(out iPolyL3);


                iCurves[i].TryGetPolyline(out myPolyL);



            */



                //Visual Studio c# is slightly diffeenfrom grasshopper skript node c#....

                Polyline myPolyL = myViusualPolylines[i + myStartIndex];   //polyline to work with..




                //Getting the Neighbourhood info, see functions

                List<string> myindexesList = Neighbourhood(myPolyL, i, myViusualPolylines, myEdgeDescription, myCheckDist);


                myIndexesListList.Add(myindexesList);  //Adding the neighbour hood Info List for each polygon to a ListList






                List<Point3d> myTopPoints3d = new List<Point3d>();




                // getting the planes for text visualisation of the neighbourhood

                for (int j = 0; j < myPolyL.Count; j++)

                {
                    myTopPoints3d.Add(myPolyL[j]);
                }





                Polyline myTopPoly = new Polyline(myTopPoints3d);


                Point3d myCenterTop = PolylineAverage(myTopPoly);





                int iPlaneFlip2;


                if (iPlaneFlip == 0)

                {
                    iPlaneFlip2 = 1;
                }

                else

                {
                    iPlaneFlip2 = -1;
                }




                // getting planes for display in the neighbourhood numbers 


                List<Plane> myTextPlanes = new List<Plane>();



                for (int j = 0; j < myPolyL.Count - 1; j++)
                {


                    Vector3d myXvec = myPolyL[j + 1] - myPolyL[j];





                    Vector3d v1 = myPolyL[j] - myPolyL[j + 1];

                    Point3d mp0 = myPolyL[j] + v1 * -0.5;


                    Vector3d myYvec = myCenterTop - mp0;




                    Plane mySuperPl = new Plane(mp0, myXvec, myYvec);





                    Point3d myMovedCenter = mp0 + mySuperPl.XAxis * iMoveX + mySuperPl.YAxis * iMoveY + mySuperPl.ZAxis * iMoveZ;



                    Plane myTextPl = new Plane(myMovedCenter, mySuperPl.XAxis, myYvec * iPlaneFlip2);


                    double myRadians = Rhino.RhinoMath.ToRadians(iPlaneRot);

                    myTextPl.Rotate(myRadians, myTextPl.ZAxis);



                    // allMyTextPlanes.Add(myTextPl);

                    myTextPlanes.Add(myTextPl);




                }










                myTextPlanesListList.Add(myTextPlanes);









            }











            Grasshopper.DataTree<string> myIndexesTree = new Grasshopper.DataTree<string>();        //ListofLists to Tree for the Output


            for (int i = 0; i < myIndexesListList.Count; i++)
            {

                int ListLenght333 = myIndexesListList[i].Count;

                for (int j = 0; j < ListLenght333; j++)
                {

                    myIndexesTree.Add(myIndexesListList[i][j], new GH_Path(i));


                }

            }














            Grasshopper.DataTree<Plane> myTextPlanesTree = new Grasshopper.DataTree<Plane>();        //ListofLists to Tree for the Output


            for (int i = 0; i < myTextPlanesListList.Count; i++)
            {

                int ListLenght333 = myTextPlanesListList[i].Count;

                for (int j = 0; j < ListLenght333; j++)
                {

                    myTextPlanesTree.Add(myTextPlanesListList[i][j], new GH_Path(i));

                    //myFinalPointsTree.Add(mySuperPoints[i][j], new GH_Path(i));
                }

            }



            //Output to gh

            DA.SetDataTree(0, myIndexesTree);

            DA.SetDataTree(1, myTextPlanesTree);

          







            /*

            oTextplaneTree = myTextPlanesTree;

            oIndexesTree = myIndexesTree;

           */




        }












        public static Point3d PolylineAverage(Polyline iPolyL)
        {

            Point3d PCenterT2 = new Point3d(0, 0, 0);


            for (int i = 0; i < iPolyL.Count - 1; i++)

            {
                PCenterT2 = PCenterT2 + iPolyL[i];
            }

            Point3d PCenter3 = PCenterT2 / (iPolyL.Count - 1);


            return PCenter3;
        }






        // A Function to find the neighbour indexes of each polyline




        public static List<string> Neighbourhood(Polyline iPolyL, int iPolyIndex, List<Polyline> allMyPolylines, string myEdgeDescription, double myCheckDist)
        {




            List<string> myIndexes = new List<string>();




            for (int i = 0; i < iPolyL.Count - 1; i++)
            {


                Vector3d v1 = iPolyL[i] - iPolyL[i + 1];

                Point3d mp0 = iPolyL[i] + v1 * -0.5;






                List<int> myEdgeCheckIntList = new List<int>();



                for (int j = 0; j < allMyPolylines.Count; j++)
                {

                    Polyline myPl = allMyPolylines[j];

                    Point3d myCP = myPl.ClosestPoint(mp0);

                    double Distance = mp0.DistanceTo(myCP);


                    if (Distance < myCheckDist)
                    {
                        myEdgeCheckIntList.Add(0);
                    }


                }






                if (myEdgeCheckIntList.Count < 2)
                {
                    myIndexes.Add(myEdgeDescription);
                }



                else

                {

                    for (int j = 0; j < allMyPolylines.Count; j++)
                    {

                        Polyline myPl = allMyPolylines[j];

                        Point3d myCP = myPl.ClosestPoint(mp0);

                        double Distance = mp0.DistanceTo(myCP);




                        if (Distance < 0.01)
                        {

                            myEdgeCheckIntList.Add(0);


                            if (j != iPolyIndex)
                            {

                                string myString = j.ToString();

                                myIndexes.Add(myString);
                            }



                        }

                    }


                }




            }



            return myIndexes;


        }









        /// <summary>
        /// Provides an Icon for the component.
        /// </summary>
        protected override System.Drawing.Bitmap Icon
        {
            get
            {
                //You can add image files to your project resources and access them like this:
                // return Resources.IconForThisComponent;


                //return null;


                return Resource1.Neighbourhood;
            }
        }




        /// <summary>
        /// Gets the unique ID for this component. Do not change this ID after release.
        /// </summary>
        public override Guid ComponentGuid
        {
            get { return new Guid("a1bcc2ac-fbeb-4450-839d-e83ca158f684"); }
        }
    }
}