﻿using System;
using System.Collections.Generic;

using Grasshopper.Kernel;
using Rhino.Geometry;

namespace cHRC
{
    public class Component_ClosedBrep : GH_Component
    {
        /// <summary>
        /// Initializes a new instance of the MyComponent1 class.
        /// </summary>
        public Component_ClosedBrep()
          : base("07_Closed Brep", "Closed Brep",
              "Crteates a closed Brep from plate or beam sidecurves, the top and low side have to be planar",
              "cHRC", "02 Offset Geometry")
        {
        }

        /// <summary>
        /// Registers all the input parameters for this component.
        /// </summary>
        protected override void RegisterInputParams(GH_Component.GH_InputParamManager pManager)
        {


            pManager.AddLineParameter("SideLines", "SL", "The Sidelines of beams and or plates", GH_ParamAccess.list); //00

            pManager.AddNumberParameter("SideJoinTol", "T1", "The tolerance in which the side surfaces can be joined", GH_ParamAccess.item, 0.001);  //01

            pManager.AddNumberParameter("TopLowCapTol", "T2", "The tolerance in which the top and the low side can be caped", GH_ParamAccess.item, 0.001);  //02

           // pManager.AddNumberParameter("TopLowSrfTol", "T3", "The tolerance in which the top and the low surface  can be created", GH_ParamAccess.item, 0.001);  //03


        }

        /// <summary>
        /// Registers all the output parameters for this component.
        /// </summary>
        protected override void RegisterOutputParams(GH_Component.GH_OutputParamManager pManager)
        {

            pManager.AddBrepParameter("ColsedBrep", "CB", "A Closed Brep for every input list", GH_ParamAccess.item);  //00

         //   pManager.AddBrepParameter("TopSurface", "TS", "The side top Surface", GH_ParamAccess.item);  //01

            pManager.AddBrepParameter("SideSurfaces", "SS", "The side Surfaces", GH_ParamAccess.list);  //01

           // pManager.AddBrepParameter("LowerSurface", "LS", "The  lower Surface", GH_ParamAccess.item);  //03

        }

        /// <summary>
        /// This is the method that actually does the work.
        /// </summary>
        /// <param name="DA">The DA object is used to retrieve from inputs and store in outputs.</param>
        protected override void SolveInstance(IGH_DataAccess DA)
        {



            List<Line> iLines = new List<Line>();   //00

            double joinSideT = 0.001; //01

            double CapTopT = 0.001; //02

         //   double TopLowSrfTol = 0.001; //3




            if (!DA.GetDataList<Line>(0, iLines)) { return; } //  01


            if (!DA.GetData(1, ref joinSideT)) return; //02


            if (!DA.GetData(2, ref joinSideT)) return;   //03


            //   if (!DA.GetData(3, ref TopLowSrfTol)) return;   //03







            // List<Surface> TestSurfaces = new List<Surface>();

            // List<Point3d> TestPoints = new List<Point3d>();

            // List<Brep> TestBrep = new List<Brep>();




            List<Brep> JoinedSides = new List<Brep>();

            List<Brep> ClosedBrep = new List<Brep>();



            iLines.Add(iLines[0]);


            /*

            List<Line> myLoopLines = new List<Line>();


            for (int i = 0; i < iLines.Count - 1; i++)
            {
              myLoopLines.Add(iLines[i]);
            }

            myLoopLines.Add

            */




            List<Brep> myBreps = new List<Brep>();



            for (int i = 0; i < iLines.Count - 1; i++)
            {

                Point3d Start1 = iLines[i].PointAtLength(0);
                Point3d End1 = iLines[i].PointAtLength(iLines[i].Length);

                // TestPoints.Add(Start1);
                //  TestPoints.Add(End1);


                Point3d Start2 = iLines[i + 1].PointAtLength(0);
                Point3d End2 = iLines[i + 1].PointAtLength(iLines[i + 1].Length);

                //  TestPoints.Add(Start2);
                //  TestPoints.Add(End2);





              //  var mySurface = NurbsSurface.CreateFromCorners(Start1, End1, End2, Start2);

                var mySurface = NurbsSurface.CreateFromCorners(Start2, End2, End1, Start1);

                Brep myBrep = mySurface.ToBrep();

                myBreps.Add(myBrep);


            }





            Brep myJoined = Brep.JoinBreps(myBreps, joinSideT)[0];   // Join side Breps

            Brep CLOSEDBREP = myJoined.CapPlanarHoles(CapTopT);   //Cap the joined Side Breps to closed b reps



            JoinedSides.Add(myJoined);

            ClosedBrep.Add(CLOSEDBREP);











            // oTestPoints = TestPoints;

            //  oTestSurfaces = TestSurfaces;

            //  oTestBrebs = TestBrep;



            /*
            oJoinedSides = JoinedSides;

            oClosedBrep = ClosedBrep;

            */


            // Output geometry

            DA.SetData(0, CLOSEDBREP);

          //  DA.SetData(1, MyTopSrf);

            DA.SetDataList(1, myBreps);

          //  DA.SetData(3, MyLowSrf);



        }






        /// <summary>
        /// Provides an Icon for the component.
        /// </summary>
        protected override System.Drawing.Bitmap Icon
        {
            get
            {
                //You can add image files to your project resources and access them like this:
                // return Resources.IconForThisComponent;

                // return null;


                return Resource1.closed_brep;

            }
        }

        /// <summary>
        /// Gets the unique ID for this component. Do not change this ID after release.
        /// </summary>
        public override Guid ComponentGuid
        {
            get { return new Guid("a142b487-8a28-41bd-8108-b6b773110311"); }
        }
    }
}