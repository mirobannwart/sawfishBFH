﻿using System;
using System.Collections.Generic;

using Grasshopper.Kernel;
using Rhino.Geometry;



using Grasshopper.Kernel.Data;


namespace cHRC
{
    public class dd_Tri_Plates_simple : GH_Component
    {
        /// <summary>
        /// Initializes a new instance of the MyComponent1 class.
        /// </summary>
        public dd_Tri_Plates_simple()
          : base("03_Triangular_Plates_Simple", "TriSimp",
              "A Componment to offset triangular plates only, the outcut size is claculated iteratively by a distance to the tope node(not just by shortening the edge). This compinent is a interstage of the developmet: Ith might be unstable, Try platethickness 27 and Cst 30 to create a fancy star node(no garantee) ",
                "cHRC", "02 Offset Geometry")
        {
        }

        /// <summary>
        /// Registers all the input parameters for this component.
        /// </summary>
        protected override void RegisterInputParams(GH_Component.GH_InputParamManager pManager)
        {

            pManager.AddCurveParameter("Polylines", "Pl", "Polyline Input for the offset, as list", GH_ParamAccess.list); //00

            pManager.AddNumberParameter("Thickness", "T", "The material thickness, structural height in mm", GH_ParamAccess.item, 27);  //01

            pManager.AddNumberParameter("NodeBackLow", "BL", "Distance in mm to make the lower node outcut", GH_ParamAccess.item, 60);  //02

            pManager.AddNumberParameter("CheckDist", "CD", "The Distance from the polygon edges middlepoint to the neighbourpolygon in which the neighbour polygon is considered a neighbour (not a naked edge)", GH_ParamAccess.item, 0.01); //03

            pManager.AddIntegerParameter("CheckStepsNodeback", "CSt", "Accuracy of the nodeback function", GH_ParamAccess.item, 50);  //04

        }

        /// <summary>
        /// Registers all the output parameters for this component.
        /// </summary>
        protected override void RegisterOutputParams(GH_Component.GH_OutputParamManager pManager)
        {
            pManager.AddCurveParameter("SideLines", "SL", "SideLines as Tree TEST", GH_ParamAccess.tree); //00
        }



        /// <summary>
        /// This is the method that actually does the work.
        /// </summary>
        /// <param name="DA">The DA object is used to retrieve from inputs and store in outputs.</param>
        protected override void SolveInstance(IGH_DataAccess DA)
        {


            List<Curve> iCurves = new List<Curve>();   //00
  
            double oHeight = 27; //01


            double oNodeBackUK = 120; //02


            double iCheckDist = 0.01; //03

            int CheckStepsNodeback = 200; //04





            if (!DA.GetDataList<Curve>(0, iCurves)) { return; } //  0


            if (!DA.GetData(1, ref oHeight)) return; //01


            if (!DA.GetData(2, ref oNodeBackUK)) return;   //02


            if (!DA.GetData(3, ref iCheckDist)) return;  //03

            if (!DA.GetData(4, ref CheckStepsNodeback)) return;  //04










            //Expiring:


            var myDay = System.DateTime.Now.Day;

            var myMonth = System.DateTime.Now.Month;

            var myYear = System.DateTime.Now.Year;

            /*
            A = myDay;

            B = myMonth;

            C = myYear;
            */

            //ExpiringTime

            int check = 1;

            int expYear = 999999999;

            int expMonth = 03;

            int expDay = 27;



            if (myYear > expYear)
            {
                check = 0;
            }

            if (myYear == expYear)
            {
                if (myMonth > expMonth)
                {
                    check = 0;
                }

                if (myMonth == expMonth)
                {

                    if (myDay > expDay)
                    {
                        check = 0;
                    }

                }

            }



            //  E = check;




















            int myStartIndex = 0;

            int iteration = iCurves.Count;




            List<Vector3d> myNormals = new List<Vector3d>();


            List<Polyline> Icurves22 = new List<Polyline>();


            List<List<NurbsCurve>> myListListCurves = new List<List<NurbsCurve>>();


            List<NurbsCurve> myListListCurves55555555 = new List<NurbsCurve>();


            List<Point3d> myPolyCentrs = new List<Point3d>();


            List<List<NurbsCurve>> myListListSuperSideLines = new List<List<NurbsCurve>>();


            if (check != 0)  //Expiring if

            {


                //Loop through all input polylines to get all neighbour normal vectors and neighbour polygon centers which are necessary to offset the plate correctly  (Edge offset in the bisecting angle to the neighbour)

                for (int i = 0; i < iCurves.Count; i++)
                {


                    Polyline iPolyL3;  //polyline to work with

                    iCurves[i].TryGetPolyline(out iPolyL3); //visual studio work around



                    Icurves22.Add(iPolyL3);


                    myPolyCentrs.Add(PolylineAverage(iPolyL3));  //the polyline center point



                    Vector3d v4 = iPolyL3[0] - iPolyL3[1];            //get polyline normal

                    Vector3d v5 = iPolyL3[0] - iPolyL3[2];



                    Vector3d myNormal = Vector3d.CrossProduct(v4, v5);

                    myNormal.Unitize();

                    myNormals.Add(myNormal);


                }

            }//Expiring



            // main loop



            for (int i = 0; i < iteration; i++)
            {

                Polyline iPolyL0;  //polyline to work with


                iCurves[i + myStartIndex].TryGetPolyline(out iPolyL0); //necessary in visual studio 

    


                //Get the UK points of the plate by a a function see functions

                List<NurbsCurve> mySuperSideLines = UKpointOffsetLine(iPolyL0, oHeight, myPolyCentrs[i + myStartIndex], Icurves22, myPolyCentrs, myNormals, oNodeBackUK, iCheckDist, CheckStepsNodeback);

                myListListSuperSideLines.Add(mySuperSideLines);

            }






            Grasshopper.DataTree<NurbsCurve> myFinalSuperlinesTree = new Grasshopper.DataTree<NurbsCurve>();        //ListofLists to Tree for the Output

            for (int i = 0; i < myListListSuperSideLines.Count; i++)
            {
                int ListLenght333 = myListListSuperSideLines[i].Count;

                for (int j = 0; j < ListLenght333; j++)
                {
                    myFinalSuperlinesTree.Add(myListListSuperSideLines[i][j], new GH_Path(i));

                }

            }



            DA.SetDataTree(0, myFinalSuperlinesTree);


        }







        public static Point3d PolylineAverage(Polyline iPolyL)     //A Function to get the center of a closed polyline
        {

            Point3d PCenterT2 = new Point3d(0, 0, 0);


            for (int i = 0; i < iPolyL.Count - 1; i++)

            {
                PCenterT2 = PCenterT2 + iPolyL[i];
            }

            Point3d PCenter3 = PCenterT2 / (iPolyL.Count - 1);


            return PCenter3;
        }




        // A Function to offset the plate  top polyline points

        // The endpoints of the edges are moved in the bisecting vector of the adjacant polyline normal vectors. To get the correct and uniform material Thickness offset Distance is calculated with a math cosinus function 
        //in dependence of the material thickness.
        //If an edge is naked and there is no neighbour polyline,
        //the edges Endpoints are moved in the polylines normal vector: Distance: Matetrial Thickness





        public static List<NurbsCurve> UKpointOffsetLine(Polyline iPolyL, double height, Point3d myPcenter, List<Polyline> allMyPolylines, List<Point3d> allmyPcenters, List<Vector3d> superNormals, double nodeBack, double myCheckDist, int CheckStepsNodeback)
        {



            List<NurbsCurve> mySideLines = new List<NurbsCurve>();


        

            for (int i = 0; i < iPolyL.Count - 1; i++)

            {


                Vector3d v1 = iPolyL[i] - iPolyL[i + 1];

                Point3d mp0 = iPolyL[i] + v1 * -0.5;


                double EdgeLength = iPolyL[i].DistanceTo(iPolyL[i + 1]);



                List<Point3d> myNeighbourCenterPoints = new List<Point3d>();

                List<Vector3d> myNeighbourVectors = new List<Vector3d>();




                for (int j = 0; j < allMyPolylines.Count; j++)
                {

                    Polyline myPl = allMyPolylines[j];

                    Point3d myCP = myPl.ClosestPoint(mp0);

                    double Distance = mp0.DistanceTo(myCP);


                    if (Distance < myCheckDist)
                    {
                        
                        myNeighbourCenterPoints.Add(allmyPcenters[j]);

                        myNeighbourVectors.Add(superNormals[j]);
                    }

                }








                if (myNeighbourCenterPoints.Count < 2)

                {


                    Vector3d moveVec = Vector3d.CrossProduct(v1, myNeighbourCenterPoints[0] - iPolyL[i]);

                    moveVec.Unitize();

                    Point3d myUKpoint0 = iPolyL[i] + moveVec * height;

                    Point3d myUKpoint1 = iPolyL[i + 1] + moveVec * height;

                    v1.Unitize();





                    Point3d StartRangePointEdge = myUKpoint0 + v1  *-1 * EdgeLength *0.3;

                    Point3d EndRangePointEdge = myUKpoint0;



                    Point3d myNodeclosest = new Point3d();

                    double myNodeClosestDist = 10000000000000000;


                  //  int checkSteps = 50;

                    double myMoveDist = StartRangePointEdge.DistanceTo(EndRangePointEdge) / CheckStepsNodeback;






                    for (int j = 0; j < CheckStepsNodeback; j++)
                    {
                        Point3d tempCheckPoint = StartRangePointEdge + v1  * myMoveDist * j;

                        double tempCheckDist = tempCheckPoint.DistanceTo(iPolyL[i]);

                        if (tempCheckDist > nodeBack)
                        {
                            if (tempCheckDist < myNodeClosestDist)
                            {
                                myNodeclosest = tempCheckPoint;
                                myNodeClosestDist = tempCheckDist;
                           }          
                       }
                    }






                    //2

                    Point3d StartRangePointEdge2 = myUKpoint1 + v1 *  EdgeLength * 0.3;

                    Point3d EndRangePointEdge2 = myUKpoint1 ;



                 //   Line myTest222 = new Line(StartRangePointEdge2, EndRangePointEdge2);

                 //   NurbsCurve myTest222Nurb = myTest222.ToNurbsCurve();

                 //   mySideLines.Add(myTest222Nurb);





                    Point3d myNodeclosest2 = new Point3d();

                    double myNodeClosestDist2 = 10000000000000000;



                    for (int j = 0; j < CheckStepsNodeback; j++)
                    {
                        Point3d tempCheckPoint2 = EndRangePointEdge2 + v1  * myMoveDist * j;

                        double tempCheckDist2 = tempCheckPoint2.DistanceTo(iPolyL[i+1]);

                        if (tempCheckDist2 > nodeBack)
                        {
                            if (tempCheckDist2 < myNodeClosestDist2)
                            {
                                myNodeclosest2 = tempCheckPoint2;
                                myNodeClosestDist2 = tempCheckDist2;
                            }
                        }
                    }






                    Line mySideLine = new Line(iPolyL[i], myNodeclosest);

                    NurbsCurve mySidleineNurb = mySideLine.ToNurbsCurve();

                    mySideLines.Add(mySidleineNurb);



                    Line mySideLine2 = new Line(iPolyL[i+1], myNodeclosest2);

                    NurbsCurve mySidleineNurb2 = mySideLine2.ToNurbsCurve();

                    mySideLines.Add(mySidleineNurb2);














                }

















                else


                {


                    Vector3d moveVecSum2 = myNeighbourVectors[0] + myNeighbourVectors[1];

                    moveVecSum2.Unitize();




                    double alpha = Vector3d.VectorAngle(moveVecSum2, myNeighbourVectors[1]);


                    double Hypothenuse = height / System.Math.Cos(alpha);



                    Point3d myUKpoint0 = iPolyL[i] + moveVecSum2 * Hypothenuse * -1;

                    Point3d myUKpoint1 = iPolyL[i + 1] + moveVecSum2 * Hypothenuse * -1;



                    v1.Unitize();






                    Point3d StartRangePointEdge = myUKpoint0 + v1 * -1 * EdgeLength * 0.3;

                    Point3d EndRangePointEdge = myUKpoint0;



                    Point3d myNodeclosest = new Point3d();

                    double myNodeClosestDist = 10000000000000000;


                    int checkSteps = 50;

                    double myMoveDist = StartRangePointEdge.DistanceTo(EndRangePointEdge) / checkSteps;






                    for (int j = 0; j < CheckStepsNodeback; j++)
                    {
                        Point3d tempCheckPoint = StartRangePointEdge + v1 * myMoveDist * j;

                        double tempCheckDist = tempCheckPoint.DistanceTo(iPolyL[i]);

                        if (tempCheckDist > nodeBack)
                        {
                            if (tempCheckDist < myNodeClosestDist)
                            {
                                myNodeclosest = tempCheckPoint;
                                myNodeClosestDist = tempCheckDist;
                            }
                        }
                    }






                    //2

                    Point3d StartRangePointEdge2 = myUKpoint1 + v1 * EdgeLength * 0.3;

                    Point3d EndRangePointEdge2 = myUKpoint1;



                //    Line myTest222 = new Line(StartRangePointEdge2, EndRangePointEdge2);

                  //  NurbsCurve myTest222Nurb = myTest222.ToNurbsCurve();

                //    mySideLines.Add(myTest222Nurb);





                    Point3d myNodeclosest2 = new Point3d();

                    double myNodeClosestDist2 = 10000000000000000;



                    for (int j = 0; j < CheckStepsNodeback; j++)
                    {
                        Point3d tempCheckPoint2 = EndRangePointEdge2 + v1 * myMoveDist * j;

                        double tempCheckDist2 = tempCheckPoint2.DistanceTo(iPolyL[i + 1]);

                        if (tempCheckDist2 > nodeBack)
                        {
                            if (tempCheckDist2 < myNodeClosestDist2)
                            {
                                myNodeclosest2 = tempCheckPoint2;
                                myNodeClosestDist2 = tempCheckDist2;
                            }
                        }
                    }






                    Line mySideLine = new Line(iPolyL[i], myNodeclosest);

                    NurbsCurve mySidleineNurb = mySideLine.ToNurbsCurve();

                    mySideLines.Add(mySidleineNurb);



                    Line mySideLine2 = new Line(iPolyL[i + 1], myNodeclosest2);

                    NurbsCurve mySidleineNurb2 = mySideLine2.ToNurbsCurve();

                    mySideLines.Add(mySidleineNurb2);







































                }


            }

       


              return mySideLines;


        }








        /// <summary>
        /// Provides an Icon for the component.
        /// </summary>
        protected override System.Drawing.Bitmap Icon
        {
            get
            {
                //You can add image files to your project resources and access them like this:
                // return Resources.IconForThisComponent;
                // return null;


                return Resource1.Plate_Simple_tr7;
            }
        }

        /// <summary>
        /// Gets the unique ID for this component. Do not change this ID after release.
        /// </summary>
        public override Guid ComponentGuid
        {
            get { return new Guid("3717e3b3-4611-4435-b190-421f1fa8501c"); }
        }
    }
}