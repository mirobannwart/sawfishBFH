﻿using System;
using System.Collections.Generic;

using Grasshopper.Kernel;
using Rhino.Geometry;

namespace cHRC
{
    public class Dif_Growth_on_Mesh : GH_Component
    {
        /// <summary>
        /// Initializes a new instance of the MyComponent7 class.
        /// </summary>
        public Dif_Growth_on_Mesh()
          : base("05_Dif_growth_on_mesh", "Dif_grw",
              "Agentbased differential growth on mesh, silent zombi solver, ",
              "cHRC", "05 WIP agentTPI + and more")
        {
        }

        /// <summary>
        /// Registers all the input parameters for this component.
        /// </summary>
        protected override void RegisterInputParams(GH_Component.GH_InputParamManager pManager)
        {
            pManager.AddPointParameter("Starting_Points", "Pt", "Starting points", GH_ParamAccess.list); //0

            pManager.AddIntegerParameter("Max_Centers", "MaxPt", "Maximal allowed amount of centers in the simulation", GH_ParamAccess.item, 158); //1

            pManager.AddMeshParameter("Mesh", "M", "The Mesh to let the agents walk on", GH_ParamAccess.item);  //2

            pManager.AddNumberParameter("Radius", "R", "Agent Radius", GH_ParamAccess.item, 0.9);  //3

            pManager.AddBooleanParameter("OnMesh", "onM", "Keep the agents on the mesh", GH_ParamAccess.item, true);  //4

            pManager.AddIntegerParameter("MaxIterations", "maxIt", "for silent mode (not used...) (int)", GH_ParamAccess.item, 40);  //5



        }

        /// <summary>
        /// Registers all the output parameters for this component.
        /// </summary>
        protected override void RegisterOutputParams(GH_Component.GH_OutputParamManager pManager)
        {


            pManager.AddPointParameter("Centers", "C", "Centers", GH_ParamAccess.list);


        }

        /// <summary>
        /// This is the method that actually does the work.
        /// </summary>
        /// <param name="DA">The DA object is used to retrieve from inputs and store in outputs.</param>
        protected override void SolveInstance(IGH_DataAccess DA)
        {




            List<Point3d> iStartingPositions = new List<Point3d>();   //0

            int iMaxCenterCount = 20;  //1




            Mesh iMesh = null;  //2




            double iRadius = 0.9;  //3



            bool iOnMesh = true;  //4



            int iMaxIt = 20; //5







            if (!DA.GetDataList<Point3d>(0, iStartingPositions)) { return; } //  0

            if (!DA.GetData(1, ref iMaxCenterCount)) return;  // 1



            if (!DA.GetData(2, ref iMesh)) return;  // 2


            if (!DA.GetData(3, ref iRadius)) return; //3

            if (!DA.GetData(4, ref iOnMesh)) return;  //4



            if (!DA.GetData(5, ref iMaxIt)) return; //5
















            centers = new List<Point3d>(iStartingPositions);


            n = 0;




            while (n <= iMaxIt)    //for silent solver
            {


                n += 1;







                if (centers == null)


                    centers = new List<Point3d>(iStartingPositions);







                List<Vector3d> totalMoves = new List<Vector3d>();
                List<double> colliosionCounts = new List<double>();
                List<Vector3d> FinalMoveVec = new List<Vector3d>();

                for (int i = 0; i < centers.Count; i++)

                {
                    totalMoves.Add(new Vector3d(0, 0, 0));
                    colliosionCounts.Add(0.0);

                }

                double collisionDistance = iRadius * 2;

                for (int i = 0; i < centers.Count; i++)

                {

                    for (int j = 0; j < centers.Count; j++)

                    {
                        double d = centers[i].DistanceTo(centers[j]);
                        if (d > collisionDistance) continue;


                        Vector3d move = centers[i] - centers[j];
                        move.Unitize();
                        move *= 0.5 * (collisionDistance - d);

                        totalMoves[i] += move;
                        totalMoves[j] -= move;

                        colliosionCounts[i] += 1.0;
                        colliosionCounts[j] += 1.0;

                    }

                }

                for (int i = 0; i < centers.Count; i++)

                {
                    if (colliosionCounts[i] != 0.0)
                        centers[i] += totalMoves[i] / colliosionCounts[i];
                    FinalMoveVec.Add(totalMoves[i] / colliosionCounts[i]);

                }


                if (iOnMesh)

                {

                    for (int i = 0; i < centers.Count; i++)

                    {

                        // double u;
                        //double v;

                        // surface.ClosestPoint(centers[i], out u, out v);
                        // centers[i] = surface.PointAt(u, v);

                        Point3d myClosestP = iMesh.ClosestPoint(centers[i]);

                        centers[i] = myClosestP;

                    }

                }






                if (centers.Count < iMaxCenterCount)
                {
                    List<int> splitIndices = new List<int>();

                    for (int i = 0; i < centers.Count - 1; i++)

                    {
                        if (centers[i].DistanceTo(centers[i + 1]) > iRadius * 2 - .001)
                        {
                            splitIndices.Add(i + 1 + splitIndices.Count);
                        }

                    }
                    foreach (int splitIndex in splitIndices)
                    {
                        Point3d newCenter = 0.5 * (centers[splitIndex - 1] + centers[splitIndex]);
                        centers.Insert(splitIndex, newCenter);
                    }

                }


            }

           // oCenters = centers;


          //  DA.SetData(0, centers);

            DA.SetDataList(0, centers);




        }








        // Functions






        List<Point3d> centers;    //??? why that here??






        int n = 0;


















        /// <summary>
        /// Provides an Icon for the component.
        /// </summary>
        protected override System.Drawing.Bitmap Icon
        {
            get
            {
                //You can add image files to your project resources and access them like this:
                // return Resources.IconForThisComponent;



                return Resource1.DiffGrowthMesh;
            }
        }

        /// <summary>
        /// Gets the unique ID for this component. Do not change this ID after release.
        /// </summary>
        public override Guid ComponentGuid
        {
            get { return new Guid("9e4cf0e4-d3c6-46fd-a5d9-66f117308dea"); }
        }
    }
}