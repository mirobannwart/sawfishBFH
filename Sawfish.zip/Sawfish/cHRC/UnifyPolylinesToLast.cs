﻿using System;
using System.Collections.Generic;

using Grasshopper.Kernel;
using Rhino.Geometry;

namespace cHRC
{
    public class UnifyPolylinesToLast : GH_Component
    {
        /// <summary>
        /// Initializes a new instance of the MyComponent3 class.
        /// </summary>
        public UnifyPolylinesToLast()
          : base("02_UnifyPolylineNormalToLast", "UniPNtoL",
              "Reverses (Flips) for each polyline in a list the polilines vertices in dependence of the angle between the polylines normalvector and the normal vector of the previous neighbour polyline(i-1)",
              "cHRC", "01 Adjust")
        {
        }

        /// <summary>
        /// Registers all the input parameters for this component.
        /// </summary>
        protected override void RegisterInputParams(GH_Component.GH_InputParamManager pManager)
        {



            pManager.AddCurveParameter("Polylines", "Pl", "The Polylines to unify / flip", GH_ParamAccess.list); //00


        }

        /// <summary>
        /// Registers all the output parameters for this component.
        /// </summary>
        protected override void RegisterOutputParams(GH_Component.GH_OutputParamManager pManager)
        {


            pManager.AddCurveParameter("FlippedPolylines", "FPl", "The flipped / unified Polylines", GH_ParamAccess.list); //00



        }

        /// <summary>
        /// This is the method that actually does the work.
        /// </summary>
        /// <param name="DA">The DA object is used to retrieve from inputs and store in outputs.</param>
        protected override void SolveInstance(IGH_DataAccess DA)
        {




            List<Curve> myPolys = new List<Curve>();   //00


            if (!DA.GetDataList<Curve>(0, myPolys)) { return; } //  00






            //List<Polyline> myFlippedPolylines = new List<Polyline>();

            List<double> myAngles = new List<double>();

            List<Vector3d> myVecs = new List<Vector3d>();








            List<Polyline> myPolys222 = new List<Polyline>();

            for (int i = 0; i < myPolys.Count; i++)
            {

                Polyline iPolyL3;  //polyline to work with

                // iCurves[i + oManStIndex].TryGetPolyline(out iPolyL3);

                myPolys[i].TryGetPolyline(out iPolyL3); //visual studio work around

                myPolys222.Add(iPolyL3);
            }


          










            List<Polyline> myFlippedPolylines = FlipPolyToLastPoly(myPolys222);    //Function to flip polylines acording to the angle of its normal to the normal angle of its predeccesor




            DA.SetDataList(0, myFlippedPolylines);




            /*

                oFlippedPolylines = myFlippedPolylines;

                oAngles = myAngles;

                // oVecs = myVecs;

                */





        }








        public List<Polyline> FlipPolyToLastPoly(List<Polyline> myPolys)    //Function to flip polylines acording to the angle of its normal to the normal angle of its predeccesor
        {

            List<Polyline> myFlippedPolylines = new List<Polyline>();

            



            for (int i = 0; i < myPolys.Count; i++)
            {










                if (i == 0)

                {


              



                     myFlippedPolylines.Add(myPolys[i]);
                }


                else

                {
                    
                    Polyline iPoly0 = myPolys[i];

                    Polyline iPoly1 = myPolys[i - 1];

                 


           









                    Point3d P0 = iPoly0[0];
                    Point3d P1 = iPoly0[1];
                    Point3d P2 = iPoly0[2];

                    Vector3d myVec1 = P1 - P0;
                    Vector3d myVec2 = P1 - P2;

                    myVec1.Unitize();
                    myVec2.Unitize();

                    Vector3d myCrossV1 = Rhino.Geometry.Vector3d.CrossProduct(myVec1, myVec2);


                    Point3d P00 = myFlippedPolylines[myFlippedPolylines.Count - 1][0];
                    Point3d P11 = myFlippedPolylines[myFlippedPolylines.Count - 1][1];
                    Point3d P22 = myFlippedPolylines[myFlippedPolylines.Count - 1][2];

                    Vector3d myVec3 = P11 - P00;
                    Vector3d myVec4 = P11 - P22;

                    bool myVec33333 = myVec3.Unitize();

                    myVec4.Unitize();



                    Vector3d myCrossV2 = Rhino.Geometry.Vector3d.CrossProduct(myVec3, myVec4);

                    //   myVecs.Add(myCrossV2);



                    double myAngle = Rhino.Geometry.Vector3d.VectorAngle(myCrossV1, myCrossV2);

                    double myDegress = Rhino.RhinoMath.ToDegrees(myAngle);

                    //   myAngles.Add(myDegress);



                    if (myDegress <= 90)
                    {
                        myFlippedPolylines.Add(iPoly0);
                    }

                    else

                    {
                        List<Point3d> myFlippedPoints = new List<Point3d>();  

                        myFlippedPoints.Add(iPoly0[3]);         //MAke this in a loop to make it work for ngons
                        myFlippedPoints.Add(iPoly0[2]);
                        myFlippedPoints.Add(iPoly0[1]);
                        myFlippedPoints.Add(iPoly0[0]);

                        Polyline myFlippedPoly = new Polyline(myFlippedPoints);


                        //  myFlippedPolylines.Add(myFlippedPoly);

                        myFlippedPolylines.Add(myFlippedPoly);

                    }

                }


            }

          



                return myFlippedPolylines;

        }
















        /// <summary>
        /// Provides an Icon for the component.
        /// </summary>
        protected override System.Drawing.Bitmap Icon
        {
            get
            {
                //You can add image files to your project resources and access them like this:
                // return Resources.IconForThisComponent;
                //return null;


                return Resource1.Unify_Normal_lasdt;


            }
        }

        /// <summary>
        /// Gets the unique ID for this component. Do not change this ID after release.
        /// </summary>
        public override Guid ComponentGuid
        {
            get { return new Guid("14b804c7-3bcd-46e9-a76f-2f386d14d23f"); }
        }
    }
}