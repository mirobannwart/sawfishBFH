﻿using System;
using System.Collections.Generic;

using Grasshopper.Kernel;
using Rhino.Geometry;



using Grasshopper.Kernel.Data;



namespace cHRC
{
    public class ff_offset_dif_polygons_AD : GH_Component
    {
        /// <summary>
        /// Initializes a new instance of the MyComponent1 class.
        /// </summary>
        public ff_offset_dif_polygons_AD()
          : base("05_Offset_Different_Polygons_Angle_Dependent", "Off-Dif-P-AD",
              "Offstets different polygons with different vertices count. Optional: nodesituation at lower polygon:  stretch the outcut in the  direction of lower angles where intersectionbs occur often. The basius outcut is calculated iteratively in to find a similar distance to the top node point",
                "cHRC", "02 Offset Geometry")
        {
        }



        /// <summary>
        /// Registers all the input parameter for this component.
        /// </summary>
        protected override void RegisterInputParams(GH_Component.GH_InputParamManager pManager)
        {



            pManager.AddCurveParameter("Polylines", "Pl", "Polyline Input for the offset, as list", GH_ParamAccess.list); //00

            pManager.AddNumberParameter("Thickness", "T", "The material thickness, structural height in mm", GH_ParamAccess.item, 27);  //01

            pManager.AddNumberParameter("NodeBackLow", "BL", "Distance in mm to make the lower node outcut", GH_ParamAccess.item, 60);  //02

            pManager.AddNumberParameter("CheckDist", "CD", "The Distance from the polygon edges middlepoint to the neighbourpolygon in which the neighbour polygon is considered a neighbour (not a naked edge)", GH_ParamAccess.item, 0.01); //03

            pManager.AddNumberParameter("AngleEffect", "AF", "Effect of the Anglefactor 0 = no effect, 1 = full effect hhmmm is that through? its more remap target 1...", GH_ParamAccess.item, 1);  //04

            pManager.AddNumberParameter("ThresholdAngle", "TA", "Nodesituations with higher top inside Angles will not be affected by the angle correction", GH_ParamAccess.item, 45);  //05

            pManager.AddNumberParameter("adjustFindpointsFactor", "CDAdjust", "Adjust check Distance factor of the edge lenght", GH_ParamAccess.item, 0.35);  //06

            pManager.AddIntegerParameter("CheckStepsNodeback", "CSt", "Accuracy of the nodeback function", GH_ParamAccess.item, 50);  //07

            pManager.AddNumberParameter("ApproxMaxTopAngle", "AprtA", "Works together with AngleEffect (remap initial 0 to AprtA) MAybe around 140 for Triangles and less for beams becaus their inside tob angles are lower  ", GH_ParamAccess.item, 140);  //08

            pManager.AddLineParameter("NakedEdge", "NK", "Naked Edges to check Edgesituation, is necessary!! From Trianglesn not from beams, (as list)", GH_ParamAccess.list); //09
        }

        /// <summary>
        /// Registers all the output parameters for this component.
        /// </summary>
        protected override void RegisterOutputParams(GH_Component.GH_OutputParamManager pManager)
        {
  

            pManager.AddCurveParameter("SideLines", "SLA", "SideLines Adjusted as Tree TEST", GH_ParamAccess.tree); //02

        

        }



        /// <summary>
        /// This is the method that actually does the work.
        /// </summary>
        /// <param name="DA">The DA object is used to retrieve from inputs and store in outputs.</param>
        protected override void SolveInstance(IGH_DataAccess DA)
        {


            List<Curve> iCurves = new List<Curve>();   //00

            double oHeight = 27; //01


            double oNodeBackUK = 120; //02


            double iCheckDist = 0.01; //03


            double AngleFactoEfect1 = 1.0; //04


            double ThresholdAngle = 45; //05


            double AdjustCeckDistFactor = 45; //06

            int checksteps = 60; //07

            double ApproxMaxTopAngle = 140; //08

            List<Line> NakedEdges = new List<Line>();   //09




            if (!DA.GetDataList<Curve>(0, iCurves)) { return; } //  0


            if (!DA.GetData(1, ref oHeight)) return; //01


            if (!DA.GetData(2, ref oNodeBackUK)) return;   //02


            if (!DA.GetData(3, ref iCheckDist)) return;  //03

            if (!DA.GetData(4, ref AngleFactoEfect1)) return;  //04  


            if (!DA.GetData(5, ref ThresholdAngle)) return;  //05


            if (!DA.GetData(6, ref AdjustCeckDistFactor)) return;  //06

            if (!DA.GetData(7, ref checksteps)) return;  //07



            if (!DA.GetData(8, ref ApproxMaxTopAngle)) return;  //08

            if (!DA.GetDataList<Line>(9, NakedEdges)) { return; } //  09








            //Expiring:


            var myDay = System.DateTime.Now.Day;

            var myMonth = System.DateTime.Now.Month;

            var myYear = System.DateTime.Now.Year;

            /*
            A = myDay;

            B = myMonth;

            C = myYear;
            */

            //ExpiringTime

            int check = 1;

            int expYear = 999999999;

            int expMonth = 03;

            int expDay = 27;



            if (myYear > expYear)
            {
                check = 0;
            }

            if (myYear == expYear)
            {
                if (myMonth > expMonth)
                {
                    check = 0;
                }

                if (myMonth == expMonth)
                {

                    if (myDay > expDay)
                    {
                        check = 0;
                    }

                }

            }



            //  E = check;

















            int myStartIndex = 0;

            int iteration = iCurves.Count;




            List<Vector3d> myNormals = new List<Vector3d>();

            List<Polyline> Icurves22 = new List<Polyline>();

            List<List<NurbsCurve>> myListListCurves = new List<List<NurbsCurve>>();

            List<NurbsCurve> myListListCurves55555555 = new List<NurbsCurve>();

            List<Point3d> myPolyCentrs = new List<Point3d>();

            List<List<NurbsCurve>> myListListSuperSideLines = new List<List<NurbsCurve>>();

            List<Line> Testlines = new List<Line>();



            // List<Point3d> TestPoints = new List<Point3d>();







            //Loop through all input polylines to get all neighbour normal vectors and neighbour polygon centers which are necessary to offset the plate correctly  (Edge offset in the bisecting angle to the neighbour)

            for (int i = 0; i < iCurves.Count; i++)
            {
                Polyline iPolyL3;  //polyline to work with

                iCurves[i].TryGetPolyline(out iPolyL3); //visual studio work around

                Icurves22.Add(iPolyL3); // polyline to work with, List


                myPolyCentrs.Add(PolylineAverage(iPolyL3));  //the polyline center point by a function

                myNormals.Add(PolygonNormal(iPolyL3)); //the Polygon Normal  by a function
            }


            if (check != 0)  //Expiring if

            {



                // main loop, find lower points / Sidleines1 


                for (int i = 0; i < iteration; i++)
                {
                    Polyline iPolyL0;  //polyline to work with
                    iCurves[i + myStartIndex].TryGetPolyline(out iPolyL0); //necessary in visual studio 

                    //Get the UK points of the plate by a a function see functions

                    List<NurbsCurve> mySuperSideLines = UKpointOffsetLine(NakedEdges, ApproxMaxTopAngle, checksteps, iPolyL0, oHeight, myPolyCentrs[i + myStartIndex], Icurves22, myPolyCentrs, myNormals, oNodeBackUK, iCheckDist, AngleFactoEfect1, ThresholdAngle);

                    myListListSuperSideLines.Add(mySuperSideLines);

                }


            }//Expiring


            //  setting node back align.... Sidleines 2 Adjusted

            List<List<Line>> myListListSuperSideLinesAdjusted0 = SetNodeBackToAngleAdjust(myListListSuperSideLines, AdjustCeckDistFactor);


            //   Remove duplicated lines

            List<List<Line>> myListListSuperSideLinesAdjusted = new List<List<Line>>();

            for (int i = 0; i < myListListSuperSideLinesAdjusted0.Count; i++)
            {
                List<Line> LineList = RemoveDuplicates(myListListSuperSideLinesAdjusted0[i], 0.06);
                myListListSuperSideLinesAdjusted.Add(LineList);
            }










                //OUTPUTS LIST TO TREE


                //ListofLists to Tree for the Output  Sidlines not align

                Grasshopper.DataTree<NurbsCurve> myFinalSuperlinesTree = new Grasshopper.DataTree<NurbsCurve>();

            for (int i = 0; i < myListListSuperSideLines.Count; i++)
            {
                int ListLenght333 = myListListSuperSideLines[i].Count;

                for (int j = 0; j < ListLenght333; j++)
                {
                    myFinalSuperlinesTree.Add(myListListSuperSideLines[i][j], new GH_Path(i));

                }

            }



            

            //ListofLists to Tree for the Output  Sidlines  align

            Grasshopper.DataTree<Line> myListListSuperSideLinesAdjustedTree = new Grasshopper.DataTree<Line>();

            for (int i = 0; i < myListListSuperSideLinesAdjusted.Count; i++)
            {
                int ListLenght333 = myListListSuperSideLinesAdjusted[i].Count;

                for (int j = 0; j < ListLenght333; j++)
                {
                    myListListSuperSideLinesAdjustedTree.Add(myListListSuperSideLinesAdjusted[i][j], new GH_Path(i));

                }

            }

         

            //OUTPUTS


            DA.SetDataTree(0, myListListSuperSideLinesAdjustedTree); //myListListSuperSideLinesAdjusted

            //  DA.SetDataList(3, TestPoints);

        }







        //FUNCTIONS


        //A Function to get the center of a closed polyline
        public static Point3d PolylineAverage(Polyline iPolyL)
        {
            Point3d PCenterT2 = new Point3d(0, 0, 0);

            for (int i = 0; i < iPolyL.Count - 1; i++)
            {
                PCenterT2 = PCenterT2 + iPolyL[i];
            }

            Point3d PCenter3 = PCenterT2 / (iPolyL.Count - 1);

            return PCenter3;
        }



        // A Function to get  the polyline normal
        public static Vector3d PolygonNormal(Polyline iPolyL3)
        {
            Vector3d v4 = iPolyL3[0] - iPolyL3[1];
            Vector3d v5 = iPolyL3[0] - iPolyL3[2];

            Vector3d myNormal = Vector3d.CrossProduct(v4, v5);
            myNormal.Unitize();

            return myNormal;
        }




        //function to remap values

        public static double map(double s, double a1, double a2, double b1, double b2)
        {
            return b1 + (s - a1) * (b2 - b1) / (a2 - a1);
        }





        // A Function to get  the inside angles of a polygon

        public static List<double> InsideAngleListDegree(Polyline iPolyL)
        {

            List<double> inSideAnglesL = new List<double>();

            for (int i = 0; i < iPolyL.Count - 1; i++)
            {
                Vector3d v11 = iPolyL[i] - iPolyL[i + 1];
                v11.Unitize();

                int superindex;

                if (i == 0)
                {
                    superindex = iPolyL.Count - 2;
                }

                else
                {
                    superindex = i - 1;
                }

                Vector3d v22 = iPolyL[i] - iPolyL[superindex];
                v22.Unitize();

                double myAngle1 = Vector3d.VectorAngle(v11, v22);  //EVENT v22 mal -1
                double insideAngle = Rhino.RhinoMath.ToDegrees(myAngle1);

                inSideAnglesL.Add(insideAngle);

            }

            return inSideAnglesL;

        }









        // A Function to offset the plate  top polyline points to the lower level
        // The endpoints of the edges are moved in the bisecting vector of the adjacant polyline normal vectors. To get the correct and uniform material Thickness offset Distance is calculated with a math cosinus function 
        //in dependence of the material thickness.  
        //If an edge is naked and there is no neighbour polyline,
        //the edges Endpoints are moved in the polylines normal vector: Distance: Matetrial Thickness

        public static List<NurbsCurve> UKpointOffsetLine(List<Line> NakedEdges, double ApproxMaxTopAngle, int checksteps, Polyline iPolyL, double height, Point3d myPcenter, List<Polyline> allMyPolylines, List<Point3d> allmyPcenters, List<Vector3d> superNormals, double nodeBack, double myCheckDist, double anglefactorEffectFactor, double thresholdAngle)
        {


            List<NurbsCurve> mySideLines = new List<NurbsCurve>();




            List<Line> NakedLines = NakedEdges;

            /*

            //Get naked edges

           List<Line> NakedLines = new List<Line>();

            
            for (int i = 0; i < allMyPolylines.Count; i++)
            {
                Polyline myPl = allMyPolylines[i];



                for (int j = 0; j < myPl.Count-1; j++)
                {

                    Line myLine = new Line(myPl[j], myPl[j + 1]);

                    Point3d stP = myLine.From;

                    Point3d enP = myLine.To;

                    Point3d  mp = (stP + enP) / 2;

                    List<int> CheckList = new List<int>();


                    for (int k= 0; k < allMyPolylines.Count; k++)
                    {
                        Point3d CP = allMyPolylines[k].ClosestPoint(mp);

                        double myDist = mp.DistanceTo(CP);

                        if (myDist < myCheckDist)
                        {
                            CheckList.Add(1);
                        }
                    }


                    if (CheckList.Count < 2)

                    {

                        NakedLines.Add(myLine);

                    }


                    }


                }


            */








            // Getting the inside angles by a function and remap to angle factors 

            List<double> inSideAnglesL = InsideAngleListDegree(iPolyL);    //see function
            List<double> inSideAnglesLFactors = new List<double>();


            for (int i = 0; i < inSideAnglesL.Count; i++)
            {

                double anglefactor = map(inSideAnglesL[i], 0, ApproxMaxTopAngle, 1.0 + anglefactorEffectFactor, 1.0);


                if (inSideAnglesL[i] < thresholdAngle)
                {
                    inSideAnglesLFactors.Add(anglefactor);
                }
                else
                {
                    inSideAnglesLFactors.Add(1.0);
                }

            }

            inSideAnglesLFactors.Add(inSideAnglesLFactors[0]);  //  Add the first at last..




            Point3d TheCenter = PolylineAverage(iPolyL);




            //MAIN LOOP through PolylinePoints


            for (int i = 0; i < iPolyL.Count - 1; i++)
            {
                //getting edge Vector, edge Middelpoint, edge lenght, Initial Points

                Point3d initialEdgeStartP = iPolyL[i];
                Point3d initialEdgeEndP = iPolyL[i + 1];


                Vector3d v1 = initialEdgeStartP - initialEdgeEndP;

                Point3d mp0 = initialEdgeStartP + v1 * -0.5;

                double EdgeLength = initialEdgeStartP.DistanceTo(initialEdgeEndP);



                List<Point3d> myNeighbourCenterPoints = new List<Point3d>();
                List<Vector3d> myNeighbourVectors = new List<Vector3d>();


                List<Polyline> myNeighbourpolylinesStart1 = new List<Polyline>();

                List<Polyline> myNeighbourpolylinesEnd2 = new List<Polyline>();




                //getting Neighbour center points, and neighbour normal vectors from a list with all center points and and normals

                for (int j = 0; j < allMyPolylines.Count; j++)
                {
                    Polyline myPl = allMyPolylines[j];



                    //Neighbours from Edge Middlepoints MP

                    Point3d myCPmp = myPl.ClosestPoint(mp0);

                    double DistanceMP0 = mp0.DistanceTo(myCPmp);

                    if (DistanceMP0 < myCheckDist)
                    {
                        myNeighbourCenterPoints.Add(allmyPcenters[j]);
                        myNeighbourVectors.Add(superNormals[j]);
                    }





                    //Neighbours from initial edge Startpoint (initialEdgeStartP)

                    Point3d myCst = myPl.ClosestPoint(initialEdgeStartP);

                    double DistanceST = initialEdgeStartP.DistanceTo(myCst);

                    if (DistanceST < myCheckDist)
                    {
                        if (allmyPcenters[j].DistanceTo(TheCenter) > myCheckDist)
                        {
                            myNeighbourpolylinesStart1.Add(allMyPolylines[j]);

                        }

                    }




                    //Neighbours from intial edge Endpoint (initialEdgeEndP)

                    Point3d myCen = myPl.ClosestPoint(initialEdgeEndP);

                    double DistanceEnd = initialEdgeEndP.DistanceTo(myCen);

                    if (DistanceEnd < myCheckDist)
                    {
                        if (allmyPcenters[j].DistanceTo(TheCenter) > myCheckDist)
                        {
                            myNeighbourpolylinesEnd2.Add(allMyPolylines[j]);

                        }

                    }



                }  //+++










                //IF less than 2 neighbours  (Edge, event. corner)


                

                if (myNeighbourCenterPoints.Count == 1)

                {   // Function to Set the node Back at EDGE Situations  //ALWAYs NODEBACK NO PLANE INTERSECTION
                    List<NurbsCurve> SideLines1 = NodebackEdge(NakedLines, checksteps, myNeighbourpolylinesStart1, myNeighbourpolylinesEnd2, v1, myNeighbourCenterPoints[0], initialEdgeStartP, initialEdgeEndP, height, EdgeLength, inSideAnglesLFactors[i], inSideAnglesLFactors[i + 1], nodeBack);

                    mySideLines.Add(SideLines1[0]);

                    mySideLines.Add(SideLines1[1]);
                }
                
                

                

                if (myNeighbourCenterPoints.Count > 1)   //IF MORE than 2 neighbours  (Middle)

                {

                    // Function to Set the node Back at MIDDLE Situations //ALWAYs NODEBACK NO PLANE INTERSECTION

                    List<NurbsCurve> SideLines2 = NodebackMiddle(NakedLines, checksteps, myNeighbourpolylinesStart1, myNeighbourpolylinesEnd2, myNeighbourVectors, v1, myNeighbourCenterPoints[0], initialEdgeStartP, initialEdgeEndP, height, EdgeLength, inSideAnglesLFactors[i], inSideAnglesLFactors[i + 1], nodeBack);

                    mySideLines.Add(SideLines2[0]);

                    mySideLines.Add(SideLines2[1]);

                }

                

                myNeighbourCenterPoints.Clear();

            }




            return mySideLines;


        }








        // A FUNCTION to set back the lower node //NODEBACK at MIDDLE  SITUATIONS   //NO PLANE INTERSECTION ALWAYS NODE BACK   

        public static List<NurbsCurve> NodebackMiddle(List<Line> NakedEdge, int checkSteps, List<Polyline> myNeighbourpolylinesStart1, List<Polyline> myNeighbourpolylinesEnd2, List<Vector3d> myNeighbourVectors, Vector3d v1, Point3d myNeighbourCenterPoint, Point3d initialEdgeStartP, Point3d initialEdgeEndP, double height, double EdgeLength, double THEinSideAnglesLFactor, double THEinSideAnglesLFactor2End, double nodeBack)
        {

            List<NurbsCurve> mySideLines = new List<NurbsCurve>();  //for return



            Vector3d moveVecSum2 = myNeighbourVectors[0] + myNeighbourVectors[1];  //  myNeighbourVectors[0]
            moveVecSum2.Unitize();

            double alpha = Vector3d.VectorAngle(moveVecSum2, myNeighbourVectors[1]);

            double Hypothenuse = height / System.Math.Cos(alpha);

            Point3d myUKpoint0 = initialEdgeStartP + moveVecSum2 * Hypothenuse * -1;
            Point3d myUKpoint1 = initialEdgeEndP + moveVecSum2 * Hypothenuse * -1;





   

            v1.Unitize();  // is necesssary!!





            //Is Naked Check START

            //Point3d mpOK = (initialEdgeStartP + initialEdgeEndP) / 2;



            List<int> NakedCheckListStart = new List<int>();



            for (int i = 0; i < NakedEdge.Count; i++)
            {
                Point3d closestP = NakedEdge[i].ClosestPoint(initialEdgeStartP, true);

                double dist = closestP.DistanceTo(initialEdgeStartP);

                if (dist < 0.1)

                {
                    NakedCheckListStart.Add(1);
                }
            }









            //Is Naked Check END

            //Point3d mpOK = (initialEdgeStartP + initialEdgeEndP) / 2;



            List<int> NakedCheckListEnd = new List<int>();



            for (int i = 0; i < NakedEdge.Count; i++)
            {
                Point3d closestP = NakedEdge[i].ClosestPoint(initialEdgeEndP, true);

                double dist = closestP.DistanceTo(initialEdgeEndP);

                if (dist < 0.1)

                {
                    NakedCheckListEnd.Add(1);
                }
            }
















            //NODEBACK


            //   1     Point1 Start of the edge


            Point3d UKMP = (myUKpoint0 + myUKpoint1) / 2;

            Vector3d HyperMoveVec = UKMP - myUKpoint0;

            HyperMoveVec.Unitize();



         //   Line TestLine1 = new Line(StartRangePointEdge, EndRangePointEdge);

         //   mySideLines.Add(TestLine1.ToNurbsCurve());  //Dangerous, just to check




            Point3d myNodeclosest = UKMP;

            //   Point3d myNodeclosest = new Point3d();
            //  Point3d myNodeclosest = StartRangePointEdge;


            double myNodeClosestDist = 10000000000000000;


          //  int checkSteps = 50;

            double myMoveDist = (UKMP.DistanceTo(myUKpoint0) / checkSteps)*2;

            double anglefactor0 = THEinSideAnglesLFactor;  //inSideAnglesLFactors[i];




        

                if (myNeighbourpolylinesStart1.Count > 1 | NakedCheckListStart.Count > 0)

                {


                    // Create points on the edge and check which is the closest to the top node point and not closer than CheckDist (to the top node point)

                    for (int j = 0; j < checkSteps; j++)
                    {
                        Point3d tempCheckPoint = myUKpoint0 + v1 * -1 * myMoveDist * j;

                        // Point3d tempCheckPoint = myUKpoint0 + HyperMoveVec * myMoveDist * j;

                        double tempCheckDist = tempCheckPoint.DistanceTo(initialEdgeStartP);

                        if (tempCheckDist > nodeBack * anglefactor0)
                        {
                            if (tempCheckDist < myNodeClosestDist)
                            {
                                myNodeclosest = tempCheckPoint;
                                myNodeClosestDist = tempCheckDist;
                            }
                        }
                    }


                }

                else

                {

                    myNodeclosest = myUKpoint0;

                }


            


            // Create the SideLine

            Line mySideLine = new Line(initialEdgeStartP, myNodeclosest);

            NurbsCurve mySidleineNurb = mySideLine.ToNurbsCurve();

            mySideLines.Add(mySidleineNurb);







            //2     Point2 End of the edge

           //   Point3d StartRangePointEdge2 = myUKpoint1 + v1 * EdgeLength * 0.3;


            Point3d UKMP2 = (myUKpoint0 + myUKpoint1) / 2;

            Vector3d HyperVec22 = UKMP2 - myUKpoint1;

            HyperVec22.Unitize();


            //   Line TestLine2 = new Line(StartRangePointEdge2, EndRangePointEdge2);
            //   mySideLines.Add(TestLine2.ToNurbsCurve()); //Dangerous, just to check



            Point3d myNodeclosest2 = UKMP2;

         //   Point3d myNodeclosest2 = new Point3d();
         //  Point3d myNodeclosest2 = StartRangePointEdge2;



            double myNodeClosestDist2 = 10000000000000000;

            double anglefactor1 = THEinSideAnglesLFactor2End; //inSideAnglesLFactors[i + 1];



          



                if (myNeighbourpolylinesEnd2.Count > 1 | NakedCheckListEnd.Count > 0)

                {

                    // Create points on the edge an check which is closest to the top node point and not closer than CheckDist (to the top node point)

                    for (int j = 0; j < checkSteps; j++)
                    {
                        Point3d tempCheckPoint2 = myUKpoint1 + v1 * myMoveDist * j;


                        //  Point3d tempCheckPoint2 = myUKpoint1 + HyperVec22 * myMoveDist * j;


                        double tempCheckDist2 = tempCheckPoint2.DistanceTo(initialEdgeEndP);

                        if (tempCheckDist2 > nodeBack * anglefactor1)
                        {
                            if (tempCheckDist2 < myNodeClosestDist2)
                            {
                                myNodeclosest2 = tempCheckPoint2;
                                myNodeClosestDist2 = tempCheckDist2;
                            }
                        }
                    }


                }

                else

                {

                    myNodeclosest2 = myUKpoint1;

                }


            



            // Create the SideLine

            Line mySideLine2 = new Line(initialEdgeEndP, myNodeclosest2);

            NurbsCurve mySidleineNurb2 = mySideLine2.ToNurbsCurve();

            mySideLines.Add(mySidleineNurb2);


            return mySideLines;


        }










        //A Function to set back the lower node //NODEBACK at EDGE SITUATIONS  //NO PLANE INTERSECTION ALWAYS NODE BACK   

        public static List<NurbsCurve> NodebackEdge(List<Line> NakedEdge, int checksteps, List<Polyline> myNeighbourpolylinesStart1, List<Polyline> myNeighbourpolylinesEnd2, Vector3d v1, Point3d myNeighbourCenterPoint, Point3d initialEdgeStartP, Point3d initialEdgeEndP, double height, double EdgeLength, double THEinSideAnglesLFactor, double THEinSideAnglesLFactor2End, double nodeBack)
        {



            List<NurbsCurve> mySideLines = new List<NurbsCurve>();


            //move vec and move

            Vector3d moveVec = Vector3d.CrossProduct(v1, myNeighbourCenterPoint - initialEdgeStartP);

            moveVec.Unitize();

            Point3d myUKpoint0 = initialEdgeStartP + moveVec * height;      //StartEdge

            Point3d myUKpoint1 = initialEdgeEndP + moveVec * height;  //End Edge

            v1.Unitize();  // is necesssary!!



            //Is Naked Check

            Point3d mpOK = (initialEdgeStartP + initialEdgeEndP) / 2;



            List<int> NakedCheckList = new List<int>();



            for (int i = 0; i < NakedEdge.Count; i++)
            {
                Point3d closestP = NakedEdge[i].ClosestPoint(mpOK, true);

                double dist = closestP.DistanceTo(mpOK);

                if(dist < 0.1)

                {
                    NakedCheckList.Add(1);
                }            
            }








                //Vector3d v1 = initialEdgeStartP - initialEdgeEndP;

                //NODEBACK



                // 1 Startpoint of the Edge





                Point3d UKMP = (myUKpoint0 + myUKpoint1) / 2;

            Vector3d HyperMoveVec = UKMP - myUKpoint0;

            HyperMoveVec.Unitize();

            double myMoveDist = (UKMP.DistanceTo(myUKpoint0) / checksteps) * 2;
            

         //  Point3d myNodeclosest = new Point3d();
         Point3d myNodeclosest = UKMP;

         double myNodeClosestDist = 10000000000000000;


       //  int checkSteps = 50;



         double anglefactor0 = THEinSideAnglesLFactor;  // inSideAnglesLFactor[i]


            // Create points on the edge an check which is closest to the top node point and not closer than CheckDist (to the top node point)




            if (NakedCheckList.Count > 0)

            {


                for (int j = 0; j < checksteps; j++)
                {
                    //Point3d tempCheckPoint = myUKpoint0 + HyperMoveVec * myMoveDist * j;

                    Point3d tempCheckPoint = myUKpoint0 + v1 * -1 * myMoveDist * j;


                    double tempCheckDist = tempCheckPoint.DistanceTo(initialEdgeStartP);



                    if (tempCheckDist > nodeBack * anglefactor0)
                    {
                        if (tempCheckDist < myNodeClosestDist)
                        {
                            myNodeclosest = tempCheckPoint;
                            myNodeClosestDist = tempCheckDist;
                        }
                    }
                }



            }

            else

            {




                if (myNeighbourpolylinesStart1.Count > 1)

                {

                    for (int j = 0; j < checksteps; j++)
                    {
                        //Point3d tempCheckPoint = myUKpoint0 + HyperMoveVec * myMoveDist * j;

                        Point3d tempCheckPoint = myUKpoint0 + v1 * -1 * myMoveDist * j;


                        double tempCheckDist = tempCheckPoint.DistanceTo(initialEdgeStartP);



                        if (tempCheckDist > nodeBack * anglefactor0)
                        {
                            if (tempCheckDist < myNodeClosestDist)
                            {
                                myNodeclosest = tempCheckPoint;
                                myNodeClosestDist = tempCheckDist;
                            }
                        }
                    }


                }


                else
                {

                    myNodeclosest = myUKpoint0;


                }


            }

         //   Point3d myNodeclosest = myUKpoint0;  //checkTest




            // Create the SideLine

            Line mySideLine = new Line(initialEdgeStartP, myNodeclosest);

            NurbsCurve mySidleineNurb = mySideLine.ToNurbsCurve();

            mySideLines.Add(mySidleineNurb);








            // 2  Endpoint of the Edges



            Point3d UKMP2 = (myUKpoint0 + myUKpoint1) / 2;

            Vector3d HyperVec22 = UKMP2 - myUKpoint1;

            HyperVec22.Unitize();


            Point3d myNodeclosest2 = UKMP2;

            double myNodeClosestDist2 = 10000000000000000;

            double anglefactor1 = THEinSideAnglesLFactor2End;  //inSideAnglesLFactors[i + 1];





            // Create points on the edge an check which is closest to the top node point and not closer than CheckDist (to the top node point)



            if (NakedCheckList.Count > 0)

            {

                for (int j = 0; j < checksteps; j++)
                {
                    //  Point3d tempCheckPoint2 = myUKpoint1 + HyperVec22 * myMoveDist * j;

                    Point3d tempCheckPoint2 = myUKpoint1 + v1 * myMoveDist * j;

                    double tempCheckDist2 = tempCheckPoint2.DistanceTo(initialEdgeEndP);

                    if (tempCheckDist2 > nodeBack * anglefactor1)
                    {
                        if (tempCheckDist2 < myNodeClosestDist2)
                        {
                            myNodeclosest2 = tempCheckPoint2;
                            myNodeClosestDist2 = tempCheckDist2;
                        }
                    }
                }
            }

            else
            {



                if (myNeighbourpolylinesEnd2.Count > 1)

                {


                    for (int j = 0; j < checksteps; j++)
                    {
                        //  Point3d tempCheckPoint2 = myUKpoint1 + HyperVec22 * myMoveDist * j;

                        Point3d tempCheckPoint2 = myUKpoint1 + v1 * myMoveDist * j;

                        double tempCheckDist2 = tempCheckPoint2.DistanceTo(initialEdgeEndP);

                        if (tempCheckDist2 > nodeBack * anglefactor1)
                        {
                            if (tempCheckDist2 < myNodeClosestDist2)
                            {
                                myNodeclosest2 = tempCheckPoint2;
                                myNodeClosestDist2 = tempCheckDist2;
                            }
                        }
                    }

                }


                else

                {

                    myNodeclosest2 = myUKpoint1;
                }

            }


           // Point3d myNodeclosest2 = myUKpoint1;  //just check

            // Create the SideLine

            Line mySideLine2 = new Line(initialEdgeEndP, myNodeclosest2);

            NurbsCurve mySidleineNurb2 = mySideLine2.ToNurbsCurve();

            mySideLines.Add(mySidleineNurb2);




            return mySideLines;





        }







        // Correct Sidleines: A fucntion to set back lower nodepoints to the points setted back in dependdence of the to inside angle 
        //(nicht zurückgesetzte Punkte auf die zurückgesetzten zurücksetzten dort wo sonst ein Absatz entstehen würde wegen dem Winkelabhängigen zurücksetzen)
        //Checks if nodes(Endpoints at outcut/nodeback low) of neighbours are on the edge (low) to correct / shorten the edge to the neigbour point on it

        public static List<List<Line>> SetNodeBackToAngleAdjust(List<List<NurbsCurve>> myListListSuperSideLines, double AdjustCeckDistFactor)
        {


            List<List<Line>> myListListSuperSideLinesAdjusted = new List<List<Line>>();  //return





          



            /*


            //Nurbcurve to Lines

            List<List<Line>> ListListLines = new List<List<Line>>();



            for (int i = 0; i < myListListSuperSideLines.Count; i++)
            {
                List<Line> LineList = new List<Line>();

                for (int j = 0; j < myListListSuperSideLines[i].Count; j++)
                {

                    Point3d p1 = myListListSuperSideLines[i][j].PointAtStart;
                    Point3d p2 = myListListSuperSideLines[i][j].PointAtEnd;

                    Line myLine = new Line(p1, p2);
                    LineList.Add(myLine);
                }


                ListListLines.Add(LineList);
            }




            //Remove Duplicates 



            List<List<NurbsCurve>> myListListSuperSideLinesNoDup = new List<List<NurbsCurve>>();



            for (int i = 0; i < ListListLines.Count; i++)
            {

                List<Line> LineList = RemoveDuplicates(ListListLines[i], 0.06);


                List<NurbsCurve> NurbsList = new List<NurbsCurve>();



                  for (int j = 0; j < LineList.Count; j++)
                     {

                    NurbsCurve myNurbs = LineList[j].ToNurbsCurve();
                    NurbsList.Add(myNurbs);

                      }
                myListListSuperSideLinesNoDup.Add(NurbsList);

            }




          
            // Adding the first Sideline (of the sublist)  at the last position (of the sublist)


            List<List<NurbsCurve>> myListListSuperSideLinesAndStartAtEnd = new List<List<NurbsCurve>>();
            List<Point3d> allLowPoints = new List<Point3d>();




            for (int i = 0; i < myListListSuperSideLinesNoDup.Count; i++)
            {                                                                   
                List<NurbsCurve> tempNC = new List<NurbsCurve>();

                for (int j = 0; j < myListListSuperSideLinesNoDup[i].Count; j++)
                {
                    tempNC.Add(myListListSuperSideLinesNoDup[i][j]);

                    if (j != 0)
                    {
                        tempNC.Add(myListListSuperSideLinesNoDup[i][j]);
                    }

                    allLowPoints.Add(myListListSuperSideLinesNoDup[i][j].PointAtEnd);
                }

                tempNC.Add(tempNC[0]);                                      //here Out of range
                myListListSuperSideLinesAndStartAtEnd.Add(tempNC);
            }



            */









            // Adding the first Sideline (of the sublist)  at the last position (of the sublist)


            List<List<NurbsCurve>> myListListSuperSideLinesAndStartAtEnd = new List<List<NurbsCurve>>();
            List<Point3d> allLowPoints = new List<Point3d>();




            for (int i = 0; i < myListListSuperSideLines.Count; i++)
            {
                List<NurbsCurve> tempNC = new List<NurbsCurve>();

                for (int j = 0; j < myListListSuperSideLines[i].Count; j++)
                {
                    tempNC.Add(myListListSuperSideLines[i][j]);

                    
                    allLowPoints.Add(myListListSuperSideLines[i][j].PointAtEnd);
                }

                tempNC.Add(tempNC[0]);                                      //here Out of range
                myListListSuperSideLinesAndStartAtEnd.Add(tempNC);
            }














            for (int i = 0; i < myListListSuperSideLinesAndStartAtEnd.Count; i++)
            {
                List<Line> AdjustedLines = new List<Line>();


                for (int j = 0; j < myListListSuperSideLinesAndStartAtEnd[i].Count - 1; j++)
                {


                    if (j % 2 == 0)
                    {



                  //      Console.WriteLine("Test");


                        NurbsCurve myNurb = myListListSuperSideLinesAndStartAtEnd[i][j];
                        NurbsCurve myNurb2 = myListListSuperSideLinesAndStartAtEnd[i][j + 1];

                        Point3d p1 = myNurb.PointAtEnd;
                        Point3d p2 = myNurb2.PointAtEnd;

                        Point3d p1StartTop = myNurb.PointAtStart;
                        Point3d p2EndTop = myNurb2.PointAtStart;


                        Line myLine = new Line(p1, p2);

                        //Testlines.Add(myLine);


                        List<Point3d> potentialPoints = new List<Point3d>();


                        Point3d mySuperAdjustedFinalStart = new Point3d();

                        Point3d mySuperAdjustedFinalEnd = new Point3d();


                        for (int k = 0; k < allLowPoints.Count; k++)
                        {
                            Point3d myCP = myLine.ClosestPoint(allLowPoints[k], true);


                            if (myCP.DistanceTo(allLowPoints[k]) < 0.01)

                            {

                                double t1 = myLine.ClosestParameter(myCP);


                                // double tE = myLine.ClosestParameter(myLine.ToNurbsCurve().PointAtEnd);   //HERE OUT OF RANGE OR NULL

                                double myLineLength2 = myLine.Length;
                                Point3d myEndPoint = myLine.PointAtLength(myLineLength2);

                                double tE = myLine.ClosestParameter(myEndPoint);

                                if (t1 != 0 && t1 != tE)
                                {
                                    potentialPoints.Add(allLowPoints[k]);
                                    //TestPoints.Add(allLowPoints[k]);
                                }
                            }

                        }






                        //Point3d start = myLine.ToNurbsCurve().PointAtStart;   //hereNull
                        //Point3d End = myLine.ToNurbsCurve().PointAtEnd;



                        double myLineLength3 = myLine.Length;

                        Point3d start = myLine.PointAtLength(0);  //hereNull
                        Point3d End = myLine.PointAtLength(myLineLength3);





                        //potentialPoints.Add(start);
                        //potentialPoints.Add(End);
                        //Point3d mp222 = (start + End) / 2;



                        if (potentialPoints.Count > 0)
                        {
                            Point3d myAdjusted = new Point3d();
                            double myCheckDist333 = 200000000000;

                            for (int l = 0; l < potentialPoints.Count; l++)
                            {
                                double tDist = start.DistanceTo(potentialPoints[l]);

                                if (tDist < myCheckDist333)
                                {
                                    myCheckDist333 = tDist;
                                    myAdjusted = potentialPoints[l];
                                }
                            }


                            double AdjusDistTol = myLine.Length * AdjustCeckDistFactor;
                            // double AdjusDistTol = myLine.Length * 0.38;    AdjustCeckDistFactor


                            double rangeDist = myAdjusted.DistanceTo(start);

                            if (rangeDist < AdjusDistTol)
                            {
                                mySuperAdjustedFinalStart = myAdjusted;
                            }


                            else
                            {
                                mySuperAdjustedFinalStart = start;
                            }




                            Point3d myAdjusted2 = new Point3d();
                            double myCheckDist444 = 200000000000;

                            for (int l = 0; l < potentialPoints.Count; l++)
                            {
                                double tDist2 = End.DistanceTo(potentialPoints[l]);

                                if (tDist2 < myCheckDist444)
                                {
                                    myCheckDist444 = tDist2;
                                    myAdjusted2 = potentialPoints[l];
                                }
                            }



                            double rangeDist2 = myAdjusted2.DistanceTo(End);

                            if (rangeDist2 < AdjusDistTol)
                            {
                                mySuperAdjustedFinalEnd = myAdjusted2;
                            }

                            else
                            {
                                mySuperAdjustedFinalEnd = End;
                            }

                        }




                        else
                        {
                            mySuperAdjustedFinalStart = start;
                            mySuperAdjustedFinalEnd = End;
                        }





                        Line AdjustedLine1Start = new Line(p1StartTop, mySuperAdjustedFinalStart);

                        Line AdjustedLine2End = new Line(p2EndTop, mySuperAdjustedFinalEnd);

                        AdjustedLines.Add(AdjustedLine1Start);
                        AdjustedLines.Add(AdjustedLine2End);



                        //Testlines.Add(AdjustedLine1Start);
                        // Testlines.Add(AdjustedLine2End);







                    }  //here/close bracket







                }



                myListListSuperSideLinesAdjusted.Add(AdjustedLines);
            }

            return myListListSuperSideLinesAdjusted;

        }






















        // A Function to remove duplicated lines calls also fuctions below...
        public static List<Line> RemoveDuplicates(List<Line> lines, double tolerance)
        {


            // Copy original list
            List<Line> clean = new List<Line>(lines);



            // Clean up the list of duplicates
            for (int i = 0; i < clean.Count; i++)
            {
                Line line = clean[i];

                for (int j = clean.Count - 1; j > i; j--)
                {
                    Line other = clean[j];

                    bool dup = AreDuplicate(line, other, tolerance);
                    if (dup == true)
                    {
                        clean.RemoveAt(j);
                    }
                }
            }

            return clean;


        }




        // Returns true if end points of lines are similar under tolerance value
       public static bool AreDuplicate(Line lineA, Line lineB, double tolerance)

        {
            // Compare starting points
            if (
              (AreSimilar(lineA.From, lineB.From, tolerance) && AreSimilar(lineA.To, lineB.To, tolerance))
              || (AreSimilar(lineA.From, lineB.To, tolerance) && AreSimilar(lineA.To, lineB.From, tolerance))
              )

            {
                return true;
            }

            else

            {

                return false;

            }
        }






        // Returns truu if coordinates of points are similar under a threshold value
        public static bool AreSimilar(Point3d a, Point3d b, double tol)

        {
            bool similar = Math.Abs(a.X - b.X) < tol
              && Math.Abs(a.Y - b.Y) < tol
              && Math.Abs(a.Z - b.Z) < tol;

            return similar;
        }








        //MORE



        /// <summary>
        /// Provides an Icon for the component.
        /// </summary>
        protected override System.Drawing.Bitmap Icon
        {
            get
            {
                //You can add image files to your project resources and access them like this:
                // return Resources.IconForThisComponent;

                return Resource1.dif_polygon_tr3;
            }
        }

        /// <summary>
        /// Gets the unique ID for this component. Do not change this ID after release.
        /// </summary>
        public override Guid ComponentGuid
        {
            get { return new Guid("b936d722-3666-4190-8909-02351f21cee3"); }
        }
    }
}