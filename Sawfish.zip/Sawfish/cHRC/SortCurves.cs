﻿using System;
using System.Collections.Generic;

using Grasshopper.Kernel;

using Grasshopper.Kernel.Data;

using Grasshopper.Kernel.Types;

using Rhino.Geometry;

namespace cHRC
{
    public class SortCurves : GH_Component
    {
        /// <summary>
        /// Initializes a new instance of the MyComponent1 class.
        /// </summary>
        public SortCurves()
          : base("SortCurves", "SrtCrv",
              "Sorts and rebuilds multiple curves",
              "cHRC", "06 more")
		{
		}



		/// <summary>
		/// Registers all the input parameters for this component.
		/// </summary>
		protected override void RegisterInputParams(GH_Component.GH_InputParamManager pManager)
		{
			// Use the pManager object to register your input parameters.
			// You can often supply default values when creating parameters.
			// All parameters must have the correct access type. If you want 
			// to import lists or trees of values, modify the ParamAccess flag.


			/*
			pManager.AddPlaneParameter("Plane", "P", "Base plane for spiral", GH_ParamAccess.item, Plane.WorldYZ);
			pManager.AddNumberParameter("Inner Radius", "R0", "Inner radius for spiral", GH_ParamAccess.item, 1.0);
			pManager.AddNumberParameter("Outer Radius", "R1", "Outer radius for spiral", GH_ParamAccess.item, 10.0);
			pManager.AddIntegerParameter("Turns", "T", "Number of turns between radii", GH_ParamAccess.item, 10);
			*/


			/* ///notused??
			pManager.AddPointParameter("Point1", "Pt1", "Base Point 1", GH_ParamAccess.item);

			pManager.AddPointParameter("Point2", "Pt2", "Base Point 2", GH_ParamAccess.item);

			*/

			/*

			pManager.AddPointParameter("Point1", "Pt1", "Base Point 1", GH_ParamAccess.item, Point3d.Origin);

			pManager.AddPointParameter("Point2", "Pt2", "Base Point 2", GH_ParamAccess.item, Point3d.Origin);
			*/


			pManager.AddCurveParameter("CurvesTr", "iCrvTr", "CurveTree", GH_ParamAccess.tree); // 6

			pManager.AddIntegerParameter("AutoManIter", "AMI", "Auto or manual Iteration 1 or 0", GH_ParamAccess.item, 1);

			pManager.AddIntegerParameter("Iterations", "It", "Iteration_Count", GH_ParamAccess.item, 4);

			pManager.AddNumberParameter("DivisionFactor", "DF", "DivisionFactor", GH_ParamAccess.item, 0.15);

			pManager.AddIntegerParameter("MinDivision", "MD", "Minimum Division Count", GH_ParamAccess.item, 3);

			pManager.AddIntegerParameter("IndexOneCurve", "IOC", "Index of one Curve / branch", GH_ParamAccess.item, 0);







			// If you want to change properties of certain parameters, 
			// you can use the pManager instance to access them by index:
			//pManager[0].Optional = true;
		}

		/// <summary>
		/// Registers all the output parameters for this component.
		/// </summary>
		protected override void RegisterOutputParams(GH_Component.GH_OutputParamManager pManager)
		{
			// Use the pManager object to register your output parameters.
			// Output parameters do not have default values, but they too must have the correct access type.

			/*
			pManager.AddCurveParameter("Spiral", "S", "Spiral curve", GH_ParamAccess.item);


			pManager.AddLineParameter("SuperLine222", "SL222", "SuperLine222", GH_ParamAccess.item);

			*/

			//not used
			//pManager.AddPointParameter("oPoints", "PtTr", "Points as Tree", GH_ParamAccess.tree);
			//pManager.AddPointParameter("oPointsOneCurve", "PtOne", "Points of One", GH_ParamAccess.list);



			pManager.AddPointParameter("oPoints", "PtTr", "Points as Tree", GH_ParamAccess.tree);

			pManager.AddPointParameter("oPointsOneCurve", "PtOne", "Points of One", GH_ParamAccess.list);








			// Sometimes you want to hide a specific parameter from the Rhino preview.
			// You can use the HideParameter() method as a quick way:
			//pManager.HideParameter(0);
		}

		/// <summary>
		/// This is the method that actually does the work.
		/// </summary>
		/// <param name="DA">The DA object can be used to retrieve data from input parameters and 
		/// to store data in output parameters.</param>
		/// 


		protected override void SolveInstance(IGH_DataAccess DA)
		{

			// First, we need to retrieve all data from the input parameters.
			// We'll start by declaring variables and assigning them starting values.


			/*
			Plane plane = Plane.WorldXY;

			double radius0 = 0.0;
			double radius1 = 0.0;
			int turns = 0;



			Point3d point1 = Point3d.Origin;
			Point3d point2 = Point3d.Origin;
			*/


			GH_Structure<GH_Curve> iCurves = new GH_Structure<GH_Curve>();

			int oAutoManIter = 1;

			int iIterations = 4;

			double iDivisionFactor = 0.15;

			int iMinDivision = 3;

			int iOnecurve = 0;





			// Then we need to access the input parameters individually. 
			// When data cannot be extracted from a parameter, we should abort this method.

			/*
			if (!DA.GetData(0, ref plane)) return;

			if (!DA.GetData(1, ref radius0)) return;
			if (!DA.GetData(2, ref radius1)) return;
			if (!DA.GetData(3, ref turns)) return;


			if (!DA.GetData(4, ref point1)) return;
			if (!DA.GetData(5, ref point2)) return;
			*/


			if (!DA.GetDataTree<GH_Curve>(0, out iCurves)) return;

			if (!DA.GetData(1, ref oAutoManIter)) return;

			if (!DA.GetData(2, ref iIterations)) return;

			if (!DA.GetData(3, ref iDivisionFactor)) return;

			if (!DA.GetData(4, ref iMinDivision)) return;

			if (!DA.GetData(5, ref iOnecurve)) return;











			/*

			// We should now validate the data and warn the user if invalid data is supplied.
			if (radius0 < 0.0)
			{
				AddRuntimeMessage(GH_RuntimeMessageLevel.Error, "Inner radius must be bigger than or equal to zero");
				return;
			}
			if (radius1 <= radius0)
			{
				AddRuntimeMessage(GH_RuntimeMessageLevel.Error, "Outer radius must be bigger than the inner radius");
				return;
			}
			if (turns <= 0)
			{
				AddRuntimeMessage(GH_RuntimeMessageLevel.Error, "Spiral turn count must be bigger than or equal to one");
				return;
			}

			*/



			// We're set to create the spiral now. To keep the size of the SolveInstance() method small, 
			// The actual functionality will be in a different method:




			//Curve spiral = CreateSpiral(plane, radius0, radius1, turns);

			//Line TheSuperLine222 = CreateLine(point1, point2);












			List<List<Curve>> myCurves = new List<List<Curve>>();  //Tree to list


			//int BranchCountCurves = iCurves.BranchCount;  /c#gh


			int BranchCountCurves = iCurves.Branches.Count;



			//for (int i = 0; i < iCurves.BranchCount; i++) //c#gh

			for (int i = 0; i < iCurves.Branches.Count; i++)
			{


				List<Curve> sublist = new List<Curve>();



				//int ListLenghtCurvesbranch = iCurves.Branch(i).Count;  //c#gh

				int ListLenghtCurvesbranch = iCurves.Branches[i].Count;

				for (int j = 0; j < ListLenghtCurvesbranch; j++)
				{
					//sublist.Add(iCurves.Branches(i)[j]);  //c#gh






					Curve rhinoCurve = null;

					GH_Convert.ToCurve(iCurves.Branches[i][j], ref rhinoCurve, 0);

					sublist.Add(rhinoCurve);




				}


				myCurves.Add(sublist);

			}




			List<List<Point3d>> mySuperPoints = new List<List<Point3d>>();   // Final output


			for (int i = 0; i < myCurves.Count; i++)                      // Main loop through all curve lists
			{




				List<List<Point3d>> myPoints = new List<List<Point3d>>();     // Curves to lists of Points: Each curve list gets sublists with sub division points on each curve




				for (int j = 0; j < myCurves[i].Count; j++)               // loop through curve lists to subdivide curves and call the sort funtion(OneSet)

				{
					List<Point3d> pts = new List<Point3d>();                // subdivision to points
					Point3d pt = new Point3d();

					double CurveLength = myCurves[i][j].GetLength();
					double PointCount = CurveLength * iDivisionFactor;

					double rounded = Math.Round(PointCount, 0);


					double rounded2 = new int();

					if (rounded < 3)              // minimal sub division point count...
					{
						rounded2 = iMinDivision;
					}

					else

					{
						rounded2 = rounded;
					}



					double spacing = 1.0 / rounded2;
					double t;

					for (int k = 0; k <= rounded2; k++)

					{
						t = k * spacing;
						pt = myCurves[i][j].PointAtNormalizedLength(t);
						pts.Add(pt);
					}

					myPoints.Add(pts);        //Add sub point lists to List of pointlists


				}





				mySuperPoints.Add(OneSet(myPoints, oAutoManIter, iIterations));   //Call Function to sort points and return one sorted list of points per initial curve list


			}







			Grasshopper.DataTree<Point3d> myFinalPointsTree = new Grasshopper.DataTree<Point3d>();        //ListofLists to Tree for the Output


			int BranchCount222 = mySuperPoints.Count;


			for (int i = 0; i < mySuperPoints.Count; i++)

			{

				int ListLenght333 = mySuperPoints[i].Count;

				for (int j = 0; j < ListLenght333; j++)

				{

					myFinalPointsTree.Add(mySuperPoints[i][j], new GH_Path(i));

					//myFinalPointsTree.Add(mySuperPoints[i][j], new GH_Path(i));
				}


			}








			/*

			oPoints = myFinalPointsTree;                        //Output

			oPointsOneCurve = mySuperPoints[iOnecurve];

			*/


















			// Finally assign the spiral to the output parameter.

			/*
			DA.SetData(0, spiral);

			DA.SetData(1, TheSuperLine222);
			*/


			DA.SetDataTree(0, myFinalPointsTree);

			DA.SetDataList(1, mySuperPoints[iOnecurve]);




		}

		/*
		private Curve CreateSpiral(Plane plane, double r0, double r1, Int32 turns)
		{
			Line l0 = new Line(plane.Origin + r0 * plane.XAxis, plane.Origin + r1 * plane.XAxis);
			Line l1 = new Line(plane.Origin - r0 * plane.XAxis, plane.Origin - r1 * plane.XAxis);

			Point3d[] p0;
			Point3d[] p1;

			l0.ToNurbsCurve().DivideByCount(turns, true, out p0);
			l1.ToNurbsCurve().DivideByCount(turns, true, out p1);

			PolyCurve spiral = new PolyCurve();

			for (int i = 0; i < p0.Length - 1; i++)
			{
				Arc arc0 = new Arc(p0[i], plane.YAxis, p1[i + 1]);
				Arc arc1 = new Arc(p1[i + 1], -plane.YAxis, p0[i + 1]);

				spiral.Append(arc0);
				spiral.Append(arc1);
			}

			return spiral;
		}


			*/


		/*
	private Line CreateLine(Point3d point1, Point3d point2)
	{
		Line myLine = new Line(point1, point2);

		return myLine;
	}

	*/





		public static List<Point3d> OneSet(List<List<Point3d>> iPoints, int oAutoManIter, int iIterations)        //Function 1 to Sort Points in Lists and return one sorted point list

		{


			/// This function loops through all inputed lists. The new  sorted lists get built by findinng the closest lists from itself (start /End points)
			//and subsequently adding them in the correct order
			//at the end or at the beginning of the new ordered list



			List<Point3d> sortedList = new List<Point3d>();  //Sorted out for Output Superlist ---   important ----





			for (int i = 0; i < iPoints[0].Count; i++) //       Adding the firs list as it is as start for the sorted list
			{
				sortedList.Add(iPoints[0][i]);
			}


			iPoints.RemoveAt(0);               //Remove Branch 0 from the input list to not add list double
											   //(Otherwise it would add always the same list because always the same lists would be the closest)



			int supercount = new int();         // limit per input to limit the iteration count (mainlky for debugging)

			if (oAutoManIter == 0)

			{
				supercount = iIterations;
			}
			else
			{
				supercount = iPoints.Count;
			}




			List<Point3d> allStartPoints = new List<Point3d>();
			List<Point3d> allEndPoints = new List<Point3d>();

			List<int> allCaseID = new List<int>();
			List<int> allDistID = new List<int>();


			for (int i = 0; i < supercount + 0; i++)

			{


				int ListlenghtSortedList = sortedList.Count;    //Lenght sorted list


				Point3d myStartPoint0 = new Point3d(sortedList[0]);
				Point3d myEndPoint0 = new Point3d(sortedList[ListlenghtSortedList - 1]);


				allStartPoints.Add(myStartPoint0);
				allEndPoints.Add(myEndPoint0);

				int CaseID = GetIdentifiers(iPoints, myStartPoint0, myEndPoint0)[0];     // Call functions for the case Identifieres:(should the closest list be added at the start or at the end and reversed or not??)
				int DistID = GetIdentifiers(iPoints, myStartPoint0, myEndPoint0)[1];    //  Call fubnction for the IIdentifier Index of the closest List

				allCaseID.Add(CaseID);
				allDistID.Add(DistID);


				int LenghtBranchAct = iPoints[DistID].Count;


				//Adding the closest list(DistID) according to the identifier numbers (CaseID) the points at the start or at the end, reversed or not to the sorted list
				// ...and remove the added lists from the input list!!!

				if (CaseID == 0)   //0  Start Start
				{

					List<Point3d> sortedListCopy = new List<Point3d>();

					for (int j = 0; j < ListlenghtSortedList; j++)
					{
						sortedListCopy.Add(sortedList[j]);
					}



					sortedList.Clear();



					for (int j = 0; j < LenghtBranchAct; j++)
					{
						sortedList.Add(iPoints[DistID][LenghtBranchAct - 1 - j]);
					}


					for (int j = 0; j < sortedListCopy.Count; j++)
					{
						sortedList.Add(sortedListCopy[j]);
					}


				}



				if (CaseID == 1) // 1   Start End
				{

					List<Point3d> sortedListCopy = new List<Point3d>();

					for (int j = 0; j < ListlenghtSortedList; j++)
					{
						sortedListCopy.Add(sortedList[j]);
					}



					sortedList.Clear();



					for (int j = 0; j < sortedListCopy.Count; j++)
					{
						sortedList.Add(sortedListCopy[j]);
					}


					for (int j = 0; j < LenghtBranchAct; j++)
					{
						sortedList.Add(iPoints[DistID][j]);
					}


				}




				if (CaseID == 2) // 2 End Start
				{


					List<Point3d> sortedListCopy = new List<Point3d>();

					for (int j = 0; j < ListlenghtSortedList; j++)
					{
						sortedListCopy.Add(sortedList[j]);
					}


					sortedList.Clear();


					for (int j = 0; j < LenghtBranchAct; j++)
					{
						sortedList.Add(iPoints[DistID][j]);
					}


					for (int j = 0; j < sortedListCopy.Count; j++)
					{
						sortedList.Add(sortedListCopy[j]);
					}


				}




				if (CaseID == 3)  // 2 End End
				{

					for (int j = 0; j < LenghtBranchAct; j++)

					{

						//LenghtBranchAct - 1 - j

						sortedList.Add(iPoints[DistID][LenghtBranchAct - 1 - j]);
					}

				}


				iPoints.RemoveAt(DistID + 0);

			}

			return sortedList;

		}









		// function to get the CaseID and the Dist ID to identify  the closest List from multiple lists to a check list
		//and analyze if the he closest lis should be added at the strart or the end of the sorted list, reversed or not

		public static List<int> GetIdentifiers(List<List<Point3d>> iPoints, Point3d myStartPoint, Point3d myEndPoint)
		{




			List<int> Identifiers = new List<int>();


			//  List<int> ListLenghts = new List<int>();

			// List<Point3d> sortedList = new List<Point3d>();


			List<double> ShortestDists = new List<double>();

			List<int> Identifier = new List<int>();     // for return output



			for (int i = 0; i < iPoints.Count; i++)     //loop through point lists

			{


				int ListLenght = iPoints[i].Count;

				Point3d iStartP = iPoints[i][0];          // Start and end points of the checked lists


				Point3d EndP = iPoints[i][ListLenght - 1];


				List<double> DistsSorted = new List<double>();

				List<double> DistsNotSorted = new List<double>();


				//measuring Distances from the start and and Point of the checking list (input my Start and my Endpoint)to all start and end points from the Lists to check.

				double DistStartStart = iStartP.DistanceTo(myStartPoint); // 0  Start Start
				DistsSorted.Add(DistStartStart);
				DistsNotSorted.Add(DistStartStart);

				double DistStartEnd = iStartP.DistanceTo(myEndPoint);  // 1   Start End
				DistsSorted.Add(DistStartEnd);
				DistsNotSorted.Add(DistStartEnd);

				double DistEndStart = EndP.DistanceTo(myStartPoint);    // 2 End Start
				DistsSorted.Add(DistEndStart);
				DistsNotSorted.Add(DistEndStart);


				double DistEndEnd = EndP.DistanceTo(myEndPoint);     // 3 End End
				DistsSorted.Add(DistEndEnd);
				DistsNotSorted.Add(DistEndEnd);

				DistsSorted.Sort();  // Sort the distances to get the shortest Distance... probably stupid to do like that but it work
				ShortestDists.Add(DistsSorted[0]);



				for (int j = 0; j < DistsNotSorted.Count; j++)
				{
					if (DistsNotSorted[j] == DistsSorted[0])
					{
						Identifier.Add(j);               // Add Case ID to a list
					}
				}

			}




			double smallestOneNum = 10000000000000000;

			int superOneIdentifier = 1000000;

			int DistanceIdentifier = 10000000;


			for (int i = 0; i < ShortestDists.Count; i++)
			{

				double tempNum = ShortestDists[i];

				if (tempNum > smallestOneNum) continue;
				{
					smallestOneNum = tempNum;

					superOneIdentifier = Identifier[i];

					DistanceIdentifier = i;

				}

			}


			// Add the identifier of the closest list (DistID) and its Case Identifier (CaseID) to an output/ return list

			Identifiers.Add(superOneIdentifier);
			Identifiers.Add(DistanceIdentifier);


			return Identifiers;


		}
















		/*


		private Line CreateSuperLine(Point3d point1, Point3d point2)
		{
			Line 14 = new Line(point1, point2);
	
		

			return 14;
		}

	*/















		/// <summary>
		/// The Exposure property controls where in the panel a component icon 
		/// will appear. There are seven possible locations (primary to septenary), 
		/// each of which can be combined with the GH_Exposure.obscure flag, which 
		/// ensures the component will only be visible on panel dropdowns.
		/// </summary>
		public override GH_Exposure Exposure
		{
			get { return GH_Exposure.primary; }
		}

		/// <summary>
		/// Provides an Icon for every component that will be visible in the User Interface.
		/// Icons need to be 24x24 pixels.
		/// </summary>
		protected override System.Drawing.Bitmap Icon
		{
			get
			{
				// You can add image files to your project resources and access them like this:
				//return Resources.IconForThisComponent;
				//return null;

				return Resource1.Sort_curves;
			}
		}
		/// <summary>
		/// Gets the unique ID for this component. Do not change this ID after release.
		/// </summary>
		public override Guid ComponentGuid
        {
            get { return new Guid("fb489f4e-5373-4a09-8b7b-4e8757e5792e"); }
        }
    }
}