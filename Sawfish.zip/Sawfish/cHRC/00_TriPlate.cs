﻿using System;
using System.Collections.Generic;

using Grasshopper.Kernel;
using Rhino.Geometry;



using Grasshopper.Kernel.Data;




namespace cHRC
{

   // public class 00_TriPlate : GH_Component

    public class aa_Component_TriPlate : GH_Component
    {
        /// <summary>
        /// Initializes a new instance of the MyComponent1 class.
        /// </summary>
        public aa_Component_TriPlate()
          : base("00_Triangular Plates", "TriPlate",
              "Creates a solid fabricable offset of a triangular polyline by keeping all sides planar",
              "cHRC", "02 Offset Geometry")
        {
        }

        /// <summary>
        /// Registers all the input parameters for this component.
        /// </summary>
        protected override void RegisterInputParams(GH_Component.GH_InputParamManager pManager)
        {







            pManager.AddCurveParameter("Polylines", "Pl", "Polyline Input for the offset, as list", GH_ParamAccess.list); //00

        //    pManager.AddPointParameter("PolylineCenter", "PolylineCenter", "Centers of the Inputpolyline, as list", GH_ParamAccess.list); //01



            pManager.AddNumberParameter("Thickness", "T", "The material thickness, structural height in mm", GH_ParamAccess.item, 27);  //05


            pManager.AddNumberParameter("NodeBackTop", "BT", "Offset Distance in mm to make the upper top node outcut if Top open/close is on Open (0)", GH_ParamAccess.item, 0.0);  //07


            pManager.AddNumberParameter("NodeBackLow", "BL", "Distance in mm to make the lower node outcut", GH_ParamAccess.item, 60);  //06

     

       //     pManager.AddIntegerParameter("OpenCloseTop", "OpenCloseTop", "0 for an open node top, 1 for a closed node top", GH_ParamAccess.item, 120);  //08


            pManager.AddBooleanParameter("ForcePlanarity", "FP", "When nodes are open at the top the node adjacant side is not necessarily planar. If True planarity is enforced. Planar Sides can be cut by a circular saw as tool, non planarsides, possibly providing a higher node aesthetic,  have to be milled", GH_ParamAccess.item, true);  //09



            pManager.AddBooleanParameter("CalcLines", "L", "If true, calculates the plates  side  curves, can be  as input for the ClosedBrep component)  ", GH_ParamAccess.item, true);  //10


            pManager.AddBooleanParameter("CalcMesh", "M", "If true, calculates am mesh of each triangular plate)  ", GH_ParamAccess.item, false);  //11




            //   pManager.AddBooleanParameter("Manual iteration", "Manual iteration", "True to limit the iterations", GH_ParamAccess.item, false);  //02



            pManager.AddNumberParameter("CheckDist", "CD", "The Distance from the polygon edges middlepoint to the neighbourpolygon in which the neighbour polygon is considered a neighbour (not a naked edge)", GH_ParamAccess.item, 0.01); //03

            pManager.AddIntegerParameter("StartIteration", "Si", "Start Index if larger than -1", GH_ParamAccess.item, -1); //04


            pManager.AddIntegerParameter("MaxIterations", "Mi", "Maximal Iteration Count if larger than -1", GH_ParamAccess.item, -1); //03

        






        }

        /// <summary>
        /// Registers all the output parameters for this component.
        /// </summary>
        protected override void RegisterOutputParams(GH_Component.GH_OutputParamManager pManager)
        {



      

            pManager.AddCurveParameter("TopPolyline", "TPl", "The top polyline possibly with node outcut", GH_ParamAccess.list);  //00


            pManager.AddCurveParameter("Lowerpolyline", "LPl", "The lower polyline  with node outcut", GH_ParamAccess.list);  //01


            pManager.AddCurveParameter("SideCurves", "SC", "SideCurves as Tree  no double curves", GH_ParamAccess.tree); //05


            //  pManager.AddCurveParameter("SideCurves", "SideCurves", "The curves (line-like) connecting the top and the lower polyline",  GH_ParamAccess.list);  //02


            pManager.AddMeshParameter("Meshes", "M", "A  List of meshes for each plate compoinent if ClacMesh input is true", GH_ParamAccess.list);  //04




         //  pManager.AddCurveParameter("SideCurvesTreeC", "SideCurvesTreeC", "SideCurves as Tree open: no double lines", GH_ParamAccess.tree); //06




        }



        /// <summary>
        /// This is the method that actually does the work.
        /// </summary>
        /// <param name="DA">The DA object is used to retrieve from inputs and store in outputs.</param>
        protected override void SolveInstance(IGH_DataAccess DA)

        {





            List<Curve> iCurves = new List<Curve>();   //00


        //    List<Point3d> iPcenters = new List<Point3d>();   //01




            double  oHeight = 27; //05

            double oNodeBackOK = 0.0; //07


            double oNodeBackUK = 120; //06

           



      //      int oTopCLosedOpen = 1;  // 08


            bool oForcePlanarity = true; //09


            bool oCalcLines = true; //10

            bool oCalcMesh = true; //11



            //      bool oManItOn = false;  //02

            double iCheckDist = 0.01;


            int oManStIndex = -1; //04

            int oManIt = -1; //03

           





            //  if (!DA.GetDataTree<GH_Curve>(0, out iCurves0)) return;   //worked in crazy ways tree structure




            if (!DA.GetDataList<Curve>(0, iCurves)) { return; } //  0


     //       if (!DA.GetDataList<Point3d>(1, iPcenters)) { return; } //  1





            if (!DA.GetData(1, ref oHeight)) return; //05




            if (!DA.GetData(2, ref oNodeBackOK)) return;   //07


            if (!DA.GetData(3, ref oNodeBackUK)) return;   //06





       //     if (!DA.GetData(4, ref oTopCLosedOpen)) return;  //08



            if (!DA.GetData(4, ref oForcePlanarity)) return;  //09



            if (!DA.GetData(5, ref oCalcLines)) return;  //10


            if (!DA.GetData(6, ref oCalcMesh)) return;  //11



            if (!DA.GetData(7, ref iCheckDist)) return;  //11



            if (!DA.GetData(8, ref oManStIndex)) return; //04


            if (!DA.GetData(9, ref oManIt)) return;  //03





            //  if (!DA.GetData(1, ref oManItOn)) return;  //02







            //Expiring:


            var myDay = System.DateTime.Now.Day;

            var myMonth = System.DateTime.Now.Month;

            var myYear = System.DateTime.Now.Year;

            /*
            A = myDay;

            B = myMonth;

            C = myYear;
            */

            //ExpiringTime

            int check = 1;

            int expYear = 999999999;

            int expMonth = 03;

            int expDay = 27;



            if (myYear > expYear)
            {
                check = 0;
            }

            if (myYear == expYear)
            {
                if (myMonth > expMonth)
                {
                    check = 0;
                }

                if (myMonth == expMonth)
                {

                    if (myDay > expDay)
                    {
                        check = 0;
                    }

                }

            }



            //  E = check;




























            // Enable to define the iteration start and the iteration count without being out of range all the time






            int myStartIndex = 0;

            int iteration = 0;



            if (oManStIndex == -1 & oManIt == -1)

            {
                myStartIndex = 0;

                iteration = iCurves.Count;

                //  iteration = 2;
            }





            if (oManStIndex > -1 & oManIt == -1)

            {

                if (oManStIndex < iCurves.Count)

                {

                    myStartIndex = oManStIndex;

                    iteration = iCurves.Count - oManStIndex;

                }


                else

                {

                    myStartIndex = iCurves.Count - 1;

                    iteration = 1;


                }



            }





            if (oManStIndex == -1 & oManIt > -1)

            {


                if (oManIt < iCurves.Count)

                {
                    myStartIndex = 0;

                    iteration = oManIt;

                }

                else

                {

                    myStartIndex = 0;

                    iteration = iCurves.Count;
                }


            }





            if (oManStIndex > -1 & oManIt > -1)

            {


                if (oManStIndex < iCurves.Count)

                {
                    myStartIndex = oManStIndex;


                    if (oManIt + oManStIndex < iCurves.Count)

                    {
                        iteration = oManIt;
                    }


                    else

                    {
                        iteration = iCurves.Count - oManStIndex;
                    }



                }



                else

                {
                    myStartIndex = iCurves.Count - 1;

                    iteration = 1;

                }



            }


            int oTopCLosedOpen = 1;


            if (oNodeBackOK == 0.0)

            {

                oTopCLosedOpen = 1;

            }

            else
            {
                oTopCLosedOpen = 0;
            }









            /*

            int iteration;

            int StartIndex;

            // int oManStIndex = 0;

            if (oManItOn == true)

            {
                iteration = oManIt;

                StartIndex = oManStIndex;
            }

            else

            {
                iteration = iCurves.Count;

                StartIndex = 0;
            }


            */




            List<Polyline> AllBeamPolylinesUK = new List<Polyline>();

            List<Polyline> AllBeamPolylinesOK = new List<Polyline>();



            List<Point3d> testPointsOriginal = new List<Point3d>();


            List<NurbsCurve> allConnectLines = new List<NurbsCurve>();





            List<Mesh> allMeshes = new List<Mesh>();










            List<Vector3d> myNormals = new List<Vector3d>();



            //not used List input from grasshopper  Polyline centers is faster
            // List<Point3d> mySuperCenters = new List<Point3d>();






            List<Polyline> Icurves22 = new List<Polyline>();





            List<List<NurbsCurve>> myListListCurves = new List<List<NurbsCurve>>();




            List<Point3d> myPolyCentrs = new List<Point3d>();








            //Loop through all input polylines to get all neighbour normal vectors and neighbour polygon centers which are necessary to offset the plate correctly  (Edge offset in the bisecting angle to the neighbour)

            if (check != 0)  //Expiring if

            {


                for (int i = 0; i < iCurves.Count; i++)



                {




                    Polyline iPolyL3;  //polyline to work with


                    // iCurves[i + oManStIndex].TryGetPolyline(out iPolyL3);


                    iCurves[i].TryGetPolyline(out iPolyL3); //visual studio work around




                    myPolyCentrs.Add(PolylineAverage(iPolyL3));  //the polyline center point





                    //Polyline iPolyL3 = iCurves[i].ToPolyline(); 


                    Vector3d v4 = iPolyL3[0] - iPolyL3[1];

                    //v4.Unitize();

                    Vector3d v5 = iPolyL3[0] - iPolyL3[2];

                    //v5.Unitize();


                    Vector3d myNormal = Vector3d.CrossProduct(v4, v5);

                    myNormal.Unitize();

                    myNormals.Add(myNormal);






                    Polyline myPolyL;

                    // iCurves[i + oManStIndex].TryGetPolyline(out myPolyL);


                    iCurves[i].TryGetPolyline(out myPolyL);


                    Icurves22.Add(myPolyL);



                }




            }//Expiring






























            // main loop

         


                for (int i = 0; i < iteration; i++)
            {

                /*
                                Polyline iPolyL4;


                                iCurves[i + oManStIndex].TryGetPolyline(out iPolyL4);







                                // Polyline iPolyL0 = iCurves[i + StartIndex];


                                Polyline iPolyL0 = iPolyL4;


                                */



                Polyline iPolyL0;  //polyline to work with


                //  iCurves[i ].TryGetPolyline(out iPolyL0);

                //  iCurves[i + oManStIndex].TryGetPolyline(out iPolyL0);  myStartIndex


                iCurves[i + myStartIndex].TryGetPolyline(out iPolyL0); //necessary in visual studio 







              //  List<Point3d> myUKpoints = UKpointOffset(iPolyL0, oHeight, iPcenters[i + StartIndex], Icurves22, iPcenters, myNormals, oNodeBackUK);



                //Get the UK points of the platevby a a function see functions

                List<Point3d> myUKpoints = UKpointOffset(iPolyL0, oHeight, myPolyCentrs[i + myStartIndex], Icurves22, myPolyCentrs, myNormals, oNodeBackUK, iCheckDist);








                List<List<Point3d>> myOKpoints1 = new List<List<Point3d>>();






                if (oForcePlanarity)   //At the node one side is not necessarily planar. With this Function the fourth point which is out of plane is moved back to the plane (in the corret direction)


                {
                    myOKpoints1.Add(OKpointOffsetPlanar(iPolyL0, myUKpoints, oNodeBackOK)); //Planar
                }


                else

                {

                    myOKpoints1.Add(OKpointOffset(iPolyL0, oNodeBackOK));   //original non planar

                }





                List<Point3d> myOKpoints = myOKpoints1[0];








                // List<Point3d> myOKpoints = OKpointOffsetPlanar(iPolyL0, myUKpoints, oNodeBackOK); //Planar


                // List<Point3d> myOKpoints = OKpointOffset(iPolyL0, oNodeBackOK);   //original








                /*




                for (int j = 0; j < myOKpoints.Count; j++)
                {
                testPointsOriginal.Add(myOKpoints[j]);
                }

                */


                /*

                for (int j = 0; j < myUKpoints.Count; j++)
                {
                testPoints.Add(myUKpoints[j]);
                }
                */

                myUKpoints.Add(myUKpoints[0]);

                Polyline UKpolyLine1 = new Polyline(myUKpoints);


                AllBeamPolylinesUK.Add(UKpolyLine1);




                myOKpoints.Add(myOKpoints[0]);



                //Polyline OKpolyLine1 = new Polyline(myOKpoints);





                //Choose between an open and a closed node: open nodes cause  a quad surface at the node which is not automatically planar. for this sitation is the Force Planarity function


                if (oTopCLosedOpen == 1)


                {

                    AllBeamPolylinesOK.Add(iPolyL0);

                }

                else

                {

                    Polyline OKpolyLine1 = new Polyline(myOKpoints);

                    AllBeamPolylinesOK.Add(OKpolyLine1);
                }











                // create the side lines



                if (oCalcLines)


                {



                    if (oTopCLosedOpen == 1)


                    {


                        List<NurbsCurve> Connectlines = new List<NurbsCurve>();

                        



                        Line l1 = new Line(myUKpoints[0], iPolyL0[0]);

                        NurbsCurve myNurb1 = l1.ToNurbsCurve();

                        Connectlines.Add(myNurb1);










                        Line l2 = new Line(myUKpoints[1], iPolyL0[1]);

                        NurbsCurve myNurb2 = l2.ToNurbsCurve();

                        Connectlines.Add(myNurb2);



                        Line l3 = new Line(myUKpoints[2], iPolyL0[1]);

                        NurbsCurve myNurb3 = l3.ToNurbsCurve();

                        Connectlines.Add(myNurb3);

                     






                        Line l4 = new Line(myUKpoints[3], iPolyL0[2]);

                        NurbsCurve myNurb4 = l4.ToNurbsCurve();

                        Connectlines.Add(myNurb4);


                       



                        Line l5 = new Line(myUKpoints[4], iPolyL0[2]);

                        NurbsCurve myNurb5 = l5.ToNurbsCurve();

                        Connectlines.Add(myNurb5);

          



                        Line l6 = new Line(myUKpoints[5], iPolyL0[0]);

                        NurbsCurve myNurb6 = l6.ToNurbsCurve();

                        Connectlines.Add(myNurb6);

                  




                        Line l7 = new Line(myUKpoints[0], iPolyL0[0]);

                        NurbsCurve myNurb7 = l7.ToNurbsCurve();

                        Connectlines.Add(myNurb7);

             




                        for (int j = 0; j < Connectlines.Count; j++)
                        {
                            allConnectLines.Add(Connectlines[j]);
                        }

                        myListListCurves.Add(Connectlines);







                    }











                    else


                    {     // create the side lines


                        List<NurbsCurve> Connectlines2 = new List<NurbsCurve>();



                        Line l1 = new Line(myUKpoints[0], myOKpoints[0]);

                        NurbsCurve myNurb1 = l1.ToNurbsCurve();

                        Connectlines2.Add(myNurb1);








                        Line l2 = new Line(myUKpoints[1], myOKpoints[1]);

                        NurbsCurve myNurb2 = l2.ToNurbsCurve();

                        Connectlines2.Add(myNurb2);



                        Line l3 = new Line(myUKpoints[2], myOKpoints[2]);

                        NurbsCurve myNurb3 = l3.ToNurbsCurve();

                        Connectlines2.Add(myNurb3);






                        Line l4 = new Line(myUKpoints[3], myOKpoints[3]);

                        NurbsCurve myNurb4 = l4.ToNurbsCurve();

                        Connectlines2.Add(myNurb4);




                        Line l5 = new Line(myUKpoints[4], myOKpoints[4]);

                        NurbsCurve myNurb5 = l5.ToNurbsCurve();

                        Connectlines2.Add(myNurb5);


                        Line l6 = new Line(myUKpoints[5], myOKpoints[5]);

                        NurbsCurve myNurb6 = l6.ToNurbsCurve();

                        Connectlines2.Add(myNurb6);


                        Line l7 = new Line(myUKpoints[0], myOKpoints[0]);

                        NurbsCurve myNurb7 = l7.ToNurbsCurve();



                        Connectlines2.Add(myNurb7);


                        for (int j = 0; j < Connectlines2.Count; j++)
                        {
                            allConnectLines.Add(Connectlines2[j]);
                        }


                        myListListCurves.Add(Connectlines2);




                    }



                }






                //Create a mesh representation of the plate

                if (oCalcMesh)

                {



                    if (oTopCLosedOpen == 1)

                    {

                        Mesh myMesh = new Mesh();


                        for (int j = 0; j < iPolyL0.Count - 1; j++)
                        {
                            myMesh.Vertices.Add(iPolyL0[j]);

                        }




                        for (int j = 0; j < myUKpoints.Count - 1; j++)
                        {
                            myMesh.Vertices.Add(myUKpoints[j]);

                        }




                        //  myMesh.Faces.AddFace(0, 1, 2);




                        myMesh.Faces.AddFace(iPolyL0.Count - 1 + 0, iPolyL0.Count - 1 + 1, iPolyL0.Count - 1 + 2, iPolyL0.Count - 1 + 3);

                        myMesh.Faces.AddFace(iPolyL0.Count - 1 + 0, iPolyL0.Count - 1 + 3, iPolyL0.Count - 1 + 4, iPolyL0.Count - 1 + 5);

                        myMesh.Faces.AddFace(0, 1, 2);



                        /*

                         for (int j = 0; j < Connectlines.Count; j++)
                         {
                             myUKpoints.Count
                         }
                    */


                        myMesh.Faces.AddFace(iPolyL0.Count - 1 + 0, iPolyL0.Count - 1 + 1, 1, 0);

                        myMesh.Faces.AddFace(iPolyL0.Count - 1 + 1, iPolyL0.Count - 1 + 2, 1);

                        myMesh.Faces.AddFace(iPolyL0.Count - 1 + 2, iPolyL0.Count - 1 + 3, 2, 1);

                        myMesh.Faces.AddFace(iPolyL0.Count - 1 + 3, iPolyL0.Count - 1 + 4, 2);

                        myMesh.Faces.AddFace(iPolyL0.Count - 1 + 4, iPolyL0.Count - 1 + 5, 0, 2);

                        myMesh.Faces.AddFace(iPolyL0.Count - 1 + 0, iPolyL0.Count - 1 + 5, 0); //here



                        myMesh.Normals.ComputeNormals();


                        myMesh.UnifyNormals();


                        myMesh.Normals.ComputeNormals();






                        allMeshes.Add(myMesh);



                    }












                    else

                    {

                        Mesh myMesh2 = new Mesh();


                        for (int j = 0; j < myOKpoints.Count - 1; j++)
                        {
                            myMesh2.Vertices.Add(myOKpoints[j]);

                        }




                        for (int j = 0; j < myUKpoints.Count - 1; j++)
                        {
                            myMesh2.Vertices.Add(myUKpoints[j]);

                        }




                        myMesh2.Faces.AddFace(0, 1, 2, 3);

                        myMesh2.Faces.AddFace(3, 4, 5, 0);


                        myMesh2.Faces.AddFace(myOKpoints.Count - 1 + 0, myOKpoints.Count - 1 + 1, myOKpoints.Count - 1 + 2, myOKpoints.Count - 1 + 3);

                        myMesh2.Faces.AddFace(myOKpoints.Count - 1 + 3, myOKpoints.Count - 1 + 4, myOKpoints.Count - 1 + 5, myOKpoints.Count - 1 + 0);




                        for (int j = 0; j < myOKpoints.Count - 2; j++)
                        {

                            myMesh2.Faces.AddFace(myOKpoints.Count - 1 + j, myOKpoints.Count - 1 + j + 1, j + 1, j);

                        }


                        //myMesh2.Faces.AddFace(0, 5, 11, 6);

                        myMesh2.Faces.AddFace(0, myOKpoints.Count - 2, myUKpoints.Count + myOKpoints.Count - 3, myOKpoints.Count - 1);



                        myMesh2.Normals.ComputeNormals();


                        myMesh2.UnifyNormals();


                        myMesh2.Normals.ComputeNormals();






                        allMeshes.Add(myMesh2);



                    }




                }




            }









            // List < Point3d > myUKpoints222 = UKpointOffset(iCurves[0], oHeight, iPcenters[0 + StartIndex], iCurves, iPcenters, myNormals, oNodeBackUK);





            // int myInt = OKpointOffsetPlanar(iCurves[0], myUKpoints222, 20.0);


            // List<Plane> mySuperTestpoints = OKpointOffsetPlanar(iCurves[0], myUKpoints222, oNodeBackOK);

            //   List<Point3d> mySuperTestpoints = OKpointOffsetPlanar(iCurves[0], myUKpoints222, oNodeBackOK);





            // Print(myInt.ToString());









            /*
            oBeamPolylinesUK = AllBeamPolylinesUK;

            oBeamPolylinesOK = AllBeamPolylinesOK;

            //oTestP = testPoints;




            oAllConnectlinesTop = allConnectLines;




            oAllMeshes = allMeshes;


            // oTestPoints = mySuperTestpoints;



            //  oTestPointsOriginal = testPointsOriginal;

    */















            
             
             // myListListCurves

            /*


            Grasshopper.DataTree<Curve> myFinalCurvesTree = new Grasshopper.DataTree<Curve>();        //ListofLists to Tree for the Output


            int BranchCount222 = myListListCurves.Count;


            for (int i = 0; i < myListListCurves.Count; i++)

            {

                int ListLenght333 = myListListCurves[i].Count;

                for (int j = 0; j < ListLenght333; j++)

                {

                    myFinalCurvesTree.Add(myListListCurves[i][j], new GH_Path(i));

                    //myFinalPointsTree.Add(mySuperPoints[i][j], new GH_Path(i));
                }


            }


    */


            

            Grasshopper.DataTree<Curve> myFinalCurvesTreeMinus1 = new Grasshopper.DataTree<Curve>();        //ListofLists to Tree for the Output


          //  int BranchCount222 = myListListCurves.Count;


            for (int i = 0; i < myListListCurves.Count; i++)

            {

                int ListLenght333 = myListListCurves[i].Count -1 ;

                for (int j = 0; j < ListLenght333; j++)

                {

                    myFinalCurvesTreeMinus1.Add(myListListCurves[i][j], new GH_Path(i));

                    //myFinalPointsTree.Add(mySuperPoints[i][j], new GH_Path(i));
                }


            }







    






            DA.SetDataList(0, AllBeamPolylinesOK);

            DA.SetDataList(1, AllBeamPolylinesUK);

            DA.SetDataTree(2, myFinalCurvesTreeMinus1);


            //DA.SetDataList(2, allConnectLines);

            DA.SetDataList(3, allMeshes);

         
          // DA.SetDataTree(5, myFinalCurvesTree);


















        }







        public static Point3d PolylineAverage(Polyline iPolyL)     //A Function to get the center of a closed polyline
        {

            Point3d PCenterT2 = new Point3d(0, 0, 0);


            for (int i = 0; i < iPolyL.Count - 1; i++)

            {
                PCenterT2 = PCenterT2 + iPolyL[i];
            }

            Point3d PCenter3 = PCenterT2 / (iPolyL.Count - 1);


            return PCenter3;
        }







        //for open nodes: move the top polyline edge endpoints towards the polyline edge middle point in th ecorrect distance to not create an non planar side




        public static List<Point3d> OKpointOffsetPlanar(Polyline iPolyL, List<Point3d> UKpointList, double nodeBack)
        {




            List<List<Point3d>> ListListp3d = new List<List<Point3d>>();   //This


            for (int i = 0; i < iPolyL.Count - 1; i++)

            {

                List<Point3d> PointCouple = new List<Point3d>();


                PointCouple.Add(iPolyL[i]);

                PointCouple.Add(iPolyL[i]);

                ListListp3d.Add(PointCouple);

            }













            List<List<Point3d>> ListListp3dUK = new List<List<Point3d>>();   //This


            for (int i = 0; i < UKpointList.Count - 1; i++)

            {






                if (i % 2 == 0)

                {



                    if (i == 0)

                    {


                        List<Point3d> PointCoupleUK = new List<Point3d>();


                        PointCoupleUK.Add(UKpointList[i]);

                        PointCoupleUK.Add(UKpointList[UKpointList.Count - 1]);

                        ListListp3dUK.Add(PointCoupleUK);


                    }



                    else

                    {

                        List<Point3d> PointCoupleUK = new List<Point3d>();


                        PointCoupleUK.Add(UKpointList[i]);

                        PointCoupleUK.Add(UKpointList[i - 1]);

                        ListListp3dUK.Add(PointCoupleUK);


                    }




                }








            }














            List<Point3d> BackOK22 = new List<Point3d>();



            for (int i = 0; i < iPolyL.Count - 1; i++)

            {

                Vector3d v1 = iPolyL[i] - iPolyL[i + 1];

                v1.Unitize();


                Point3d NodeBack2 = iPolyL[i] + v1 * -1 * nodeBack;

                Point3d NodeBack3 = iPolyL[i + 1] + v1 * nodeBack;



                BackOK22.Add(NodeBack2);

                BackOK22.Add(NodeBack3);

            }








            List<List<Point3d>> ListListp3dOKback = new List<List<Point3d>>();


            for (int i = 0; i < BackOK22.Count - 1; i++)

            {

                if (i % 2 == 0)

                {

                    if (i == 0)

                    {


                        List<Point3d> PointCoupleOKback = new List<Point3d>();


                        PointCoupleOKback.Add(BackOK22[i]);

                        PointCoupleOKback.Add(BackOK22[BackOK22.Count - 1]);

                        ListListp3dOKback.Add(PointCoupleOKback);


                    }


                    else

                    {


                        List<Point3d> PointCoupleOKback = new List<Point3d>();


                        PointCoupleOKback.Add(BackOK22[i]);

                        PointCoupleOKback.Add(BackOK22[i - 1]);

                        ListListp3dOKback.Add(PointCoupleOKback);


                    }


                }







            }












            List<Point3d> FinalOKMPpoints = new List<Point3d>();


            List<Point3d> FinalOKpoints = new List<Point3d>();


            List<Plane> myPlanes = new List<Plane>();






            for (int i = 0; i < ListListp3d.Count; i++)

            {



                Point3d OKp0 = ListListp3d[i][0];

                Point3d OKp1 = ListListp3d[i][1];



                Point3d OKp0back = ListListp3dOKback[i][0];

                Point3d OKp1back = ListListp3dOKback[i][1];



                Point3d UKp0 = ListListp3dUK[i][0];

                Point3d UKp1 = ListListp3dUK[i][1];



                Vector3d v7 = OKp0back - OKp1back;

                Point3d mp7OKback = OKp0back + v7 * -0.5;


                FinalOKMPpoints.Add(mp7OKback);


                Plane mySuperplane = new Plane(mp7OKback, mp7OKback - UKp1, mp7OKback - UKp0);


                myPlanes.Add(mySuperplane);




                Vector3d v00 = OKp0back - OKp0;

                Vector3d v11 = OKp1back - OKp1;


                Point3d LineP0 = OKp1 + v00 * 2;

                Point3d LineP1 = OKp1 + v11 * 2;


                Line L0 = new Line(OKp0, LineP0);

                Line L1 = new Line(OKp1, LineP1);






                double t;

                Rhino.Geometry.Intersect.Intersection.LinePlane(L0, mySuperplane, out t);


                Point3d intPoint0 = L0.PointAt(t);









                double t1;

                Rhino.Geometry.Intersect.Intersection.LinePlane(L1, mySuperplane, out t1);


                Point3d intPoint1 = L1.PointAt(t1);



                FinalOKpoints.Add(intPoint1);

                FinalOKpoints.Add(intPoint0);




                //var intesectsPos = Rhino.Geometry.Intersect.Intersection.CurveCurve(testLinePos.ToNurbsCurve(), iPolyL.ToNurbsCurve(), offIntersectTol, 0.0);




            }





            // return BackOK22.Count;
            //return myPlanes;





            List<Point3d> SuperFinalLastOKPoints = new List<Point3d>();






            for (int i = 0; i < FinalOKpoints.Count - 1; i++)

            {

                SuperFinalLastOKPoints.Add(FinalOKpoints[i + 1]);

            }


            SuperFinalLastOKPoints.Add(FinalOKpoints[0]);




            return SuperFinalLastOKPoints;


        }













        // NON PLANAR open the node in causing a non planar side at the node

        public static List<Point3d> OKpointOffset(Polyline iPolyL, double nodeBack)
        {


            List<Point3d> BackOK = new List<Point3d>();

            // List<Point3d> test3 = new List<Point3d>();



            for (int i = 0; i < iPolyL.Count - 1; i++)

            {

                Vector3d v1 = iPolyL[i] - iPolyL[i + 1];

                v1.Unitize();


                Point3d NodeBack2 = iPolyL[i] + v1 * -1 * nodeBack;

                Point3d NodeBack3 = iPolyL[i + 1] + v1 * nodeBack;



                BackOK.Add(NodeBack2);

                BackOK.Add(NodeBack3);

            }


            return BackOK;

        }




















        // A Function to offset the plate  top polyline points

        // The endpoints of the edges are moved in the bisecting vector of the adjacant polyline normal vectors. To get the correct and uniform material Thickness offset Distance is calculated with a math cosinus function 
        //in dependence of the material thickness.
        //If an edge is naked and therte is no neighbour polyline,
        //the edges Endpoints are moved in the polylines normal vector: Distance: Matetrial Thickness





        public static List<Point3d> UKpointOffset(Polyline iPolyL, double height, Point3d myPcenter, List<Polyline> allMyPolylines, List<Point3d> allmyPcenters, List<Vector3d> superNormals, double nodeBack, double myCheckDist)
        {


            List<Point3d> offsetsUK = new List<Point3d>();

            List<Point3d> test2 = new List<Point3d>();

            //iPolyL.Count - 1

            for (int i = 0; i < iPolyL.Count - 1; i++)

            {


                Vector3d v1 = iPolyL[i] - iPolyL[i + 1];

                Point3d mp0 = iPolyL[i] + v1 * -0.5;

                //test2.Add(mp0);


                // List<Polyline> myNeighbours = new List<Polyline>();

                List<Point3d> myNeighbourCenterPoints = new List<Point3d>();

                List<Vector3d> myNeighbourVectors = new List<Vector3d>();




                for (int j = 0; j < allMyPolylines.Count; j++)
                {

                    Polyline myPl = allMyPolylines[j];

                    Point3d myCP = myPl.ClosestPoint(mp0);

                    double Distance = mp0.DistanceTo(myCP);


                    if (Distance < myCheckDist)
                    {
                        //myNeighbours.Add(allMyPolylines[j]);

                        myNeighbourCenterPoints.Add(allmyPcenters[j]);

                        myNeighbourVectors.Add(superNormals[j]);
                    }

                }




                if (myNeighbourCenterPoints.Count < 2)

                {
                    Vector3d moveVec = Vector3d.CrossProduct(v1, myNeighbourCenterPoints[0] - iPolyL[i]);

                    moveVec.Unitize();

                    Point3d myUKpoint0 = iPolyL[i] + moveVec * height;

                    Point3d myUKpoint1 = iPolyL[i + 1] + moveVec * height;





                    v1.Unitize();


                    Point3d NodeBack0 = myUKpoint0 + v1 * -1 * nodeBack;

                    Point3d NodeBack1 = myUKpoint1 + v1 * nodeBack;





                    test2.Add(NodeBack0);

                    test2.Add(NodeBack1);
                }





                else


                {


                    Vector3d moveVecSum2 = myNeighbourVectors[0] + myNeighbourVectors[1];

                    moveVecSum2.Unitize();




                    double alpha = Vector3d.VectorAngle(moveVecSum2, myNeighbourVectors[1]);


                    double Hypothenuse = height / System.Math.Cos(alpha);



                    Point3d myUKpoint2 = iPolyL[i] + moveVecSum2 * Hypothenuse * -1;

                    Point3d myUKpoint3 = iPolyL[i + 1] + moveVecSum2 * Hypothenuse * -1;



                    v1.Unitize();


                    Point3d NodeBack2 = myUKpoint2 + v1 * -1 * nodeBack;

                    Point3d NodeBack3 = myUKpoint3 + v1 * nodeBack;



                    test2.Add(NodeBack2);

                    test2.Add(NodeBack3);





                }


            }



            return test2;


        }





























        /// <summary>
        /// Provides an Icon for the component.
        /// </summary>
        protected override System.Drawing.Bitmap Icon
        {
            get
            {
                //You can add image files to your project resources and access them like this:
                // return Resources.IconForThisComponent;
                //  return null;


                // return Resource1.tri;


                // return Resource1.tri_solid_222;


                return Resource1.plateLast;
            }
        }

        /// <summary>
        /// Gets the unique ID for this component. Do not change this ID after release.
        /// </summary>
        public override Guid ComponentGuid
        {
            get { return new Guid("9b9906e4-827d-486d-b760-7ffd21fb3e0d"); }
        }
    }
}