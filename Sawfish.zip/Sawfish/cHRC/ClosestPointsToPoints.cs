﻿using System;
using System.Collections.Generic;

using Grasshopper.Kernel;
using Rhino.Geometry;

namespace cHRC
{
    public class ClosestPointsToPoints : GH_Component
    {
        /// <summary>
        /// Initializes a new instance of the MyComponent3 class.
        /// </summary>
        public ClosestPointsToPoints()
          : base("04_CLosestPoints", "CPts",
              "Ceck from every point in a list (Points[]) which point of an other list (CheckPoints[]) is the closest coresponding point",
              "cHRC", "01 Adjust")
        {
        }

        /// <summary>
        /// Registers all the input parameters for this component.
        /// </summary>
        protected override void RegisterInputParams(GH_Component.GH_InputParamManager pManager)
        {
            pManager.AddPointParameter("Points", "Pt", "Points to Test", GH_ParamAccess.list); //00

            pManager.AddPointParameter("CheckPoints", "CPt", "Checkpoints", GH_ParamAccess.list); //01


        }

        /// <summary>
        /// Registers all the output parameters for this component.
        /// </summary>
        protected override void RegisterOutputParams(GH_Component.GH_OutputParamManager pManager)
        {

            pManager.AddPointParameter("ClosestCheckPoints", "CP", "For every Point in Points the closest Checkpoint ", GH_ParamAccess.list);
            pManager.AddNumberParameter("IndexOfClosest", "i", "Your Indexes ", GH_ParamAccess.list);

        }

        /// <summary>
        /// This is the method that actually does the work.
        /// </summary>
        /// <param name="DA">The DA object is used to retrieve from inputs and store in outputs.</param>
        protected override void SolveInstance(IGH_DataAccess DA)
        {






            List<Point3d> iTest = new List<Point3d>();   //00



            List<Point3d> iTest2 = new List<Point3d>();   //01



            if (!DA.GetDataList<Point3d>(0, iTest)) { return; } //  00


            if (!DA.GetDataList<Point3d>(1, iTest2)) { return; } //  01








            List<Point3d> ClosestPoints = new List<Point3d>();

            for (int i = 0; i < iTest.Count; i++)
            {
                Point3d myClosests = PointClosestPoint(iTest[i], iTest2);
                ClosestPoints.Add(myClosests);
            }


            //I know its stupid - 

            List<double> myIndexes = new List<double>();

            for (int i = 0; i < iTest.Count; i++)
            {
                double myIndexes2 = PointClosestPointINDEX(iTest[i], iTest2);
                myIndexes.Add(myIndexes2);
            }





            //   oClosest = ClosestPoints;

            DA.SetDataList(0, ClosestPoints);


            DA.SetDataList(1, myIndexes);

        }











        Point3d PointClosestPoint(Point3d testPoint, List<Point3d> Checkpoints)
        {
            Point3d tp = testPoint;

            double myDist = 100000000;
            //double myIndex = 1000000000000;

            List<Point3d> ClosestPoints = new List<Point3d>();
            Point3d Closest = new Point3d();


            for (int i = 0; i < Checkpoints.Count; i++)
            {
                Point3d SwapPoint = Checkpoints[i];

                double myDist0 = tp.DistanceTo(SwapPoint);

                if (myDist0 < myDist)
                {
                    myDist = myDist0;

                    //myIndex = i;

                    Closest = SwapPoint;
                }

            }

            return Closest;
        }



        //I know its stupid - 

        double PointClosestPointINDEX(Point3d testPoint, List<Point3d> Checkpoints)
        {
            Point3d tp = testPoint;

            double myDist = 100000000;

            double myIndex = 1000000000000;

            List<Point3d> ClosestPoints = new List<Point3d>();

           // Point3d Closest = new Point3d();


            for (int i = 0; i < Checkpoints.Count; i++)
            {
                Point3d SwapPoint = Checkpoints[i];

                double myDist0 = tp.DistanceTo(SwapPoint);

                if (myDist0 < myDist)
                {
                    myDist = myDist0;

                    myIndex = i;

                  //  Closest = SwapPoint;
                }

            }

            return myIndex;
        }















        /// <summary>
        /// Provides an Icon for the component.
        /// </summary>
        protected override System.Drawing.Bitmap Icon
        {
            get
            {
                //You can add image files to your project resources and access them like this:
                // return Resources.IconForThisComponent;
                // return null;

                return Resource1.ClosestPoints;
            }
        }

        /// <summary>
        /// Gets the unique ID for this component. Do not change this ID after release.
        /// </summary>
        public override Guid ComponentGuid
        {
            get { return new Guid("2066c476-a29e-4841-a852-5d002cd70a0a"); }
        }
    }
}