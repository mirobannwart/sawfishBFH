﻿using System;
using System.Collections.Generic;

using Grasshopper.Kernel;
using Rhino.Geometry;





using Grasshopper.Kernel.Data;

namespace cHRC
{
    public class Component_SideLength : GH_Component
    {
        /// <summary>
        /// Initializes a new instance of the MyComponent1 class.
        /// </summary>
        public Component_SideLength()
          : base("SideLenght", "SideLenght",
              "Calculates the leghts of each polygon segment of a polyline and a plane to visualize the result",
              "cHRC", "03 Dimensioning")
        {
        }

        /// <summary>
        /// Registers all the input parameters for this component.
        /// </summary>
        protected override void RegisterInputParams(GH_Component.GH_InputParamManager pManager)
        {




            //pManager.AddCurveParameter("Polylines", "Polylines", "Polyline Input for the offset, as list", GH_ParamAccess.tree); //00

            pManager.AddCurveParameter("Polylines", "Pl", "Polyline Input for the offset, as list", GH_ParamAccess.list); //00


  


            /*

            pManager.AddNumberParameter("PlaneRotate", "PlaneRotate", "Rotation of the plane arount its Z vector in degrees", GH_ParamAccess.item, 0.0);  //04

            pManager.AddIntegerParameter("FlipPlane", "Fliplane", "Flip the Plane(set Plane Y vector negative)", GH_ParamAccess.item, 0); //05



            pManager.AddNumberParameter("moveX", "moveX", "Move the plane along its X vector", GH_ParamAccess.item, 0.0);  //06

            pManager.AddNumberParameter("moveY", "moveY", "Move the plane along its y vector", GH_ParamAccess.item, 0.0);  //07

            pManager.AddNumberParameter("moveZ", "moveZ", "Move the plane along its Z vector", GH_ParamAccess.item, 0.0);  //08

      */



            pManager.AddIntegerParameter("Round", "R", "Round the angle result", GH_ParamAccess.item, 1); //09



            //   pManager.AddBooleanParameter("Manual iteration", "Manual iteration", "True to limit the iterations", GH_ParamAccess.item, false);  //01

            pManager.AddIntegerParameter("StartIteration", "Si", "StartIndex if Manual iteration is true", GH_ParamAccess.item, -1); //03

            pManager.AddIntegerParameter("MaxIterations", "Mi", "Maximal Iteration Count if Manuak Itreration is true, should not be higher than Cinput Curve count minus start Iteration  index", GH_ParamAccess.item, -1); //02

     






        }

        /// <summary>
        /// Registers all the output parameters for this component.
        /// </summary>
        protected override void RegisterOutputParams(GH_Component.GH_OutputParamManager pManager)
        {



            pManager.AddNumberParameter("Lengths", "L", "A Tree of lenghts as numbers ", GH_ParamAccess.tree); //06

            pManager.AddPlaneParameter("Planes", "P", "A tree of planes to visualize the lengths", GH_ParamAccess.tree); //05


           




        }

        /// <summary>
        /// This is the method that actually does the work.
        /// </summary>
        /// <param name="DA">The DA object is used to retrieve from inputs and store in outputs.</param>
        protected override void SolveInstance(IGH_DataAccess DA)
        {



            List<Curve> iCurves = new List<Curve>();   //00



          //  GH_Structure<GH_Curve> iCurvesTree = new GH_Structure<GH_Curve>();


     



   

            double iPlaneRot = 0.0; //04

            int iPlaneFlip = 1; //05





            double iMoveX = 0.0; //06

            double iMoveY = 0.0; //07

            double iMoveZ = 0.0; //08


            int iRound = 2; //09


         //   bool oManItOn = false;  //01

            int oManIt = 1; //02

            int oManStIndex = 1; //03











            // if (!DA.GetDataTree<GH_Curve>(0, out iCurves0)) return;   //worked in crazy ways tree structure




            if (!DA.GetDataList<Curve>(0, iCurves)) { return; }   //00


          //  if (!DA.GetDataTree<GH_Curve>(0, out iCurvesTree)) return;    //00






            /*


            if (!DA.GetData(4, ref iPlaneRot)) return;   //04

            if (!DA.GetData(5, ref iPlaneFlip)) return;  //05




            if (!DA.GetData(6, ref iMoveX)) return;  //06

            if (!DA.GetData(7, ref iMoveY)) return;  //07

            if (!DA.GetData(8, ref iMoveZ)) return;  //08


            */



            if (!DA.GetData(1, ref iRound)) return;  //09



            //    if (!DA.GetData(2, ref oManItOn)) return;  //01


            if (!DA.GetData(2, ref oManStIndex)) return; //03

            if (!DA.GetData(3, ref oManIt)) return;  //02






            /*


            int iteration;

            int StartIndex;

            // int oManStIndex = 0;

            if (oManItOn == true)

            {
                iteration = oManIt;

                StartIndex = oManStIndex;
            }

            else

            {
                iteration = iCurves.Count;

                StartIndex = 0;
            }


            */










            // Enable to define the iteration start and the iteration count without being out of range all the time



            int myStartIndex = 0;

            int iteration = 0;



            if (oManStIndex == -1 & oManIt == -1)

            {
                myStartIndex = 0;

                iteration = iCurves.Count;

                //  iteration = 2;
            }





            if (oManStIndex > -1 & oManIt == -1)

            {

                if (oManStIndex < iCurves.Count)

                {

                    myStartIndex = oManStIndex;

                    iteration = iCurves.Count - oManStIndex;

                }


                else

                {

                    myStartIndex = iCurves.Count - 1;

                    iteration = 1;


                }



            }





            if (oManStIndex == -1 & oManIt > -1)

            {


                if (oManIt < iCurves.Count)

                {
                    myStartIndex = 0;

                    iteration = oManIt;

                }

                else

                {

                    myStartIndex = 0;

                    iteration = iCurves.Count;
                }


            }





            if (oManStIndex > -1 & oManIt > -1)

            {


                if (oManStIndex < iCurves.Count)

                {
                    myStartIndex = oManStIndex;


                    if (oManIt + oManStIndex < iCurves.Count)

                    {
                        iteration = oManIt;
                    }


                    else

                    {
                        iteration = iCurves.Count - oManStIndex;
                    }



                }



                else

                {
                    myStartIndex = iCurves.Count - 1;

                    iteration = 1;

                }



            }







            List<Plane> allMyTopPlanes = new List<Plane>();

            List<int> allMyIndexes = new List<int>();




            List<Plane> SuperallMySidePlanes = new List<Plane>();


            List<Vector3d> allMyVecNormMain = new List<Vector3d>();

            List<Vector3d> allMyVecSide = new List<Vector3d>();



            //   List<Point3d> allMySideCenterPoints = new List<Point3d>();



            //  List<double> allMyAngles = new List<double>();



            List<Plane> allMyTextPlanes = new List<Plane>();




            List<List<Plane>> myTextPlanesListList = new List<List<Plane>>();



            List<List<double>> myLenghtsListList = new List<List<double>>();










            // Main loop



            for (int i = myStartIndex; i < iteration + myStartIndex; i++)
            {


                allMyIndexes.Add(i);




                List<Line> myLines = new List<Line>();



                List<Point3d> myTopPoints3d = new List<Point3d>();





                //c#gh//   Polyline myPolyL = iCurves[i];



                //in Visual studio this is somehow necessary


                Polyline myPolyL;


                // iCurves[i + oManStIndex].TryGetPolyline(out iPolyL3);


                iCurves[i].TryGetPolyline(out myPolyL);










                //Get the polyline points


                for (int j = 0; j < myPolyL.Count; j++)
                {


                    myTopPoints3d.Add(myPolyL[j]);

                }





                Polyline myTopPoly = new Polyline(myTopPoints3d);



                Point3d myCenterTop = PolylineAverage(myTopPoly);  //center of the polyline



                

                int iPlaneFlip2;


                if (iPlaneFlip == 0)

                {
                    iPlaneFlip2 = -1;
                }

                else

                {
                    iPlaneFlip2 = 1;
                }




            

                List<double> myLenghts = new List<double>();


                List<Plane> myTextPlanes = new List<Plane>();



                // Get the lengths and a plane for visualiastion


                for (int j = 0; j < myPolyL.Count - 1; j++)
                {


                    Vector3d myXvec = myPolyL[j + 1] - myPolyL[j];





                    Vector3d v1 = myPolyL[j] - myPolyL[j + 1];

                    Point3d mp0 = myPolyL[j] + v1 * -0.5;  //middlepoint


                    Vector3d myYvec = myCenterTop - mp0;




                    Plane mySuperPl = new Plane(mp0, myXvec, myYvec);



                    //Get the Distances/Lengths


                    List<double> myDists = new List<double>();



                    double myDistTop = myTopPoints3d[j].DistanceTo(myTopPoints3d[j + 1]);

                    myDists.Add(myDistTop);





                    double myLenghtRoundet = System.Math.Round(myDists[0], iRound);



                    myLenghts.Add(myLenghtRoundet);


                    //Text plane:


                    //move and rot the plane, finally not controllable by input, this hapens now in in the Plane Move rot flip node, variable are definded at the beginning of the script and not changeable by input


                    Point3d myMovedCenter = mp0 + mySuperPl.XAxis * iMoveX + mySuperPl.YAxis * iMoveY + mySuperPl.ZAxis * iMoveZ;




                    Plane myTextPl = new Plane(myMovedCenter, mySuperPl.XAxis, myYvec * iPlaneFlip2);


                    double myRadians = Rhino.RhinoMath.ToRadians(iPlaneRot);  //its all 0 defined at the beginning

                    myTextPl.Rotate(myRadians, myTextPl.ZAxis);



                    allMyTextPlanes.Add(myTextPl);

                    myTextPlanes.Add(myTextPl);




                }








                myLenghtsListList.Add(myLenghts);


                myTextPlanesListList.Add(myTextPlanes);



            }








            



            Grasshopper.DataTree<double> myLenghtsTree = new Grasshopper.DataTree<double>();        //ListofLists to Tree for the Output


            for (int i = 0; i < myLenghtsListList.Count; i++)
            {

                int ListLenght333 = myLenghtsListList[i].Count;

                for (int j = 0; j < ListLenght333; j++)
                {

                    myLenghtsTree.Add(myLenghtsListList[i][j], new GH_Path(i));

                    //myFinalPointsTree.Add(mySuperPoints[i][j], new GH_Path(i));
                }

            }


            




            Grasshopper.DataTree<Plane> myTextPlanesTree = new Grasshopper.DataTree<Plane>();        //ListofLists to Tree for the Output


            for (int i = 0; i < myTextPlanesListList.Count; i++)
            {

                int ListLenght333 = myTextPlanesListList[i].Count;

                for (int j = 0; j < ListLenght333; j++)
                {

                    myTextPlanesTree.Add(myTextPlanesListList[i][j], new GH_Path(i));

                    //myFinalPointsTree.Add(mySuperPoints[i][j], new GH_Path(i));
                }

            }





            DA.SetDataTree(0, myLenghtsTree);



            DA.SetDataTree(1, myTextPlanesTree);

        








            /*




            oLenghtsTree = myLenghtsTree;

            oTextplaneTree = myTextPlanesTree;












            oAllMyTopPlanes = allMyTopPlanes;


            oAllmyIndexes = allMyIndexes;




            oAllMyVecNormMaim = allMyVecNormMain;


            oSuperallMySidePlanes = SuperallMySidePlanes;


            //oAllMySideCenterPoints = allMySideCenterPoints;


            oAllMyVecSide = allMyVecSide;




            oAllMyTextPlanes = allMyTextPlanes;



            */








        }

















        public static Point3d PolylineAverage(Polyline iPolyL)    // A function to get the Average(center) of a closed curve. The last point is not taken it ist on the position of the first
        {

            Point3d PCenterT2 = new Point3d(0, 0, 0);


            for (int i = 0; i < iPolyL.Count - 1; i++)

            {
                PCenterT2 = PCenterT2 + iPolyL[i];
            }

            Point3d PCenter3 = PCenterT2 / (iPolyL.Count - 1);


            return PCenter3;
        }



 












        /// <summary>
        /// Provides an Icon for the component.
        /// </summary>
        protected override System.Drawing.Bitmap Icon
        {
            get
            {
                //You can add image files to your project resources and access them like this:
                // return Resources.IconForThisComponent;

                //    return null;

                return Resource1.lengths2;
            }
        }

        /// <summary>
        /// Gets the unique ID for this component. Do not change this ID after release.
        /// </summary>
        public override Guid ComponentGuid
        {
            get { return new Guid("f1062327-94be-4582-b86f-d7a7f9a25ddd"); }
        }
    }
}