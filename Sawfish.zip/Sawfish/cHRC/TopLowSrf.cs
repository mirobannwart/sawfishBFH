﻿using System;
using System.Collections.Generic;

using Grasshopper.Kernel;
using Rhino.Geometry;

namespace cHRC
{
    public class TopLowSrf : GH_Component
    {
        /// <summary>
        /// Initializes a new instance of the MyComponent3 class.
        /// </summary>
        public TopLowSrf()
          : base("08_TopLowSurface", "TopLowSrf",
              "The Top and Low surfaces of a beams or plates, based on their sidelines",
              "cHRC", "02 Offset Geometry")
        {
        }


        /// <summary>
        /// Registers all the input parameters for this component.
        /// </summary>
        protected override void RegisterInputParams(GH_Component.GH_InputParamManager pManager)
        {


            pManager.AddLineParameter("SideLines", "SL", "The Sidelines of beams and or plates", GH_ParamAccess.list); //00

           // pManager.AddNumberParameter("SideJoinTol", "T1", "The tolerance in which the side surfaces can be joined", GH_ParamAccess.item, 0.001);  //01

           // pManager.AddNumberParameter("TopLowCapTol", "T2", "The tolerance in which the top and the low side can be caped", GH_ParamAccess.item, 0.001);  //02

             pManager.AddNumberParameter("TopLowSrfTol", "T", "The tolerance in which the top and the low surface  can be created", GH_ParamAccess.item, 0.001);  //03


        }

        /// <summary>
        /// Registers all the output parameters for this component.
        /// </summary>
        protected override void RegisterOutputParams(GH_Component.GH_OutputParamManager pManager)
        {

           // pManager.AddBrepParameter("ColsedBrep", "CB", "A Closed Brep for every input list", GH_ParamAccess.item);  //00
            
                        pManager.AddBrepParameter("TopSurface", "TS", "The side top Surface", GH_ParamAccess.item);  //00

                    //    pManager.AddBrepParameter("SideSurfaces", "SS", "The side Surfaces", GH_ParamAccess.list);  //02

                        pManager.AddBrepParameter("LowerSurface", "LS", "The  lower Surface", GH_ParamAccess.item);  //01

            pManager.AddCurveParameter("TopPolyline", "TPl", "The top polyline", GH_ParamAccess.list); //02

            pManager.AddCurveParameter("LowPolyline", "LPl", "The low polyline", GH_ParamAccess.list); //03





        }

        /// <summary>
        /// This is the method that actually does the work.
        /// </summary>
        /// <param name="DA">The DA object is used to retrieve from inputs and store in outputs.</param>
        protected override void SolveInstance(IGH_DataAccess DA)
        {



            List<Line> iLines = new List<Line>();   //00

          //  double joinSideT = 0.001; //01

           // double CapTopT = 0.001; //02

             double TopLowSrfTol = 0.001; //01



            if (!DA.GetDataList<Line>(0, iLines)) { return; } //  00


           // if (!DA.GetData(1, ref joinSideT)) return; //02


          //  if (!DA.GetData(2, ref joinSideT)) return;   //03


               if (!DA.GetData(1, ref TopLowSrfTol)) return;   //01





            //List<Surface> myTopSrf = new List<Surface>();

            // List<Surface> myLowSurface = new List<Surface>();







            iLines.Add(iLines[0]);





            List<Brep> myBreps = new List<Brep>();










            //  Creaze Lists with Top and lower points for a top and a lower polyline for the top and lower surface


            List<Point3d> myTopPoints3d = new List<Point3d>();

            List<Point3d> myLowPoints3d = new List<Point3d>();


            for (int i = 0; i < iLines.Count; i++)
            {

                Point3d St = iLines[i].PointAtLength(0.0);

                Point3d End = iLines[i].PointAtLength(iLines[i].Length);


                myTopPoints3d.Add(End);

                myLowPoints3d.Add(St);

            }



     
            //ARRAY TO LIST


              Rhino.Geometry.Point3d[] myTopPoints3dnoDupAr = Rhino.Geometry.Point3d.CullDuplicates(myTopPoints3d, 0.01);

              Rhino.Collections.Point3dList myTopPoints3dnoDup = new Rhino.Collections.Point3dList(myTopPoints3dnoDupAr);

               myTopPoints3dnoDup.Add(myTopPoints3dnoDup[0]);



              Rhino.Geometry.Point3d[] myLowpPoints3dnoDupAr = Rhino.Geometry.Point3d.CullDuplicates(myLowPoints3d, 0.01);

              Rhino.Collections.Point3dList myLowPoints3dnoDup = new Rhino.Collections.Point3dList(myLowpPoints3dnoDupAr);

              myLowPoints3dnoDup.Add(myLowPoints3dnoDup[0]);







            //Create the top and the lower surface from a top and a lower polyline




              Polyline TopPoly2 = new Polyline(myLowPoints3dnoDup);

              Polyline LowPoly2 = new Polyline(myTopPoints3dnoDup);


              Polyline TopPoly = new Polyline(myLowPoints3d);

              Polyline LowPoly = new Polyline(myTopPoints3d);





            Brep myTopSrf = Brep.CreatePlanarBreps(TopPoly.ToNurbsCurve(), TopLowSrfTol)[0];  //Break  here

            Brep myLowSrf = Brep.CreatePlanarBreps(LowPoly.ToNurbsCurve(), TopLowSrfTol)[0];   





            /*
            oTopSrf = myTopSrf;

            oLowSrf = myLowSrf;

            */



            // DA.SetData(0, CLOSEDBREP);

            DA.SetData(0, myTopSrf);

             DA.SetData(1, myLowSrf);




             DA.SetData(2, TopPoly2);

              DA.SetData(3, LowPoly2);





            //  DA.SetData(3, MyLowSrf);



        }






        /// <summary>
        /// Provides an Icon for the component.
        /// </summary>
        protected override System.Drawing.Bitmap Icon
        {
            get
            {
                //You can add image files to your project resources and access them like this:
                // return Resources.IconForThisComponent;

                // return null;


                return Resource1.ToipLowSrf2;

            }
        }
        public override Guid ComponentGuid
        {
            get { return new Guid("3a95088b-7f2e-422b-9d3b-64f76c0e4b71"); }
        }
    }
}