﻿using System;
using System.Collections.Generic;

using Grasshopper.Kernel;
using Rhino.Geometry;

namespace cHRC
{
    public class CurvesInBreps : GH_Component
    {
        /// <summary>
        /// Initializes a new instance of the MyComponent3 class.
        /// </summary>
        public CurvesInBreps()
          : base("08_PolylinesInBreps", "PLinBreps",
              "Checks if a Polyline is inside of a Brep by checking if a testpoint (Checkpoint) is inside of a brep of a list of breps",
              "cHRC", "01 Adjust")
        {
        }

        /// <summary>
        /// Registers all the input parameters for this component.
        /// </summary>
        protected override void RegisterInputParams(GH_Component.GH_InputParamManager pManager)
        {

            pManager.AddCurveParameter("Polylines", "PL", "Polylines to Check", GH_ParamAccess.list); //00

            pManager.AddPointParameter("Checkpoints", "CPt", "The Checkpoints for insideBrep check", GH_ParamAccess.list); //01

            pManager.AddBrepParameter("Breps", "B", "The breps for point inclusion checking", GH_ParamAccess.list); //02

            pManager.AddNumberParameter("CheckingTolerance", "T", "Brep nnclusion check tolerance", GH_ParamAccess.item, 0.002);  //03

            pManager.AddBooleanParameter("Strict", "S", "Strict or not Strict (brep point inclusion)", GH_ParamAccess.item, true);  //04



        }

        /// <summary>
        /// Registers all the output parameters for this component.
        /// </summary>
        protected override void RegisterOutputParams(GH_Component.GH_OutputParamManager pManager)
        {


            pManager.AddCurveParameter("PolylinesA", "PlA", "Polylines (according to the Testpoint) inside of the breps", GH_ParamAccess.list); //00

            pManager.AddNumberParameter("IndexA", "iA", "Index of Polyline /Checkpoint inside of the breps", GH_ParamAccess.list); //00

            pManager.AddPointParameter("PointA", "PtA", "Checkpoints inside of the breps", GH_ParamAccess.list); //00



            pManager.AddCurveParameter("PolylinesB", "PlB", "Polylines (according to the Testpoint) outside of the brep", GH_ParamAccess.list); //00

            pManager.AddNumberParameter("IndexB", "iB", "Index of Polyline /Checkpoint outside of the brep", GH_ParamAccess.list); //00

            pManager.AddPointParameter("PointB", "PtB", "Checkpoints outside of the breps", GH_ParamAccess.list); //00



        }

        /// <summary>
        /// This is the method that actually does the work.
        /// </summary>
        /// <param name="DA">The DA object is used to retrieve from inputs and store in outputs.</param>
        protected override void SolveInstance(IGH_DataAccess DA)
        {





            List<Curve> iCurves = new List<Curve>();   //00

            List<Point3d> iCheckPoints = new List<Point3d>();   //01

            List<Brep> iBreps = new List<Brep>();   //02

            double iTol = 0.002; //03

            bool iStrictIn = true;  //04







            if (!DA.GetDataList<Curve>(0, iCurves)) { return; } //  00

            if (!DA.GetDataList<Point3d>(1, iCheckPoints)) { return; } //  01

            if (!DA.GetDataList(2, iBreps)) { return; }  //02

            if (!DA.GetData(3, ref iTol)) return;  //03

            if (!DA.GetData(4, ref iStrictIn)) return;  //04







            List<Polyline> myPolys222 = new List<Polyline>();

            for (int i = 0; i < iCurves.Count; i++)
            {

                Polyline iPolyL3;  //polyline to work with

                // iCurves[i + oManStIndex].TryGetPolyline(out iPolyL3);

                iCurves[i].TryGetPolyline(out iPolyL3); //visual studio work around

                myPolys222.Add(iPolyL3);
            }













            List<Point3d> myTestPoints = new List<Point3d>();

            List<Surface> myTestSurfaces = new List<Surface>();

            List<Point3d> myFinalPoints = new List<Point3d>();





            List<Polyline> myPolysA = new List<Polyline>();

            List<Polyline> myPolysB = new List<Polyline>();


            List<int> myIndexA = new List<int>();

            List<int> myIndexB = new List<int>();




            List<Point3d> myPointsA = new List<Point3d>();

            List<Point3d> myPointsB = new List<Point3d>();





            for (int i = 0; i < iCheckPoints.Count; i++)
            {

                List<bool> inBools = new List<bool>();


                for (int j = 0; j < iBreps.Count; j++)
                {

                    bool isInside = iBreps[j].IsPointInside(iCheckPoints[i], iTol, iStrictIn);



                    if (isInside)

                    {
                        inBools.Add(isInside);
                    }


                }

                if (inBools.Count > 0)

                {
                    myPolysA.Add(myPolys222[i]);

                    myIndexA.Add(i);

                    myPointsA.Add(iCheckPoints[i]);


                }

                else

                {
                    myPolysB.Add(myPolys222[i]);

                    myIndexB.Add(i);

                    myPointsB.Add(iCheckPoints[i]);


                }





            }



            /*

            PolysA = myPolysA;


            PolysB = myPolysB;



            indexA = myIndexA;

            indexB = myIndexB;

            */


            DA.SetDataList(0, myPolysA);

            DA.SetDataList(1, myIndexA);

            DA.SetDataList(2, myPointsA);


            DA.SetDataList(3, myPolysB);

            DA.SetDataList(4, myIndexB);

            DA.SetDataList(5, myPointsB);






            // oPoints = myFinalPoints;

            // oTestPoints = myTestPoints;

            //oTestSurfaces = myTestSurfaces;


        }

        /// <summary>
        /// Provides an Icon for the component.
        /// </summary>
        protected override System.Drawing.Bitmap Icon
        {
            get
            {
                //You can add image files to your project resources and access them like this:
                // return Resources.IconForThisComponent;

                //  return null;

                return Resource1.PolyInBrep;


            }
        }

        /// <summary>
        /// Gets the unique ID for this component. Do not change this ID after release.
        /// </summary>
        public override Guid ComponentGuid
        {
            get { return new Guid("4f75cdb6-bf61-4019-98c7-65920ea5ecd9"); }
        }
    }
}