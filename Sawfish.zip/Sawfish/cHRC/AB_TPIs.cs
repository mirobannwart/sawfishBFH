﻿using System;
using System.Collections.Generic;

using Grasshopper.Kernel;
using Rhino.Geometry;

namespace cHRC
{
    public class AB_TPIs : GH_Component
    {
        /// <summary>
        /// Initializes a new instance of the MyComponent1 class.
        /// </summary>
        public AB_TPIs()
          : base("01_MyProject_TPI_silent", "TPIs",
              "Agentbased tangetial plane intersection Silent Solver, use it as it is, its under development, ",
              "cHRC", "05 WIP agentTPI + and more")
        {
        }

        /// <summary>
        /// Registers all the input parameters for this component.
        /// </summary>
        protected override void RegisterInputParams(GH_Component.GH_InputParamManager pManager)
        {
            // Use the pManager object to register your input parameters.
            // You can often supply default values when creating parameters.
            // All parameters must have the correct access type. If you want 
            // to import lists or trees of values, modify the ParamAccess flag.






            pManager.AddPointParameter("Starting_Points", "Pt", "Starting points", GH_ParamAccess.list); //0

            pManager.AddIntegerParameter("Max_Centers", "MaxPt", "Maximal allowed amount of centers in the simulation", GH_ParamAccess.item, 158); //1

            pManager.AddSurfaceParameter("Surface", "Srf", "Design Nurb Surface", GH_ParamAccess.item);  //2

            //pManager.AddCurveParameter("Curve", "Crv", "DesignCurves", GH_ParamAccess.list);  //2

            pManager.AddNumberParameter("Radius", "R", "Agent Radius", GH_ParamAccess.item, 0.9);  //3

            pManager.AddIntegerParameter("Test_Index", "Ti", "Test Index", GH_ParamAccess.item, 0); //4



            pManager.AddNumberParameter("a1", "a1", "Remapping weights dont think about - a1", GH_ParamAccess.item, 0.0);  //5

            pManager.AddNumberParameter("a2", "a2", "Remapping weights dont think about - a2", GH_ParamAccess.item, 0.6);  //6

            pManager.AddNumberParameter("b1", "b1", "Remapping weights dont think about - b1", GH_ParamAccess.item, 1.2);  //7

            pManager.AddNumberParameter("b2", "b2", "Remapping weights dont think about - b2", GH_ParamAccess.item, 0.8);  //8




            pManager.AddIntegerParameter("Velocity_decrease_at_Iteration", "Vdi", "Decrease the distribution Velocity at this Iteration (int)", GH_ParamAccess.item, 160);  //9

            pManager.AddNumberParameter("Weight_Distribution_2", "WD2", "Weight Distribution after VDI", GH_ParamAccess.item, 0.6);  //10




            pManager.AddNumberParameter("Outside_Tolerance", "oTl", "Remove Plate Outside of the Surface", GH_ParamAccess.item, 0.6);  //11

            pManager.AddBooleanParameter("Add_Edge_Polygon", "aEP", "Add an Edge Polygon", GH_ParamAccess.item, true);  //12



            pManager.AddNumberParameter("Weight_Distribution", "WD", "Weight Distribution", GH_ParamAccess.item, 2.00);  //13

            pManager.AddNumberParameter("Weight_To_Shortest_Edge", "WtSEG", "Weight Distribution towards the polygons shortest Edge, Global", GH_ParamAccess.item, 0.04);  //14

            pManager.AddNumberParameter("Weight_To Longest", "WtLE", "Weight Distribution along the longest mesh Edge (???will check later)", GH_ParamAccess.item, 0.012);  //15


            pManager.AddBooleanParameter("more_Agents_at_less-Curvature", "mAalC", "Generates more Agents at less curvature - dynamic Radius (check later)", GH_ParamAccess.item, true);  //16

            pManager.AddBooleanParameter("stop_adding_agents", "stpA", "Stops to add Agents", GH_ParamAccess.item, true);  //17

            pManager.AddBooleanParameter("Reset", "R", "Reset the Simulation", GH_ParamAccess.item, false);  //18


            pManager.AddIntegerParameter("MaxIterations", "maxIt", "for silent mode (not used...) (int)", GH_ParamAccess.item, 40);  //19




















            // If you want to change properties of certain parameters, 
            // you can use the pManager instance to access them by index:
            //pManager[0].Optional = true;
        }

        /// <summary>
        /// Registers all the output parameters for this component.
        /// </summary>
        protected override void RegisterOutputParams(GH_Component.GH_OutputParamManager pManager)
        {
            // Use the pManager object to register your output parameters.
            // Output parameters do not have default values, but they too must have the correct access type.









            pManager.AddMeshParameter("Mesh", "M", "Mesh probably not used, between c# code and plugin were 1,5 years.......", GH_ParamAccess.item);

            pManager.AddPointParameter("Centers", "C", "Centers", GH_ParamAccess.list);

            pManager.AddPointParameter("Vectors", "V", "Vectors", GH_ParamAccess.list);

            pManager.AddCurveParameter("Curves", "Crv", "Intersect polygonal curves", GH_ParamAccess.list);

            pManager.AddIntegerParameter("Itertions", "I", "Iteration count", GH_ParamAccess.item);

            pManager.AddCircleParameter("Circle", "Ci", "Agent Circles", GH_ParamAccess.list);

            pManager.AddCircleParameter("Circle_Edge", "CiE", "Agent Circles At the Edge", GH_ParamAccess.list);

















            // Sometimes you want to hide a specific parameter from the Rhino preview.
            // You can use the HideParameter() method as a quick way:
            //pManager.HideParameter(0);
        }

        /// <summary>
        /// This is the method that actually does the work.
        /// </summary>
        /// <param name="DA">The DA object can be used to retrieve data from input parameters and 
        /// to store data in output parameters.</param>
        protected override void SolveInstance(IGH_DataAccess DA)
        {
            // First, we need to retrieve all data from the input parameters.
            // We'll start by declaring variables and assigning them starting values.


            // Then we need to access the input parameters individually. 
            // When data cannot be extracted from a parameter, we should abort this method.













            // We're set to create the spiral now. To keep the size of the SolveInstance() method small, 
            // The actual functionality will be in a different method:


            // Finally assign the spiral to the output parameter.
















            // First, we need to retrieve all data from the input parameters.
            // We'll start by declaring variables and assigning them starting values.

            /*
            Plane plane = Plane.WorldXY;
            double radius0 = 0.0;
            double radius1 = 0.0;
            int turns = 0;
            */


            // Mesh mesh = new Mesh();
            //  String test = test;



            List<Point3d> iStartingPositions = new List<Point3d>();   //0

            int iMaxCenterCount = 20;  //1



            //var surface = new EnvironmentVariableTarget();

            // public  surface000 = new  Surface();

            //Rhino.Geometry.Surface surface = new Rhino.Geometry.Surface();

            //Surface surface = new Surface();

            Surface surface = null;  //2

            // Rhino.Geometry.NurbsSurface surface = new Rhino.Geometry.NurbsSurface();

            //GH_Surface surface222 = new GH_Surface;

            //GH_Surface surface0 = new GH_Surface();


            //List < Surface > SurfaceList =  new List<Surface>();


            //List<Curve> curves = new List<Curve>();



            double iRadius = 0.9;  //3

            int iTest = 5;  //4 


            double a1 = 0.9;  //5

            double a2 = 0.9; //6

            double b1 = 0.9;  //7

            double b2 = 0.9;  //8


            int iVelocityDecreaseAtIteration = 5;  //9

            double iWeightDistribution2 = 0.9;  //10

            double iOutsideTolerance = 0.9;  //11


            bool iAddEdgePolygon = false;  //12

            double iWeightDistribution = 0.9; //13

            double iWeightToShortestEdgeGlobal = 0.9; //14

            double iWeightTowardsLongest = 0.9; //15

            bool moreAgentsAtLessC = false; //16

            bool iStopAddAgents = false;  //17

            bool iReset = false;  //18

            int iMaxIt = 40; //19






            // Then we need to access the input parameters individually. 
            // When data cannot be extracted from a parameter, we should abort this method.


            // if (!DA.GetDataList(0, ref iStartingPositions)) return;  //0

            if (!DA.GetDataList<Point3d>(0, iStartingPositions)) { return; } //  0

            if (!DA.GetData(1, ref iMaxCenterCount)) return;  // 1

            //if (!DA.GetData(2, ref SurfaceList)) return;

            // if (!DA.GetData<Rhino.Geometry.Surface>(0, ref surface) || !surface.IsValid) { return; }


            //  if (!DA.GetData(2, ref curves)) return;

            if (!DA.GetData(2, ref surface)) return;  // 2


            if (!DA.GetData(3, ref iRadius)) return;

            if (!DA.GetData(4, ref iTest)) return;

            if (!DA.GetData(5, ref a1)) return;

            if (!DA.GetData(6, ref a2)) return;

            if (!DA.GetData(7, ref b1)) return;

            if (!DA.GetData(8, ref b2)) return;

            if (!DA.GetData(9, ref iVelocityDecreaseAtIteration)) return;

            if (!DA.GetData(10, ref iWeightDistribution2)) return;

            if (!DA.GetData(11, ref iOutsideTolerance)) return;

            if (!DA.GetData(12, ref iAddEdgePolygon)) return;

            if (!DA.GetData(13, ref iWeightDistribution)) return;

            if (!DA.GetData(14, ref iWeightToShortestEdgeGlobal)) return;

            if (!DA.GetData(15, ref iWeightTowardsLongest)) return;

            if (!DA.GetData(16, ref moreAgentsAtLessC)) return;

            if (!DA.GetData(17, ref iStopAddAgents)) return;

            if (!DA.GetData(18, ref iReset)) return;

            if (!DA.GetData(19, ref iMaxIt)) return;













            //Expiring:


            var myDay = System.DateTime.Now.Day;

            var myMonth = System.DateTime.Now.Month;

            var myYear = System.DateTime.Now.Year;

            /*
            A = myDay;

            B = myMonth;

            C = myYear;
            */

            //ExpiringTime

            int check = 1;

            int expYear = 999999999;

            int expMonth = 03;

            int expDay = 27;



            if (myYear > expYear)
            {
                check = 0;
            }

            if (myYear == expYear)
            {
                if (myMonth > expMonth)
                {
                    check = 0;
                }

                if (myMonth == expMonth)
                {

                    if (myDay > expDay)
                    {
                        check = 0;
                    }

                }

            }



            //  E = check;





















            //if (surface == null) { return; }




            /*
            if (!DA.GetData(0, ref plane)) return;
            if (!DA.GetData(1, ref radius0)) return;
            if (!DA.GetData(2, ref radius1)) return;
            if (!DA.GetData(3, ref turns)) return;
            */




            /*

            // We should now validate the data and warn the user if invalid data is supplied.
            if (radius0 < 0.0)
            {
                AddRuntimeMessage(GH_RuntimeMessageLevel.Error, "Inner radius must be bigger than or equal to zero");
                return;
            }
            if (radius1 <= radius0)
            {
                AddRuntimeMessage(GH_RuntimeMessageLevel.Error, "Outer radius must be bigger than the inner radius");
                return;
            }
            if (turns <= 0)
            {
                AddRuntimeMessage(GH_RuntimeMessageLevel.Error, "Spiral turn count must be bigger than or equal to one");
                return;
            }
    */



            // We're set to create the spiral now. To keep the size of the SolveInstance() method small, 
            // The actual functionality will be in a different method:


            //Curve spiral = CreateSpiral(plane, radius0, radius1, turns);

            //Finally assign the spiral to the output 

            //parameter.DA.SetData(0, spiral);




            /*

            //NurbsSurface surface = surface0.T

            Surface surface;

            GH_Conversion conv = new GH_Conversion();

            GH_Convert.ToSurface(surface0, ref surface, conv);
            */



            // Surface surface = SurfaceList[0];



            // var breps = Brep.CreateFromLoft(curves, Point3d.Unset, Point3d.Unset, LoftType.Normal, false);


            //Surface surface = breps[0].Surfaces[0];








            if (check != 0)  //Expiring if

            {




                //restart                                                   //restart by bool input Reset






                //  List<Point3d> centers = null;   //is in gh c# in function part





                //  if (iReset || centers == null)                              //for timer

                if (iWeightToShortestEdgeGlobal > -10000)             //for silent solver

                    centers = new List<Point3d>(iStartingPositions);





                //int n = new int();          //is in gh c# in function part,,,,,, HERE TOOO






                // if (iReset) n = 0;                                      //for timer

                if (iWeightToShortestEdgeGlobal > -10000) n = 0;      //for silent solver



            }//7ExpiringIf


            //Lists for silent solver

            List<Curve> SuperallIntersectionCurves = new List<Curve>();


            List<Circle> SuperAllCircles = new List<Circle>();

            List<Vector3d> SuperFinalMoveVec = new List<Vector3d>();

            List<Point3d> SuperCenters = new List<Point3d>();



            //Mesh for silent solver
            Mesh mySuperMesh = new Mesh();





            while (n <= iMaxIt)    //for silent solver
            {


                n += 1;

                //create Lists

                var outTolerance = iOutsideTolerance;


                List<Vector3d> totalMoves = new List<Vector3d>();       //Create List for move Vectors
                List<double> colliosionCounts = new List<double>();       //Create List for collision Counts

                List<Vector3d> FinalMoveVec = new List<Vector3d>();       //Create List final move Vectors for visualisation

                List<Curve> allIntersectionCurves = new List<Curve>();    // List of all  Intersection curves

                List<Circle> myCirclesMain = new List<Circle>();
                List<Circle> myCirclesEdge = new List<Circle>();


                List<Plane> myPlanes = new List<Plane>();




                //Neighbourhood delaunay Mesh:

                Mesh DelauneyMesh0 = MakeDalauneyMeshFromPoints(centers);   //function: create delaunay mesh to get the neighbourhood of each center/agent

                Mesh swaped = swapMeshEdges(DelauneyMesh0);

                Mesh swaped2 = swapMeshEdges(swaped);

                Mesh DelauneyMesh = swaped2;  // test to replace with iMesh... was a bad idea..



                var isNaked = DelauneyMesh.GetNakedEdgePointStatus();


                if (n == iMaxIt + 1)
                {
                    mySuperMesh = DelauneyMesh;
                }

                //Tests at one agent:

                /*
                Plane myPlaneTest = makePlane(surface, centers[iTest]);   //function te get a plane on a surface (test)

                var sortedPointsTest = getNeighbours(DelauneyMesh, centers, iTest);     //function: get and sort neighbours of an index (test)

                var myIntersectPointsTest = intersectPoints(centers, surface, iTest, sortedPointsTest, iOutsideTolerance);  // function: get one test intersection Curve (test)

                List<Point3d> sortedPointsListTest = sortedPointsTest.ToList();

                var intersectCurveTest = Curve.CreateControlPointCurve(myIntersectPointsTest, 1);

                */





                // Zero Lists (move vectors and collision count)

                for (int i = 0; i < centers.Count; i++)                   //Fill Move Vector list with 0.0.0 Vectors (as many as agents in the system)
                {
                    totalMoves.Add(new Vector3d(0, 0, 0));                   //Fill Collision count list with 0.0  (as many as agents in the system)
                    colliosionCounts.Add(0.0);
                }





                // Calculating move vectors and intersection curves

                double collisionDistance = iRadius * 2;                  // 2 Radius = Collision Distance


                for (int i = 0; i < centers.Count; i++)                  // Calculating Distances "d" from each agent toe each agent
                {


                    //Get intersection Curves (output geometry):




                    if (isNaked[i] != true)
                    {

                        var tempSortedPoints = getNeighbours(DelauneyMesh, centers, i);                        //function: get and sort neighbours of an index

                        //List<Point3d> tempSortedPointsList = tempSortedPoints.ToList();                        // var to list (??? is there a better way???)

                        List<Point3d> tempSortedPointsList = tempSortedPoints;                    // var to list (??? is there a better way???)



                        var intersectPt = intersectPoints(centers, surface, i, tempSortedPointsList, iOutsideTolerance);          // function: get intersection Points

                        var intersectCurve = Curve.CreateControlPointCurve(intersectPt, 1);                    // Create Polyline

                        allIntersectionCurves.Add(intersectCurve);                                             // Add Polyline to List


                        Plane myPlane = makePlane(surface, centers[i]);             //Plane for Circle
                        /*
                        Vector3d unitX = new Vector3d(1, 0, 0);                         //Plane in Move directions somehow suddenly index out of range....
                        Plane myPlane2 = new Plane(centers[i], FinalMoveVec[i], unitX);
                        myPlanes.Add(myPlane2);*/

                        Circle myCircle = new Circle(myPlane, iRadius);           //Circle just for visualisation
                        myCirclesMain.Add(myCircle);

                        if (n == iMaxIt + 1)  //for silent solver
                        {
                            SuperallIntersectionCurves.Add(intersectCurve);

                            SuperAllCircles.Add(myCircle);

                            SuperFinalMoveVec = FinalMoveVec;

                            SuperCenters.Add(centers[i]);
                        }


                    }
                    else if (iAddEdgePolygon)
                    {

                        var tempSortedPoints = getNeighbours(DelauneyMesh, centers, i);                        //function: get and sort neighbours of an index
                                                                                                               // List<Point3d> tempSortedPointsList = tempSortedPoints.ToList();                        // var to list (??? is there a better way???)

                        List<Point3d> tempSortedPointsList = tempSortedPoints;                        // var to list (??? is there a better way???)


                        var intersectPt = intersectPoints(centers, surface, i, tempSortedPointsList, iOutsideTolerance);          // function: get intersection Points

                        var intersectCurve = Curve.CreateControlPointCurve(intersectPt, 1);                    // Create Polyline

                        allIntersectionCurves.Add(intersectCurve);                                             // Add Polyline to List



                        Plane myPlane = makePlane(surface, centers[i]);
                        //myPlanes.Add(myPlane);

                        Circle myCircle = new Circle(myPlane, iRadius);
                        myCirclesEdge.Add(myCircle);


                        if (n == iMaxIt + 1) //for silent solver
                        {
                            SuperallIntersectionCurves.Add(intersectCurve);

                            SuperAllCircles.Add(myCircle);

                            SuperCenters.Add(centers[i]);
                        }


                    }





                    for (int j = 0; j < centers.Count; j++)
                    {

                        // More agents at less curvature

                        double averageGaussian = 1;

                        if (moreAgentsAtLessC)
                        {
                            double GaussianCurvature1 = GC(surface, centers[i]);                        //functions to get and remap gaussian curvature of [i]centers and [j]centers
                            double mappedGaussian1 = map(GaussianCurvature1, 0.00, 0.02, 1.3, 0.45);

                            double GaussianCurvature2 = GC(surface, centers[j]);
                            double mappedGaussian2 = map(GaussianCurvature2, 0.00, 0.02, 1.3, 0.45);

                            averageGaussian = (mappedGaussian1 + mappedGaussian2) / 2;           //average of gaussian at i and j center curvature
                        }



                        //calculate move vectors

                        double distance = centers[i].DistanceTo(centers[j]);

                        if (distance > collisionDistance * averageGaussian) continue;  //averageGaussian or 1        //just go on (overwrite 0.0.0 Vecs)if Disstance is smaller than 2 * Radius)

                        //                                                                                           //multiply with average gaussian for more agents at lower gaussian curvature


                        Vector3d move = centers[i] - centers[j];          // Make move Vector by subttracting : centers[i] - centers[j];
                        move.Unitize();                                   // Unitize move Vector
                        move *= 0.5 * (distance - collisionDistance);


                        //Get vectors towards shortest edge:

                        var tempSortedPoints2 = getNeighbours(DelauneyMesh, centers, i);                                         //function: get and sort neighbours of an index
                                                                                                                                 //List<Point3d> tempSortedPointsList2 = tempSortedPoints2.ToList();                                        // var to list (??? is there a better way???)

                        List<Point3d> tempSortedPointsList2 = tempSortedPoints2;                                        // var to list (??? is there a better way???)




                        var intersectPt2 = intersectPoints(centers, surface, i, tempSortedPointsList2, iOutsideTolerance);                          // function: get intersection Points

                        var towardsShortestEdgeVec2 = getVecToShortest(centers[i], intersectPt2, a1, a2, b1, b2);                // function: to get vec towards shortest edge

                        var theLongestNeighbourVec2 = getVecLongestEdge(centers[i], tempSortedPointsList2, 1.3, 2.5, 0.8, 1.2);  //funtion for vector towards longest neighbour



                        var tempSortedPoints3 = getNeighbours(DelauneyMesh, centers, j);                                         //function: get and sort neighbours of an index
                                                                                                                                 // List<Point3d> tempSortedPointsList3 = tempSortedPoints3.ToList();                                        // var to list (??? is there a better way???)

                        List<Point3d> tempSortedPointsList3 = tempSortedPoints3;                                        // var to list (??? is there a better way???)



                        var intersectPt3 = intersectPoints(centers, surface, j, tempSortedPointsList3, iOutsideTolerance);                          // function: get intersection Points

                        var towardsShortestEdgeVec3 = getVecToShortest(centers[j], intersectPt3, a1, a2, b1, b2);                // function: to get vec towards shortest edge

                        var theLongestNeighbourVec3 = getVecLongestEdge(centers[j], tempSortedPointsList3, 1.3, 2.5, 0.8, 1.2);  //funtion for vector towards longest neighbour






                        // Change weights after x iterations...

                        double WeightDistribution = iWeightDistribution;

                        double WeightToShortestEdgeGlobal = 0;
                        double WeightTowardsLongest = 0;


                        if (n > iVelocityDecreaseAtIteration)
                        {
                            WeightDistribution = iWeightDistribution2;

                            WeightToShortestEdgeGlobal = iWeightToShortestEdgeGlobal;

                            WeightTowardsLongest = iWeightTowardsLongest;


                        }




                        // calculate final move vectors,          -- with for example iWeightToShortestEdgeGlobal no changes at iteraration x


                        totalMoves[i] += (move * WeightDistribution * -1) + towardsShortestEdgeVec2 * WeightToShortestEdgeGlobal + theLongestNeighbourVec2 * WeightTowardsLongest;                       // overwrite 0,0,0 vector (or current vector) with new vector
                        totalMoves[j] += move * WeightDistribution + towardsShortestEdgeVec3 * WeightToShortestEdgeGlobal + theLongestNeighbourVec3 * WeightTowardsLongest;                          // at i and j list position


                        /*
                        oWeightDistribution = WeightDistribution;                           //somehow i have to declare here otherwise i does not work...
                        oWeightTowardsShortestPlateEdge = WeightToShortestEdgeGlobal;
                        oWeightTowardsLongestMeshEdge = WeightTowardsLongest;
                        */


                        colliosionCounts[i] += 1.0;                       // why collision counts?? AHA cause to decide if move:):)
                        colliosionCounts[j] += 1.0;                       // AHA2 to decreas the agent speed with each itertion!!!

                    }

                }


                //Mesh DelauneyMesh1 = moveMeshVertices(DelauneyMesh0, FinalMoveVec);  // idea to just change the mesh by moving its vertices in the final move
                //                                                                      (not changing mesh topology...) it somehow did not work,
                //                                                                       (juststopping to add more agents worked better)




                //move centers

                for (int i = 0; i < centers.Count; i++)                     // move each center/agent if collision Count is not 0.0
                {
                    if (colliosionCounts[i] != 0.0)
                        centers[i] += totalMoves[i] / colliosionCounts[i];      // slow down agent speet by shortening the move vec by
                    FinalMoveVec.Add(totalMoves[i] / colliosionCounts[i]);    //dividing move vec through amount of Collision
                                                                              //                                                        //doing the same vor final move Vectors
                }



                for (int i = 0; i < centers.Count; i++)                      //replace the center/agent with its surface closest point

                {
                    double u;
                    double v;

                    surface.ClosestPoint(centers[i], out u, out v);
                    centers[i] = surface.PointAt(u, v);
                }


                //Add new agents

                if (centers.Count < iMaxCenterCount && iStopAddAgents != true)   //magicaly add new agents if distance is larger than 2 * radius


                {
                    List<int> splitIndices = new List<int>();



                    for (int i = 0; i < centers.Count - 1; i++)
                    {
                        if (centers[i].DistanceTo(centers[i + 1]) > iRadius * 2 - .001)
                        {
                            splitIndices.Add(i + 1 + splitIndices.Count);
                        }

                    }
                    foreach (int splitIndex in splitIndices)
                    {
                        Point3d newCenter = 0.5 * (centers[splitIndex - 1] + centers[splitIndex]);
                        centers.Insert(splitIndex, newCenter);
                    }







                }



            }  //for silent solver







            /*

       pManager.AddMeshParameter("Mesh", "M", "Mesh probably not used, between c# code and plugin were 1,5 years.......", GH_ParamAccess.item);

       pManager.AddPointParameter("Centers", "C", "Centers", GH_ParamAccess.list);

       pManager.AddPointParameter("Vectors", "V", "Vectors", GH_ParamAccess.list);

       pManager.AddCurveParameter("Curves", "Crv", "Intersect polygonal curves", GH_ParamAccess.list);

       pManager.AddIntegerParameter("Itertions", "I", "Iteration count", GH_ParamAccess.item);

       pManager.AddCircleParameter("Circle", "Ci", "Agent Circles", GH_ParamAccess.list);

       pManager.AddCircleParameter("Circle_Edge", "CiE", "Agent Circles At the Edge", GH_ParamAccess.list);


       */












            /*
             
            //Output to grasshopper

            oMesh = DelauneyMesh;                  //mySuperMesh  or  DelauneyMesh    switch to super for silent solver

            oCenters = centers;                 //centers or SuperCenters
            oVectors = FinalMoveVec;            //SuperFinalMoveVec or FinalMoveVec

            oIntersectCurves = allIntersectionCurves;        //SuperallIntersectionCurves   allIntersectionCurves   switch to super for silent solver


            oIterations = n;

            oCirclesMain = myCirclesMain;                          // myCircles or SuperAllCircles
            oCirclesEdge = myCirclesEdge;


            */









            DA.SetData(0, mySuperMesh);

            DA.SetDataList(1, SuperCenters);

            DA.SetDataList(2, SuperFinalMoveVec);

            DA.SetDataList(3, SuperallIntersectionCurves);

            DA.SetData(4, n);

            DA.SetDataList(5, SuperAllCircles);

            //  DA.SetDataList(6, myCirclesEdge);












            /*


            DA.SetData(0, DelauneyMesh);

            DA.SetDataList(1, centers);

            DA.SetDataList(2, FinalMoveVec);

            DA.SetDataList(3, allIntersectionCurves);

            DA.SetData(4, n);

            DA.SetDataList(5, myCirclesMain);

            DA.SetDataList(6, myCirclesEdge);

            */

        }













        ///function here:
        ///







        List<Point3d> centers = null;   //is in gh c# in function part (as here....))) makes no sense i know

        int n = new int();          //is in gh c# in function part



        //function to remap values

        double map(double s, double a1, double a2, double b1, double b2)
        {
            return b1 + (s - a1) * (b2 - b1) / (a2 - a1);
        }



        //function to return Gaussian Curvature

        double GC(Surface s, Point3d p)
        {
            double u1;
            double v1;
            s.ClosestPoint(p, out u1, out v1);

            var surface_curvature1 = s.CurvatureAt(u1, v1);
            double GaussianCurvature = surface_curvature1.Gaussian;

            return GaussianCurvature;
        }



        //function to create frame at surface closest point

        Plane makePlane(Surface s, Point3d p)
        {
            double u3;
            double v3;
            s.ClosestPoint(p, out u3, out v3);

            Plane myPlane;

            s.FrameAt(u3, v3, out myPlane);

            return myPlane;
        }



        //Function: Create delauney Mesh

        public Mesh MakeDalauneyMeshFromPoints(List<Point3d> points)
        {

            Grasshopper.Kernel.Geometry.Node2List N2L = new Grasshopper.Kernel.Geometry.Node2List(points);



            // IEnumerable DF = Grasshopper.Kernel.Geometry.Delaunay.Solver.Solve_Faces(N2L, 0.0);           //c# grasshopper



            System.Collections.IEnumerable DF = Grasshopper.Kernel.Geometry.Delaunay.Solver.Solve_Faces(N2L, 0.0);    //c# visual studio


            List<MeshFace> Faces = new List<MeshFace>();

            foreach (Grasshopper.Kernel.Geometry.Delaunay.FaceEx DFace in DF)
            {
                MeshFace MF = new MeshFace(DFace.A, DFace.B, DFace.C);
                Faces.Add(MF);
            }

            Mesh DelauneyMesh = new Mesh();

            DelauneyMesh.Vertices.AddVertices(points);

            DelauneyMesh.Faces.AddFaces(Faces);

            return DelauneyMesh;








            /*

            


    //input
            //List<Point3d> pts;

            //convert point3d to node2
            //grasshopper requres that nodes are saved within a Node2List for Delaunay

            var nodes = new Grasshopper.Kernel.Geometry.Node2List();


            

            for (int i = 0; i < pts.Count; i++)
            {
                //notice how we only read in the X and Y coordinates
                //  this is why points should be mapped onto the XY plane

                 nodes.Append(new Grasshopper.Kernel.Geometry.Node2(pts[i].X, pts[i].Y));


            }

            //solve Delaunay
            var delMesh = new Mesh();

            var delMesh2 = new Mesh();




            var faces = new List<Grasshopper.Kernel.Geometry.Delaunay.Face>();

            faces = Grasshopper.Kernel.Geometry.Delaunay.Solver.Solve_Faces(nodes, 1);


          



            //output
            delMesh = Grasshopper.Kernel.Geometry.Delaunay.Solver.Solve_Mesh(nodes, 1, ref faces);




            delMesh2.Vertices.AddVertices(pts)

            delMesh2.Faces.AddFaces(delMesh.Faces);




            return delMesh2;

            
           // return delMesh;


            */

        }




        //function to get and sort neighbours

        public static List<Point3d> getNeighbours(Mesh myMesh, List<Point3d> myPoints, int myIndex)
        {

            var Neighbours = myMesh.Vertices.GetConnectedVertices(myIndex);





            //List<int> NeighboursList = Neighbours.ToList();


            var NeighboursList = new List<int>(Neighbours);






            List<Point3d> NeighbourPoints = new List<Point3d>();  //loop to fill list with neighbours


            for (int i = 0; i < NeighboursList.Count; i++)

            {
                NeighbourPoints.Add(myPoints[NeighboursList[i]]);
            }


            NeighbourPoints.Add(myPoints[NeighboursList[0]]);






            var sortedPoints = Point3d.SortAndCullPointList(NeighbourPoints, 0.002);  // sort Points


            var myList = new List<Point3d>(sortedPoints);




            // List<Point3d> myList = new List<Point3d>();

            // myList = sortedPoints.ToList();






            myList.Add(myList[0]);


            return myList;
        }




        //function to get Plane intersection Points (polyline)

        public List<Point3d> intersectPoints(List<Point3d> allPoints, Surface s, int thisOne, List<Point3d> superSorted, double outTolerance)

        {

            List<Point3d> intersectionPoints = new List<Point3d>();

            Plane mainPlane0 = makePlane(s, allPoints[thisOne]);


            for (int i = 0; i < superSorted.Count - 1; i++)
            {
                Plane plane1 = makePlane(s, superSorted[i]);
                Plane plane2 = makePlane(s, superSorted[i + 1]);

                Point3d intPoint;

                Rhino.Geometry.Intersect.Intersection.PlanePlanePlane(mainPlane0, plane1, plane2, out intPoint);


                double u;
                double v;

                s.ClosestPoint(intPoint, out u, out v);

                Point3d cp = s.PointAt(u, v);

                double d = intPoint.DistanceTo(cp);



                if (d < outTolerance)
                {
                    intersectionPoints.Add(intPoint);
                }
            }


            if (intersectionPoints.Count > 0)
            {

                intersectionPoints.Add(intersectionPoints[0]);

            }

            else
            {
                Point3d p1 = new Point3d(0, 0, 0);

                intersectionPoints.Add(p1);
                intersectionPoints.Add(p1);

            }



            return intersectionPoints;
        }



        // function to get vector from the "center/agent" to the middle of the shortest "intersection edge"
        //(to between shortest point dist in a list of points)

        public Vector3d getVecToShortest(Point3d theCenter, List<Point3d> theNeighbours, double a1, double a2, double b1, double b2)
        {

            double smallestDist = 1000000.0;
            Point3d middleP = new Point3d(0, 0, 0);

            for (int i = 0; i < theNeighbours.Count - 1; i++)
            {
                Point3d p = theNeighbours[i];
                Point3d p2 = theNeighbours[i + 1];

                double tempdist = p.DistanceTo(p2);

                if (tempdist > smallestDist) continue;

                smallestDist = tempdist;
                middleP = (p + p2) / 2;
            }

            Vector3d theVec = middleP - theCenter;
            theVec.Unitize();



            double mappedSmallestDist = map(smallestDist, a1, a2, b1, b2);

            Vector3d theVec2 = theVec * mappedSmallestDist;

            return theVec2;
        }




        // function to get longest neighbour edge vec (from agent/center to longest agent neighbour)


        public Vector3d getVecLongestEdge(Point3d theCenter, List<Point3d> theNeighbours, double a1, double a2, double b1, double b2)
        {
            double longest = 0.0002;

            Point3d thePoint = new Point3d(0, 0, 0);


            for (int i = 0; i < theNeighbours.Count - 1; i++)
            {
                Point3d p = theNeighbours[i];


                double tempdist = theCenter.DistanceTo(p);

                if (tempdist < longest) continue;

                longest = tempdist;

                thePoint = theNeighbours[i];
            }

            Vector3d theVeclongest = thePoint - theCenter;
            theVeclongest.Unitize();


            double mappedSmallestDist = map(longest, a1, a2, b1, b2);

            Vector3d theVeclongest2 = theVeclongest * mappedSmallestDist;

            return theVeclongest2;
        }


        // Function to move mesh vertices
        /*
        public Mesh moveMeshVertices(Mesh theMesh, List < Vector3d > theVecs)
        {

        for (int i = 0; i < theMesh.Vertices.Count; i++)
        {
        Point3d position = theMesh.Vertices[i];

        Point3d newPosition = position + theVecs[i];

        theMesh.Vertices.SetVertex(i, newPosition);

        }
        return theMesh;
        }
        */




        //Function to swap mesh edges if the Mesh edge is Longer than the distanc between its tip points

        public Mesh swapMeshEdges(Mesh theMesh)
        {
            theMesh.Faces.ConvertQuadsToTriangles();

            Point3d[] VertexPts = theMesh.Vertices.ToPoint3dArray();


            for (int i = 0; i < theMesh.TopologyEdges.Count; i++)
            {
                int[] ConnectedFaces = theMesh.TopologyEdges.GetConnectedFaces(i);


                if (ConnectedFaces.Length == 2)
                {
                    Point3d EdgeEnd1 = theMesh.TopologyEdges.EdgeLine(i).From;
                    Point3d EdgeEnd2 = theMesh.TopologyEdges.EdgeLine(i).To;

                    int[] adjacentface1points = theMesh.TopologyVertices.IndicesFromFace(ConnectedFaces[0]);
                    int[] adjacentface2points = theMesh.TopologyVertices.IndicesFromFace(ConnectedFaces[1]);




                    //IndexPair EndTopologyVertices = theMesh.TopologyEdges.GetTopologyVertices(i);

                    Rhino.IndexPair EndTopologyVertices = theMesh.TopologyEdges.GetTopologyVertices(i);



                    int[] connectedTopVerts = theMesh.TopologyVertices.ConnectedTopologyVertices(EndTopologyVertices.I, true);

                    Point3d tip1 = new Point3d();
                    Point3d tip2 = new Point3d();

                    for (int j = 0; j < connectedTopVerts.Length; j++)
                    {
                        if (connectedTopVerts[j] == EndTopologyVertices.J)
                        {
                            int Tip1TopologyVertex = connectedTopVerts[(j - 1 + connectedTopVerts.Length) % (connectedTopVerts.Length)];
                            int Tip2TopologyVertex = connectedTopVerts[(j + 1 + connectedTopVerts.Length) % (connectedTopVerts.Length)];
                            int[] Tip1VertexIndex = theMesh.TopologyVertices.MeshVertexIndices(Tip1TopologyVertex);
                            int[] Tip2VertexIndex = theMesh.TopologyVertices.MeshVertexIndices(Tip2TopologyVertex);

                            Point3d t1 = VertexPts[Tip1VertexIndex[0]];
                            Point3d t2 = VertexPts[Tip2VertexIndex[0]];

                            tip1 = t1;
                            tip2 = t2;
                        }
                    }


                    double distanceEdge = EdgeEnd1.DistanceTo(EdgeEnd2);

                    double distanceTips = tip1.DistanceTo(tip2);


                    if (distanceEdge > distanceTips)

                    {

                        theMesh.TopologyEdges.SwapEdge(i);

                    }


                }
            }



            return theMesh;
        }
































        /// <summary>
        /// The Exposure property controls where in the panel a component icon 
        /// will appear. There are seven possible locations (primary to septenary), 
        /// each of which can be combined with the GH_Exposure.obscure flag, which 
        /// ensures the component will only be visible on panel dropdowns.
        /// </summary>
        /// 











        public override GH_Exposure Exposure
        {
            get { return GH_Exposure.primary; }
        }

        /// <summary>
        /// Provides an Icon for every component that will be visible in the User Interface.
        /// Icons need to be 24x24 pixels.
        /// </summary>
        protected override System.Drawing.Bitmap Icon
        {
            get
            {
                // You can add image files to your project resources and access them like this:
                //return Resources.IconForThisComponent;
                // return null;

                return Resource1.TPIs;


            }
        }

        /// <summary>
        /// Gets the unique ID for this component. Do not change this ID after release.
        /// </summary>
        public override Guid ComponentGuid
        {
            get { return new Guid("6b6cdb4d-5dec-4044-abaa-9eddcf19755a"); }
        }
    }
}